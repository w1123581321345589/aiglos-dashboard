"""
Aiglos CLI -- Command-line interface for the security runtime.

Commands:
  aiglos proxy     Start the MCP security proxy
  aiglos scan      Run the security scanner on a directory
  aiglos logs      View recent audit log events
  aiglos tail      Live tail security events
  aiglos sessions  List recent agent sessions
  aiglos report    Generate a CMMC compliance report
  aiglos policy    Manage security policies
  aiglos init      Generate a starter config and policy file
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path

import click
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

from aiglos_core.types import ProxyConfig, DeploymentTier, PolicyAction
from aiglos_core.audit import AuditLog
from aiglos_core.proxy import run_proxy
from aiglos_core.policy import generate_default_policy_file

console = Console()

SEVERITY_COLORS = {
    "critical": "bold red",
    "high": "red",
    "medium": "yellow",
    "low": "cyan",
    "info": "dim",
}

BANNER = r"""
[bold cyan]
   _____ _                     _  _____                     _
  / ____| |                   | |/ ____|                   | |
 | |    | | __ ___      _____ | | |  __ _   _  __ _ _ __ __| |
 | |    | |/ _` \ \ /\ / / _` | | | |_ | | | |/ _` | '__/ _` |
 | |____| | (_| |\ V  V / (_| | | |__| | |_| | (_| | | | (_| |
  \_____|_|\__,_| \_/\_/ \__,_|_|\_____|\\__,_|\\__,_|_|  \\__,_|
[/bold cyan]
[dim]AI Agent Security Runtime for Defense and Critical Infrastructure[/dim]
[dim]v0.1.0[/dim]
"""


def get_audit(db_path: str) -> AuditLog:
    return AuditLog(db_path)


# ---------------------------------------------------------------------------
# CLI group
# ---------------------------------------------------------------------------

@click.group()
@click.version_option("0.1.0", prog_name="aiglos")
def cli():
    """Aiglos -- AI Agent Security Runtime."""
    pass


# ---------------------------------------------------------------------------
# proxy
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--host", default="127.0.0.1", show_default=True, help="Listen address")
@click.option("--port", default=8765, show_default=True, help="Listen port")
@click.option("--upstream-host", default="127.0.0.1", show_default=True)
@click.option("--upstream-port", default=18789, show_default=True)
@click.option("--tier", default="cloud", type=click.Choice(["cloud", "on_prem", "gov"]))
@click.option("--policy", default="aiglos_policy.yaml", help="Policy file path")
@click.option("--db", default="aiglos_audit.db", help="Audit database path")
@click.option("--no-goal-check", is_flag=True, help="Disable goal integrity engine")
@click.option("--no-cred-scan", is_flag=True, help="Disable credential scanning")
def proxy(host, port, upstream_host, upstream_port, tier, policy, db,
          no_goal_check, no_cred_scan):
    """Start the MCP Security Proxy."""
    console.print(BANNER)

    config = ProxyConfig(
        listen_host=host,
        listen_port=port,
        upstream_host=upstream_host,
        upstream_port=upstream_port,
        deployment_tier=DeploymentTier(tier),
        policy_file=policy,
        audit_db_path=db,
        enable_goal_integrity=not no_goal_check,
        enable_credential_scanning=not no_cred_scan,
    )

    console.print(Panel(
        f"[bold]Proxy listening:[/bold] [cyan]{host}:{port}[/cyan]\n"
        f"[bold]Upstream MCP:[/bold] [cyan]{upstream_host}:{upstream_port}[/cyan]\n"
        f"[bold]Deployment tier:[/bold] [cyan]{tier}[/cyan]\n"
        f"[bold]Policy file:[/bold] [cyan]{policy}[/cyan]\n"
        f"[bold]Audit DB:[/bold] [cyan]{db}[/cyan]",
        title="[bold cyan]Aiglos Proxy[/bold cyan]",
        border_style="cyan",
    ))

    try:
        asyncio.run(run_proxy(config))
    except KeyboardInterrupt:
        console.print("\n[yellow]Proxy stopped.[/yellow]")


# ---------------------------------------------------------------------------
# logs
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--db", default="aiglos_audit.db", help="Audit database path")
@click.option("-n", default=50, help="Number of events to show")
@click.option("--session", default=None, help="Filter by session ID")
@click.option("--severity", default=None,
              type=click.Choice(["critical", "high", "medium", "low", "info"]))
def logs(db, n, session, severity):
    """View recent audit log events."""
    if not Path(db).exists():
        console.print(f"[red]Audit database not found: {db}[/red]")
        sys.exit(1)

    audit = get_audit(db)
    events = audit.get_recent_events(limit=n, session_id=session, severity=severity)

    if not events:
        console.print("[dim]No events found.[/dim]")
        return

    table = Table(
        box=box.SIMPLE_HEAVY,
        show_header=True,
        header_style="bold cyan",
        title=f"[bold]Security Events[/bold] ({len(events)} shown)",
    )
    table.add_column("Time", style="dim", width=19)
    table.add_column("Severity", width=10)
    table.add_column("Type", width=22)
    table.add_column("Title")
    table.add_column("Session", style="dim", width=12)

    for ev in events:
        ts = datetime.fromtimestamp(ev["timestamp"]).strftime("%Y-%m-%d %H:%M:%S")
        sev = ev["severity"]
        color = SEVERITY_COLORS.get(sev, "white")
        session_short = ev["session_id"][:8] + "..." if ev["session_id"] else ""
        table.add_row(
            ts,
            Text(sev.upper(), style=color),
            ev["event_type"],
            ev["title"],
            session_short,
        )

    console.print(table)


# ---------------------------------------------------------------------------
# tail
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--db", default="aiglos_audit.db", help="Audit database path")
@click.option("--severity", default="info",
              type=click.Choice(["critical", "high", "medium", "low", "info"]))
def tail(db, severity):
    """Live tail security events from the audit log."""
    if not Path(db).exists():
        console.print(f"[red]Audit database not found: {db}[/red]")
        sys.exit(1)

    console.print(Panel(
        "[dim]Watching for new security events... (Ctrl+C to stop)[/dim]",
        title="[bold cyan]Aiglos Live Tail[/bold cyan]",
        border_style="cyan",
    ))

    audit = get_audit(db)
    seen_ids: set[str] = set()

    # Seed with existing events
    for ev in audit.get_recent_events(limit=5):
        seen_ids.add(ev["id"])

    sev_order = ["critical", "high", "medium", "low", "info"]
    min_sev_idx = sev_order.index(severity)

    try:
        while True:
            events = audit.get_recent_events(limit=20)
            for ev in reversed(events):
                if ev["id"] not in seen_ids:
                    ev_sev_idx = sev_order.index(ev["severity"]) if ev["severity"] in sev_order else 4
                    if ev_sev_idx <= min_sev_idx:
                        ts = datetime.fromtimestamp(ev["timestamp"]).strftime("%H:%M:%S")
                        sev = ev["severity"]
                        color = SEVERITY_COLORS.get(sev, "white")
                        console.print(
                            f"[dim]{ts}[/dim] [{color}]{sev.upper():8}[/{color}] "
                            f"{ev['title']}"
                        )
                    seen_ids.add(ev["id"])
            time.sleep(1)
    except KeyboardInterrupt:
        console.print("\n[yellow]Tail stopped.[/yellow]")


# ---------------------------------------------------------------------------
# sessions
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--db", default="aiglos_audit.db", help="Audit database path")
@click.option("-n", default=20, help="Number of sessions to show")
@click.option("--active", is_flag=True, help="Show only active sessions")
def sessions(db, n, active):
    """List recent agent sessions."""
    if not Path(db).exists():
        console.print(f"[red]Audit database not found: {db}[/red]")
        sys.exit(1)

    audit = get_audit(db)
    rows = audit.get_sessions(limit=n, active_only=active)
    stats = audit.get_stats()

    # Stats panel
    console.print(Panel(
        f"[bold]Total Sessions:[/bold] {stats['total_sessions']}  "
        f"[bold]Active:[/bold] {stats['active_sessions']}  "
        f"[bold]Tool Calls:[/bold] {stats['total_tool_calls']}  "
        f"[bold]Blocked:[/bold] [red]{stats['blocked_calls']}[/red]  "
        f"[bold]Critical Events:[/bold] [bold red]{stats['critical_events']}[/bold red]",
        title="[bold cyan]Aiglos Stats[/bold cyan]",
        border_style="cyan",
    ))

    if not rows:
        console.print("[dim]No sessions found.[/dim]")
        return

    table = Table(
        box=box.SIMPLE_HEAVY,
        header_style="bold cyan",
        title=f"[bold]Agent Sessions[/bold] ({len(rows)} shown)",
    )
    table.add_column("Session ID", width=14)
    table.add_column("Model", width=20)
    table.add_column("Started", width=19)
    table.add_column("Status", width=8)
    table.add_column("Goal Integrity", width=14)
    table.add_column("Anomaly", width=8)
    table.add_column("Initiated By", width=16)

    for row in rows:
        ts = datetime.fromtimestamp(row["start_time"]).strftime("%Y-%m-%d %H:%M:%S")
        session_short = row["session_id"][:12] + "..."
        status = "[green]ACTIVE[/green]" if row["is_active"] else "[dim]CLOSED[/dim]"

        gi_score = row.get("goal_integrity_score", 1.0)
        gi_color = "green" if gi_score > 0.7 else "yellow" if gi_score > 0.35 else "red"
        gi_display = f"[{gi_color}]{gi_score:.2f}[/{gi_color}]"

        an_score = row.get("anomaly_score", 0.0)
        an_color = "green" if an_score < 0.3 else "yellow" if an_score < 0.7 else "red"
        an_display = f"[{an_color}]{an_score:.2f}[/{an_color}]"

        table.add_row(
            session_short,
            row.get("model_id", "unknown"),
            ts,
            status,
            gi_display,
            an_display,
            row.get("initiated_by", "unknown"),
        )

    console.print(table)


# ---------------------------------------------------------------------------
# scan (original scanner, now as a subcommand)
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--path", default=None, help="Path to scan (default: ~/.clawdbot)")
@click.option("--format", "fmt", default="table",
              type=click.Choice(["table", "json"]), show_default=True)
def scan(path, fmt):
    """Run the configuration security scanner."""
    from aiglos_core.scanner.config_scanner import ConfigScanner
    scanner = ConfigScanner(path)
    findings = scanner.scan()

    if fmt == "json":
        console.print(scanner.to_json())
        return

    if not findings:
        console.print(Panel(
            "[bold green]No security issues found.[/bold green]",
            title="[bold cyan]Aiglos Scan Results[/bold cyan]",
            border_style="green",
        ))
        return

    table = Table(
        box=box.SIMPLE_HEAVY,
        header_style="bold cyan",
        title="[bold]Configuration Scan Results[/bold]",
    )
    table.add_column("Check", width=30)
    table.add_column("Severity", width=10)
    table.add_column("Description", width=50)
    table.add_column("Fix")

    critical = high = medium = low = 0
    for f in findings:
        sev = f.severity.value
        color = SEVERITY_COLORS.get(sev, "white")
        table.add_row(
            f.check,
            Text(sev.upper(), style=color),
            f.description,
            f.fix,
        )
        if sev == "critical": critical += 1
        elif sev == "high": high += 1
        elif sev == "medium": medium += 1
        elif sev == "low": low += 1

    console.print(table)
    console.print(
        f"\n[bold red]Critical: {critical}[/bold red]  "
        f"[red]High: {high}[/red]  "
        f"[yellow]Medium: {medium}[/yellow]  "
        f"[cyan]Low: {low}[/cyan]"
    )


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--tier", default="cloud", type=click.Choice(["cloud", "on_prem", "gov"]))
def init(tier):
    """Generate a starter Aiglos config and policy file."""
    import yaml

    config = {
        "aiglos": {
            "version": "0.1.0",
            "deployment_tier": tier,
            "proxy": {
                "listen_host": "127.0.0.1",
                "listen_port": 8765,
                "upstream_host": "127.0.0.1",
                "upstream_port": 18789,
            },
            "security": {
                "enable_goal_integrity": True,
                "enable_credential_scanning": True,
                "enable_policy_engine": True,
                "enable_behavioral_baseline": True,
                "enable_attestation": True,
                "goal_drift_threshold": 0.35,
            },
            "audit": {
                "db_path": "aiglos_audit.db",
                "log_full_payloads": True,
            },
            "alerts": {
                "slack_webhook": None,
                "webhook_url": None,
            },
        }
    }

    with open("aiglos.yaml", "w") as f:
        yaml.dump(config, f, default_flow_style=False)

    generate_default_policy_file("aiglos_policy.yaml")

    console.print(Panel(
        "[green]Generated:[/green] aiglos.yaml\n"
        "[green]Generated:[/green] aiglos_policy.yaml\n\n"
        "Start the proxy with: [bold cyan]aiglos proxy[/bold cyan]\n"
        "View events with:     [bold cyan]aiglos logs[/bold cyan]\n"
        "Live tail with:       [bold cyan]aiglos tail[/bold cyan]",
        title="[bold cyan]Aiglos Initialized[/bold cyan]",
        border_style="cyan",
    ))


# ---------------------------------------------------------------------------
# report (stub -- full implementation in T19)
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--db", default="aiglos_audit.db")
@click.option("--session", default=None, help="Scope report to one session ID")
@click.option("--level", default=2, type=click.Choice(["1", "2", "3"]), help="CMMC level")
@click.option("--output", default="aiglos_cmmc_report.json")
@click.option("--format", "fmt", default="json", type=click.Choice(["json", "summary"]))
def report(db, session, level, output, fmt):
    """Generate a CMMC compliance report."""
    from aiglos_core.compliance import build_compliance_report, CMMCLevel
    from aiglos_core.types import SecurityEvent, EventType, Severity

    if not Path(db).exists():
        console.print(f"[red]Audit database not found: {db}[/red]")
        sys.exit(1)

    audit = get_audit(db)
    raw_events = audit.get_recent_events(limit=10000, session_id=session)
    sessions_data = audit.get_sessions(limit=1000)

    events = []
    for ev in raw_events:
        se = SecurityEvent(
            id=ev["id"],
            session_id=ev["session_id"],
            event_type=EventType(ev["event_type"]),
            severity=Severity(ev["severity"]),
            title=ev["title"],
            description=ev.get("description", ""),
            timestamp=ev["timestamp"],
            cmmc_controls=json.loads(ev.get("cmmc_controls", "[]") or "[]"),
            nist_controls=json.loads(ev.get("nist_controls", "[]") or "[]"),
        )
        events.append(se)

    cmmc_level = CMMCLevel(int(level))
    compliance_report = build_compliance_report(
        events=events,
        sessions=sessions_data,
        cmmc_level=cmmc_level,
        session_id=session,
    )

    if fmt == "json":
        with open(output, "w") as f:
            f.write(compliance_report.to_json())

    # Always print summary
    covered_color = "green" if compliance_report.overall_coverage_pct >= 80 else "yellow"
    console.print(Panel(
        f"[bold]CMMC Level:[/bold] {level}\n"
        f"[bold]Controls Covered:[/bold] [{covered_color}]{compliance_report.controls_covered}/{compliance_report.total_controls_applicable} ({compliance_report.overall_coverage_pct:.0f}%)[/{covered_color}]\n"
        f"[bold]Partial:[/bold] {compliance_report.controls_partial}\n"
        f"[bold]Total Events:[/bold] {compliance_report.total_events}\n"
        f"[bold]Critical Events:[/bold] [red]{compliance_report.critical_events}[/red]\n"
        f"[bold]Attestations Issued:[/bold] {compliance_report.attestations_issued}\n"
        f"[bold]Section 1513 Readiness:[/bold] {compliance_report.section_1513_active_count}/{compliance_report.section_1513_total}\n"
        + (f"\n[green]Report saved to:[/green] {output}" if fmt == "json" else ""),
        title="[bold cyan]CMMC Compliance Report[/bold cyan]",
        border_style="cyan",
    ))

    if compliance_report.gaps:
        for gap in compliance_report.gaps:
            console.print(f"[yellow]Gap:[/yellow] {gap}")

    if fmt == "summary":
        table = Table(box=box.SIMPLE_HEAVY, header_style="bold cyan", title="Control Coverage")
        table.add_column("Control ID", width=12)
        table.add_column("Family", width=28)
        table.add_column("Title", width=30)
        table.add_column("Status", width=12)
        table.add_column("Evidence")
        for entry in compliance_report.control_coverage:
            st = entry["status"]
            color = "green" if st == "covered" else "yellow" if st == "partial" else "dim"
            table.add_row(
                entry["control_id"],
                entry["family"],
                entry["title"],
                Text(st.upper(), style=color),
                str(entry["evidence_count"]),
            )
        console.print(table)


if __name__ == "__main__":
    cli()


# ---------------------------------------------------------------------------
# attest
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--session", required=True, help="Session ID to attest")
@click.option("--db", default="aiglos_audit.db")
@click.option("--output", default=None, help="Output file (default: <session_id>.attestation.json)")
def attest(session, db, output):
    """Produce a signed attestation document for a session."""
    from aiglos_core.intelligence.attestation import AttestationBuilder
    from aiglos_core.types import (
        AgentIdentity, SessionContext, SecurityEvent, EventType, Severity
    )
    import json as _json

    if not Path(db).exists():
        console.print(f"[red]Audit database not found: {db}[/red]")
        sys.exit(1)

    audit = get_audit(db)
    sessions_data = audit.get_sessions(limit=1000)
    session_row = next((s for s in sessions_data if s["session_id"] == session), None)
    if not session_row:
        console.print(f"[red]Session not found: {session}[/red]")
        sys.exit(1)

    # Reconstruct session context from audit data
    ctx = SessionContext()
    ctx.identity = AgentIdentity(
        session_id=session_row["session_id"],
        model_id=session_row.get("model_id", ""),
        model_version=session_row.get("model_version", ""),
        system_prompt_hash=session_row.get("system_prompt_hash", ""),
        tool_permissions=_json.loads(session_row.get("tool_permissions", "[]") or "[]"),
        initiated_by=session_row.get("initiated_by", "unknown"),
        timestamp=session_row.get("start_time", 0.0),
        attestation_hash=session_row.get("attestation_hash", ""),
    )
    ctx.authorized_goal = session_row.get("authorized_goal", "")
    ctx.authorized_goal_hash = session_row.get("authorized_goal_hash", "")
    ctx.goal_integrity_score = session_row.get("goal_integrity_score", 1.0)
    ctx.anomaly_score = session_row.get("anomaly_score", 0.0)
    ctx.is_active = False
    ctx.end_time = session_row.get("end_time")

    # Load events
    raw_events = audit.get_recent_events(limit=10000, session_id=session)
    events = []
    for ev in reversed(raw_events):  # chronological order
        se = SecurityEvent(
            id=ev["id"],
            session_id=ev["session_id"],
            event_type=EventType(ev["event_type"]),
            severity=Severity(ev["severity"]),
            title=ev["title"],
            description=ev.get("description", ""),
            details=_json.loads(ev.get("details", "{}") or "{}"),
            timestamp=ev["timestamp"],
            cmmc_controls=_json.loads(ev.get("cmmc_controls", "[]") or "[]"),
            nist_controls=_json.loads(ev.get("nist_controls", "[]") or "[]"),
        )
        events.append(se)

    builder = AttestationBuilder()
    doc = builder.build(ctx, events)

    out_path = output or f"{session[:12]}.attestation.json"
    with open(out_path, "w") as f:
        f.write(doc.to_json())

    console.print(Panel(
        f"[green]Attestation saved to:[/green] {out_path}\n"
        f"[bold]Document hash:[/bold] [cyan]{doc.document_hash[:32]}...[/cyan]\n"
        f"[bold]Session ID:[/bold] {session[:24]}...\n"
        f"[bold]Events in manifest:[/bold] {len(doc.event_manifest)}\n"
        f"[bold]CMMC controls active:[/bold] {len(doc.cmmc_controls_active)}\n"
        f"[bold]Goal integrity score:[/bold] {doc.security_posture.get('goal_integrity_score', 'N/A')}\n"
        f"[bold]Signed:[/bold] {'Yes' if doc.signature else 'Hash only'}",
        title="[bold cyan]Aiglos Attestation[/bold cyan]",
        border_style="cyan",
    ))


# ---------------------------------------------------------------------------
# verify
# ---------------------------------------------------------------------------

@cli.command()
@click.argument("attestation_file")
def verify(attestation_file):
    """Verify the integrity of an attestation document."""
    from aiglos_core.intelligence.attestation import AttestationBuilder

    if not Path(attestation_file).exists():
        console.print(f"[red]File not found: {attestation_file}[/red]")
        sys.exit(1)

    builder = AttestationBuilder()
    doc_json = Path(attestation_file).read_text()
    is_valid, reason = builder.verify_json(doc_json)

    if is_valid:
        console.print(Panel(
            f"[bold green]VALID[/bold green]\n{reason}",
            title="[bold cyan]Attestation Verification[/bold cyan]",
            border_style="green",
        ))
    else:
        console.print(Panel(
            f"[bold red]INVALID[/bold red]\n{reason}\n\n"
            "[yellow]This document may have been tampered with.[/yellow]",
            title="[bold red]Attestation Verification FAILED[/bold red]",
            border_style="red",
        ))
        sys.exit(1)


# ---------------------------------------------------------------------------
# alerts (dispatcher status)
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--db", default="aiglos_audit.db")
def alerts(db):
    """Show alert destination configuration and stats."""
    console.print(Panel(
        "Configure alert destinations in [bold]aiglos.yaml[/bold] under the "
        "[cyan]alerts:[/cyan] key.\n\n"
        "Supported destinations: [cyan]splunk[/cyan], [cyan]slack[/cyan], "
        "[cyan]webhook[/cyan], [cyan]syslog[/cyan], [cyan]file_sink[/cyan], "
        "[cyan]teams[/cyan]\n\n"
        "Example:\n"
        "[dim]alerts:\n"
        "  slack:\n"
        "    webhook_url: https://hooks.slack.com/...\n"
        "    min_severity: high\n"
        "  splunk:\n"
        "    hec_url: https://splunk.example.com:8088/services/collector\n"
        "    hec_token: YOUR_HEC_TOKEN\n"
        "    min_severity: info\n"
        "  file_sink:\n"
        "    path: aiglos_events.jsonl[/dim]",
        title="[bold cyan]Aiglos Alert Destinations[/bold cyan]",
        border_style="cyan",
    ))


# ---------------------------------------------------------------------------
# trust
# ---------------------------------------------------------------------------

@cli.group()
def trust():
    """Manage the MCP server trust registry."""
    pass


@trust.command("list")
@click.option("--trust-file", default="aiglos_trust.yaml")
def trust_list(trust_file):
    """List all servers in the trust registry."""
    from aiglos_core.proxy.trust import ServerTrustRegistry, TrustStatus

    registry = ServerTrustRegistry(trust_file=trust_file)
    entries = registry.list_entries()
    stats = registry.stats()

    if not entries:
        console.print("[dim]No servers in trust registry. Use 'aiglos trust allow' to add one.[/dim]")
        return

    table = Table(box=box.SIMPLE_HEAVY, header_style="bold cyan",
        title=f"Trust Registry — mode: [bold]{stats['mode'].upper()}[/bold]")
    table.add_column("Address", width=28)
    table.add_column("Alias", width=22)
    table.add_column("Status", width=12)
    table.add_column("Fingerprint", width=20)
    table.add_column("Connections")

    for e in sorted(entries, key=lambda x: x.identity.address):
        st = e.status.value
        color = "green" if st=="allowed" else "red" if st=="blocked" else "yellow"
        fp = e.identity.fingerprint[:16] + "..." if e.identity.fingerprint else "—"
        table.add_row(
            e.identity.address,
            e.identity.alias or "—",
            Text(st.upper(), style=color),
            fp,
            str(e.identity.connection_count),
        )
    console.print(table)


@trust.command("allow")
@click.argument("address")
@click.option("--alias", default="", help="Human-readable name")
@click.option("--note", default="")
@click.option("--trust-file", default="aiglos_trust.yaml")
def trust_allow(address, alias, note, trust_file):
    """Allow an MCP server (host:port)."""
    from aiglos_core.proxy.trust import ServerTrustRegistry

    if ":" not in address:
        console.print("[red]Address must be host:port format[/red]")
        sys.exit(1)
    host, port_str = address.rsplit(":", 1)
    registry = ServerTrustRegistry(trust_file=trust_file)
    registry.allow(host, int(port_str), alias=alias, note=note)
    console.print(f"[green]✓[/green] Allowed: [bold]{address}[/bold]" + (f" ({alias})" if alias else ""))


@trust.command("block")
@click.argument("address")
@click.option("--alias", default="")
@click.option("--reason", default="", required=True, help="Reason for blocking")
@click.option("--trust-file", default="aiglos_trust.yaml")
def trust_block(address, alias, reason, trust_file):
    """Block an MCP server (host:port)."""
    from aiglos_core.proxy.trust import ServerTrustRegistry

    if ":" not in address:
        console.print("[red]Address must be host:port format[/red]")
        sys.exit(1)
    host, port_str = address.rsplit(":", 1)
    registry = ServerTrustRegistry(trust_file=trust_file)
    registry.block(host, int(port_str), alias=alias, reason=reason)
    console.print(f"[red]✗[/red] Blocked: [bold]{address}[/bold] — {reason}")


@trust.command("remove")
@click.argument("address")
@click.option("--trust-file", default="aiglos_trust.yaml")
def trust_remove(address, trust_file):
    """Remove a server from the trust registry."""
    from aiglos_core.proxy.trust import ServerTrustRegistry

    if ":" not in address:
        console.print("[red]Address must be host:port format[/red]")
        sys.exit(1)
    host, port_str = address.rsplit(":", 1)
    registry = ServerTrustRegistry(trust_file=trust_file)
    removed = registry.remove(host, int(port_str))
    if removed:
        console.print(f"[green]Removed {address} from trust registry[/green]")
    else:
        console.print(f"[yellow]{address} was not in the registry[/yellow]")


# ---------------------------------------------------------------------------
# report pdf
# ---------------------------------------------------------------------------

@cli.command("report-pdf")
@click.option("--org", default="Defense Contractor", help="Organization name")
@click.option("--level", default=2, type=int, help="CMMC level (1-3)")
@click.option("--tier", default="cloud", help="Deployment tier (cloud|on_prem|gov)")
@click.option("--days", default=30, type=int, help="Assessment period in days")
@click.option("--official", default="", help="Affirming official name")
@click.option("--output", default="aiglos_cmmc_report.pdf", help="Output file path")
@click.option("--db", default="aiglos_audit.db")
def report_pdf(org, level, tier, days, official, output, db):
    """Generate a CMMC compliance report PDF for C3PAO submission."""
    from aiglos_core.compliance.report_pdf import build_report_data, generate_pdf, EventSummary

    # Pull real event stats if the audit DB exists
    ev = EventSummary()
    if os.path.exists(db):
        try:
            import sqlite3
            with sqlite3.connect(db) as conn:
                rows = conn.execute(
                    "SELECT severity, COUNT(*) FROM security_events GROUP BY severity"
                ).fetchall()
                for sev, count in rows:
                    ev.by_severity[sev] = count
                    ev.total_events += count

                type_rows = conn.execute(
                    "SELECT event_type, COUNT(*) FROM security_events GROUP BY event_type"
                ).fetchall()
                for etype, count in type_rows:
                    ev.by_type[etype] = count

                session_row = conn.execute(
                    "SELECT COUNT(DISTINCT session_id) FROM security_events"
                ).fetchone()
                if session_row:
                    ev.sessions_analyzed = session_row[0]
        except Exception:
            pass

    data = build_report_data(
        organization=org,
        deployment_tier=tier,
        cmmc_level=level,
        period_days=days,
        event_summary=ev,
        affirming_official=official,
    )

    with console.status(f"[bold]Generating CMMC Level {level} compliance report PDF...[/bold]"):
        generate_pdf(data, output)

    console.print(f"[green]✓[/green] Report generated: [bold]{output}[/bold]")
    covered = sum(1 for c in data.controls if c.status == "covered")
    total = len(data.controls)
    console.print(f"  Controls: {covered}/{total} covered  |  §1513: {len(data.s1513_items)}/10 active")
    console.print(f"  Hand this file to your C3PAO assessor or upload to your CMMC documentation package.")


# ---------------------------------------------------------------------------
# daemon -- autonomous engine (T23)
# ---------------------------------------------------------------------------

@cli.group()
def daemon():
    """Autonomous threat scanning engine. Continuously hunts threats without human input."""
    pass


@daemon.command("start")
@click.option("--db", default="aiglos_audit.db")
@click.option("--scan-interval", default=5, show_default=True, help="Minutes between scan cycles")
@click.option("--intel-interval", default=60, show_default=True, help="Minutes between intel refreshes")
@click.option("--report-interval", default=1440, show_default=True, help="Minutes between compliance reports")
@click.option("--state-file", default="aiglos_engine_state.json")
@click.option("--background", "-b", is_flag=True, help="Run detached as background process")
def daemon_start(db, scan_interval, intel_interval, report_interval, state_file, background):
    """Start the autonomous threat scanning engine."""
    import asyncio
    if background:
        import subprocess, sys
        proc = subprocess.Popen(
            [sys.executable, "-m", "aiglos_cli.main", "daemon", "start",
             "--db", db, "--scan-interval", str(scan_interval), "--state-file", state_file],
            stdout=open("aiglos_engine.log", "a"), stderr=subprocess.STDOUT, start_new_session=True)
        Path("aiglos_engine.pid").write_text(str(proc.pid))
        console.print(f"[green]✓[/green] Aiglos autonomous engine started (PID {proc.pid})")
        console.print("  Logs: aiglos_engine.log  |  Stop: aiglos daemon stop"); return

    from aiglos_core.autonomous import AiglOsAutonomousEngine
    console.print("[bold green]Aiglos Autonomous Engine[/bold green]")
    console.print(f"  Scan every {scan_interval}m  |  Intel every {intel_interval}m  |  Report every {report_interval//60}h")
    console.print("[dim]Ctrl+C to stop.[/dim]\n")
    engine = AiglOsAutonomousEngine(
        audit_db_path=db, state_path=state_file,
        scan_interval_minutes=scan_interval,
        intel_refresh_interval_hours=max(1, intel_interval // 60),
        report_interval_hours=max(1, report_interval // 60))
    try: asyncio.run(engine.run())
    except KeyboardInterrupt: console.print("\n[yellow]Engine stopped.[/yellow]")


@daemon.command("stop")
@click.option("--pid-file", default="aiglos_engine.pid")
def daemon_stop(pid_file):
    """Stop a background autonomous engine process."""
    import signal as _signal
    pid_path = Path(pid_file)
    if not pid_path.exists():
        console.print("[yellow]No PID file found.[/yellow]"); return
    try:
        pid = int(pid_path.read_text().strip()); os.kill(pid, _signal.SIGTERM)
        pid_path.unlink(); console.print(f"[green]✓[/green] Engine stopped (PID {pid})")
    except ProcessLookupError:
        console.print("[yellow]Process not found. Removing stale PID file.[/yellow]")
        pid_path.unlink(missing_ok=True)
    except Exception as e: console.print(f"[red]Error: {e}[/red]")


@daemon.command("status")
@click.option("--state-file", default="aiglos_engine_state.json")
def daemon_status(state_file):
    """Show autonomous engine status and recent activity."""
    from rich.table import Table
    state_path = Path(state_file)
    if not state_path.exists():
        console.print("[yellow]Engine not running. Start with: aiglos daemon start[/yellow]"); return
    try: data = json.loads(state_path.read_text())
    except Exception as e: console.print(f"[red]Error reading state: {e}[/red]"); return

    threat_level = data.get("threat_level", "nominal")
    state = data.get("state", "unknown")
    uptime = data.get("uptime_seconds", 0)
    tc = {"nominal": "green", "elevated": "yellow", "critical": "red"}.get(threat_level, "white")
    sc = "green" if state == "running" else "yellow"
    critical_24h = data.get("critical_events_24h", 0)

    console.print(f"\n[bold]Aiglos Autonomous Engine[/bold]")
    console.print(f"  State: [{sc}]{state.upper()}[/{sc}]  |  Threat: [{tc}]{threat_level.upper()}[/{tc}]  |  Uptime: {int(uptime//3600)}h {int((uptime%3600)//60)}m\n")
    t = Table(show_header=False, box=None, pad_edge=False)
    t.add_column("k", style="dim"); t.add_column("v", justify="right")
    t.add_row("Tasks completed", str(data.get("tasks_completed", 0)))
    t.add_row("Tasks failed", str(data.get("tasks_failed", 0)))
    t.add_row("Tasks queued", str(data.get("tasks_queued", 0)))
    t.add_row("Active task", str(data.get("active_task") or "idle"))
    t.add_row("Critical events (24h)", f"[{'red' if critical_24h else 'green'}]{critical_24h}[/{'red' if critical_24h else 'green'}]")
    def _ts(ts):
        if not ts: return "never"
        d = time.time() - ts
        return f"{int(d)}s ago" if d < 60 else (f"{int(d//60)}m ago" if d < 3600 else f"{int(d//3600)}h ago")
    t.add_row("Last scan", _ts(data.get("last_scan_at")))
    t.add_row("Last intel refresh", _ts(data.get("last_intel_refresh_at")))
    t.add_row("Last report", _ts(data.get("last_report_at")))
    console.print(t); console.print()


@daemon.command("scan")
@click.option("--db", default="aiglos_audit.db")
@click.option("--intel", is_flag=True, help="Also refresh threat intelligence")
def daemon_scan(db, intel):
    """Run a single threat hunt cycle immediately (foreground)."""
    import asyncio
    from aiglos_core.autonomous.hunter import ThreatHunter

    async def _run():
        hunter = ThreatHunter(audit_db_path=db)
        with console.status("[bold]Running threat hunt...[/bold]"):
            result = await hunter.run_full_scan()
        console.print(f"\n[bold]Hunt Complete[/bold] ({result.duration_s}s) | {', '.join(result.hunts_run)}")
        console.print(f"  Sessions: {result.sessions_analyzed}  |  Tool calls: {result.tool_calls_analyzed}\n")
        if not result.findings:
            console.print("[green]✓ No findings. Threat level: NOMINAL.[/green]"); return
        for f in result.findings:
            c = {"critical":"red","high":"yellow","medium":"blue","low":"dim"}.get(f.severity,"white")
            console.print(f"  [{c}][{f.severity.upper()}][/{c}] {f.title}")
            console.print(f"  [dim]  {f.description[:100]}[/dim]")
            if f.remediation: console.print(f"  [dim]  Fix: {f.remediation[:80]}[/dim]")
            console.print()
        console.print(f"[bold]{result.critical_count} critical  {result.high_count} high  {len(result.findings)} total[/bold]")
        if intel:
            from aiglos_core.autonomous.intel import ThreatIntelligence
            ie = ThreatIntelligence()
            with console.status("[bold]Refreshing threat intelligence...[/bold]"):
                ir = await ie.refresh()
            console.print(f"\n[bold]Intel:[/bold] {ir.new_indicators} new indicators, {ir.new_policy_rules} rules added")

    asyncio.run(_run())


@daemon.command("intel")
@click.option("--policy", default="aiglos_policy.yaml")
@click.option("--trust", default="aiglos_trust.yaml")
def daemon_intel(policy, trust):
    """Run threat intelligence refresh and update policies immediately."""
    import asyncio
    from aiglos_core.autonomous.intel import ThreatIntelligence

    async def _run():
        ie = ThreatIntelligence(policy_file=policy, trust_file=trust)
        with console.status("[bold]Ingesting threat intelligence...[/bold]"):
            r = await ie.refresh()
        console.print(f"\n[bold]Intel Refresh Complete[/bold] ({r.refresh_duration_s}s)")
        console.print(f"  Sources: {', '.join(r.sources_checked) or 'none'}  |  New indicators: {r.new_indicators}")
        console.print(f"  Rules added: {r.new_policy_rules}  |  Servers blocked: {r.new_blocked_servers}")
        if r.errors: [console.print(f"  [red]Error: {e}[/red]") for e in r.errors]
        s = ie.get_summary()
        console.print(f"\n  Library: {s['total_indicators']} indicators ({s['applied']} applied, {s['pending']} pending)")

    asyncio.run(_run())


# ---------------------------------------------------------------------------
# T27: Red Team Probe command
# ---------------------------------------------------------------------------

@app.command("probe")
@click.option("--target", default=None, help="Target server ID (default: all registered servers)")
@click.option("--probes", default=None, help="Comma-separated probe types")
@click.option("--verbose", is_flag=True, help="Show all probe results")
@click.option("--json-output", is_flag=True, help="Output as JSON")
@click.option("--db", default="aiglos_audit.db")
def probe(target, probes, verbose, json_output, db):
    """Red team probe: adversarial self-testing for MCP deployments (T27)."""
    import asyncio, json as _json
    from aiglos_probe import ProbeEngine, ProbeReport

    probe_types = [p.strip() for p in probes.split(",")] if probes else None

    async def _run():
        engine = ProbeEngine(audit_db=db)
        if target:
            reports = [await engine.probe_server(target, probe_types)]
        else:
            reports = await engine.probe_all(probe_types)
        return reports

    reports = asyncio.run(_run())

    if json_output:
        print(_json.dumps([r.to_dict() for r in reports], indent=2))
        return

    for report in reports:
        total_vuln = report.vulnerable_count
        color = "red" if total_vuln else "green"
        console.print(f"\n[bold {color}]Probe: {report.target}[/bold {color}]  {report.summary_line()}")
        for f in report.findings:
            if f.verdict == "VULNERABLE":
                sev_color = {"critical": "red", "high": "yellow"}.get(f.severity, "white")
                console.print(f"  [{sev_color}]● {f.title}[/{sev_color}]")
                console.print(f"    {f.description[:120]}")
                if f.remediation:
                    console.print(f"    [dim]Remediation: {f.remediation[:100]}[/dim]")
        if verbose:
            for f in report.findings:
                if f.verdict == "HARDENED":
                    console.print(f"  [green]✓ {f.title}[/green]")


# ---------------------------------------------------------------------------
# T28: Section 1513 compliance command
# ---------------------------------------------------------------------------

@app.command("s1513")
@click.option("--db", default="aiglos_audit.db")
@click.option("--json-output", is_flag=True, help="Output as JSON")
@click.option("--pdf", default=None, help="Extend existing PDF report")
def s1513(db, json_output, pdf):
    """Generate NDAA FY2026 Section 1513 AI/ML compliance readiness report (T28)."""
    import json as _json
    from aiglos_core.compliance.s1513 import Section1513Mapper

    mapper = Section1513Mapper(audit_db=db)
    report = mapper.build_report()

    if json_output:
        print(report.to_json())
        return

    console.print(f"\n[bold blue]NDAA FY2026 §1513 Readiness[/bold blue]  Score: [bold]{report.overall_score_pct:.0f}%[/bold]  [{report.overall_status()}]")
    console.print(f"Controls active: {report.controls_active}/{report.controls_total}\n")

    for ds in report.domain_scores:
        bar = "█" * int(ds.score_pct / 10) + "░" * (10 - int(ds.score_pct / 10))
        color = "green" if ds.status == "READY" else "yellow" if ds.status == "PARTIAL" else "red"
        console.print(f"  [{color}]{ds.status_icon()} Domain {ds.domain_number}: {ds.domain:<26} {bar} {ds.score_pct:.0f}%[/{color}]")

    console.print(f"\n[dim]Framework basis: NDAA FY2026 §1513 + NIST AI RMF. DoD status report due June 16, 2026.[/dim]")

    if pdf:
        ok = mapper.extend_pdf_report(pdf)
        if ok:
            console.print(f"[green]Section 1513 sidecar written: {pdf}.s1513.json[/green]")
