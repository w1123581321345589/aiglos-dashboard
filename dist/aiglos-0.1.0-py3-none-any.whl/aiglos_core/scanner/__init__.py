"""
Aiglos Credential and Secret Scanner.

Scans all MCP tool arguments and responses for credentials, secrets,
and sensitive patterns before they cross the security boundary.

Pattern library covers: AWS, Anthropic, OpenAI, GitHub, Stripe, Slack,
Twilio, Google, Azure, and generic high-entropy string detection.
"""

from __future__ import annotations

import re
import math
from typing import Any

from aiglos_core.types import SecurityEvent, EventType, Severity


# ---------------------------------------------------------------------------
# Pattern library
# ---------------------------------------------------------------------------

SECRET_PATTERNS: list[tuple[str, re.Pattern[str], Severity]] = [
    # API Keys -- Critical
    ("Anthropic API Key",     re.compile(r"sk-ant-[a-zA-Z0-9\-_]{20,}"),           Severity.CRITICAL),
    ("OpenAI API Key",        re.compile(r"sk-[a-zA-Z0-9]{20,}"),                  Severity.CRITICAL),
    ("AWS Access Key",        re.compile(r"AKIA[0-9A-Z]{16}"),                     Severity.CRITICAL),
    ("AWS Secret Key",        re.compile(r"[0-9a-zA-Z/+]{40}"),                    Severity.HIGH),
    ("GitHub Token",          re.compile(r"gh[pousr]_[a-zA-Z0-9]{36,}"),           Severity.CRITICAL),
    ("GitHub Fine-Grained",   re.compile(r"github_pat_[a-zA-Z0-9_]{82}"),          Severity.CRITICAL),
    ("Stripe Secret",         re.compile(r"sk_live_[a-zA-Z0-9]{24,}"),             Severity.CRITICAL),
    ("Stripe Test",           re.compile(r"sk_test_[a-zA-Z0-9]{24,}"),             Severity.MEDIUM),
    ("Slack Bot Token",       re.compile(r"xoxb-[0-9]{11,}-[0-9]{11,}-[a-zA-Z0-9]{24}"), Severity.HIGH),
    ("Slack User Token",      re.compile(r"xoxp-[0-9]{11,}-[0-9]{11,}-[a-zA-Z0-9]{24}"), Severity.HIGH),
    ("Twilio SID",            re.compile(r"AC[a-f0-9]{32}"),                       Severity.HIGH),
    ("Google API Key",        re.compile(r"AIza[0-9A-Za-z\-_]{35}"),               Severity.HIGH),
    ("Google OAuth",          re.compile(r"ya29\.[0-9A-Za-z\-_]+"),               Severity.HIGH),
    ("Azure Storage",         re.compile(r"AccountKey=[a-zA-Z0-9+/=]{88}"),        Severity.CRITICAL),
    ("Azure SAS Token",       re.compile(r"sig=[a-zA-Z0-9%]{43,}"),               Severity.HIGH),
    ("JWT Token",             re.compile(r"eyJ[a-zA-Z0-9\-_]+\.eyJ[a-zA-Z0-9\-_]+\.[a-zA-Z0-9\-_]+"), Severity.HIGH),
    ("Private Key Header",    re.compile(r"-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----"), Severity.CRITICAL),
    ("Password in string",    re.compile(r'(?i)(password|passwd|pwd)\s*[:=]\s*["\']?[^\s"\']{8,}'), Severity.HIGH),
    ("Connection String",     re.compile(r'(?i)(mongodb|postgresql|mysql|redis)://[^\s]{10,}'), Severity.CRITICAL),
]

# Command injection indicators
COMMAND_INJECTION_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r";\s*(cat|rm|curl|wget|bash|sh|python|nc|ncat|netcat)\s"),
    re.compile(r"\|\s*(cat|rm|curl|wget|bash|sh|python|nc)\s"),
    re.compile(r"`[^`]{3,}`"),                          # backtick execution
    re.compile(r"\$\([^)]{3,}\)"),                      # $() subshell
    re.compile(r"&&\s*(cat|rm|curl|wget|bash|sh)"),
    re.compile(r">\s*/etc/(passwd|shadow|sudoers)"),
    re.compile(r"2>&1"),                                 # stderr redirect often used in injection
]

# Path traversal indicators
PATH_TRAVERSAL_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"\.\./\.\./"),
    re.compile(r"\.\.\\\.\.\\"),
    re.compile(r"%2e%2e%2f", re.IGNORECASE),
    re.compile(r"(?:/etc/passwd|/etc/shadow|/proc/self)"),
    re.compile(r"(?:C:\\Windows\\System32|C:\\Users\\.*\\AppData)"),
]


# ---------------------------------------------------------------------------
# Scanner class
# ---------------------------------------------------------------------------

class CredentialScanner:
    """
    Scans arbitrary data structures (dicts, strings, nested objects)
    for credentials and attack patterns.
    """

    def scan_value(self, value: Any, path: str = "") -> list[SecurityEvent]:
        """Recursively scan any value for secrets."""
        events: list[SecurityEvent] = []

        if isinstance(value, str):
            events.extend(self._scan_string(value, path))
        elif isinstance(value, dict):
            for k, v in value.items():
                events.extend(self.scan_value(v, f"{path}.{k}" if path else k))
        elif isinstance(value, (list, tuple)):
            for i, item in enumerate(value):
                events.extend(self.scan_value(item, f"{path}[{i}]"))

        return events

    def _scan_string(self, text: str, path: str) -> list[SecurityEvent]:
        events: list[SecurityEvent] = []

        # Secret patterns
        for name, pattern, severity in SECRET_PATTERNS:
            if pattern.search(text):
                events.append(SecurityEvent(
                    event_type=EventType.CREDENTIAL_DETECTED,
                    severity=severity,
                    title=f"Credential detected: {name}",
                    description=(
                        f"Pattern '{name}' matched in field '{path}'. "
                        "Potential secret or credential about to cross security boundary."
                    ),
                    details={"pattern_name": name, "field_path": path},
                    cmmc_controls=["3.13.10", "3.13.16"],
                    nist_controls=["SC-28", "IA-5"],
                ))

        # Command injection
        for pattern in COMMAND_INJECTION_PATTERNS:
            if pattern.search(text):
                events.append(SecurityEvent(
                    event_type=EventType.COMMAND_INJECTION,
                    severity=Severity.CRITICAL,
                    title="Command injection pattern detected",
                    description=(
                        f"Potential command injection in field '{path}'. "
                        "Argument contains shell metacharacters or execution patterns."
                    ),
                    details={"field_path": path, "snippet": text[:200]},
                    cmmc_controls=["3.14.2", "3.14.6"],
                    nist_controls=["SI-3", "SI-10"],
                ))
                break  # One event per field for injection

        # Path traversal
        for pattern in PATH_TRAVERSAL_PATTERNS:
            if pattern.search(text):
                events.append(SecurityEvent(
                    event_type=EventType.PATH_TRAVERSAL,
                    severity=Severity.HIGH,
                    title="Path traversal pattern detected",
                    description=(
                        f"Potential path traversal in field '{path}'. "
                        "Argument contains directory escape sequences."
                    ),
                    details={"field_path": path, "snippet": text[:200]},
                    cmmc_controls=["3.1.3", "3.13.1"],
                    nist_controls=["AC-3", "SC-4"],
                ))
                break

        # High-entropy string detection (possible secrets not matched above)
        if len(text) >= 20 and self._entropy(text) > 4.5:
            # Only flag if it looks like a key (alphanumeric + limited special chars)
            if re.match(r"^[a-zA-Z0-9+/=_\-]{20,}$", text):
                events.append(SecurityEvent(
                    event_type=EventType.CREDENTIAL_DETECTED,
                    severity=Severity.MEDIUM,
                    title="High-entropy string detected",
                    description=(
                        f"High-entropy string in field '{path}' may be an undeclared secret. "
                        "Review and confirm this value is not a credential."
                    ),
                    details={"field_path": path, "entropy": round(self._entropy(text), 3)},
                    cmmc_controls=["3.13.10"],
                    nist_controls=["IA-5"],
                ))

        return events

    @staticmethod
    def _entropy(s: str) -> float:
        """Shannon entropy of a string."""
        if not s:
            return 0.0
        freq = {}
        for c in s:
            freq[c] = freq.get(c, 0) + 1
        n = len(s)
        return -sum((f / n) * math.log2(f / n) for f in freq.values())


# Module-level singleton
_scanner = CredentialScanner()


def scan(value: Any, path: str = "") -> list[SecurityEvent]:
    """Convenience function: scan any value for credentials and attack patterns."""
    return _scanner.scan_value(value, path)
