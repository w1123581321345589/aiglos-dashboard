"""Config file security scanner -- the original Aiglos scanner, now a CLI subcommand."""

from __future__ import annotations

import json
import os
import yaml
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from aiglos_core.types import Severity


@dataclass
class Finding:
    check: str
    severity: Severity
    description: str
    fix: str
    details: Optional[str] = None


class ConfigScanner:
    def __init__(self, path: str | None = None):
        self.path = Path(path) if path else Path.home() / ".clawdbot"
        self.findings: list[Finding] = []

    def scan(self) -> list[Finding]:
        self.findings = []
        self._check_gateway_binding()
        self._check_authentication()
        self._check_plaintext_credentials()
        self._check_file_permissions()
        self._check_tls()
        self._check_permissive_tools()
        self._check_rate_limiting()
        self._check_exposed_logs()
        self._check_default_port()
        return self.findings

    def _load_config(self) -> dict:
        config_path = self.path / "config.yaml"
        if config_path.exists():
            with open(config_path) as f:
                return yaml.safe_load(f) or {}
        return {}

    def _check_gateway_binding(self):
        config = self._load_config()
        host = config.get("gateway", {}).get("host", "127.0.0.1")
        if host in ["0.0.0.0", "::"]:
            self.findings.append(Finding(
                check="Exposed Gateway",
                severity=Severity.CRITICAL,
                description="Gateway bound to 0.0.0.0 -- accessible from any network",
                fix="Set gateway.host to '127.0.0.1' in config.yaml",
            ))

    def _check_authentication(self):
        config = self._load_config()
        auth = config.get("gateway", {}).get("auth", {})
        if not auth.get("enabled", False):
            self.findings.append(Finding(
                check="No Authentication",
                severity=Severity.CRITICAL,
                description="Gateway has no authentication configured",
                fix="Enable authentication in gateway.auth settings",
            ))

    def _check_plaintext_credentials(self):
        import re
        cred_files = ["credentials.json", "config.json", ".env"]
        sensitive_patterns = ["api_key", "apikey", "token", "secret", "password"]
        for cred_file in cred_files:
            cred_path = self.path / cred_file
            if cred_path.exists():
                content = cred_path.read_text().lower()
                for pattern in sensitive_patterns:
                    if pattern in content:
                        self.findings.append(Finding(
                            check="Plaintext Credentials",
                            severity=Severity.CRITICAL,
                            description=f"Found potential credentials in {cred_file}",
                            fix="Use environment variables instead of config files",
                        ))
                        break

    def _check_file_permissions(self):
        sensitive_files = ["config.yaml", "credentials.json", "memory"]
        for sf in sensitive_files:
            file_path = self.path / sf
            if file_path.exists():
                mode = file_path.stat().st_mode
                if mode & 0o004:
                    label = "Config" if "config" in sf else "Memory"
                    self.findings.append(Finding(
                        check=f"World-Readable {label}",
                        severity=Severity.HIGH,
                        description=f"{sf} is readable by all users",
                        fix=f"Run: chmod 600 {file_path}",
                    ))

    def _check_tls(self):
        config = self._load_config()
        tls = config.get("gateway", {}).get("tls", {})
        if not tls.get("enabled", False):
            self.findings.append(Finding(
                check="No TLS/SSL",
                severity=Severity.HIGH,
                description="Gateway traffic is not encrypted",
                fix="Enable TLS in gateway.tls settings",
            ))

    def _check_permissive_tools(self):
        config = self._load_config()
        tools = config.get("tools", {})
        dangerous = ["shell", "bash", "exec", "run_command"]
        for tool in dangerous:
            if tools.get(tool, {}).get("enabled", False):
                if not tools.get(tool, {}).get("restrictions", []):
                    self.findings.append(Finding(
                        check="Permissive Tools",
                        severity=Severity.MEDIUM,
                        description=f"{tool} enabled without restrictions",
                        fix=f"Add restrictions to tools.{tool} in config",
                    ))

    def _check_rate_limiting(self):
        config = self._load_config()
        rate_limit = config.get("gateway", {}).get("rate_limit", {})
        if not rate_limit.get("enabled", False):
            self.findings.append(Finding(
                check="No Rate Limiting",
                severity=Severity.MEDIUM,
                description="No rate limiting configured",
                fix="Enable rate limiting in gateway.rate_limit",
            ))

    def _check_exposed_logs(self):
        log_path = self.path / "logs"
        if log_path.exists() and log_path.is_dir():
            mode = log_path.stat().st_mode
            if mode & 0o004:
                self.findings.append(Finding(
                    check="Exposed Logs",
                    severity=Severity.MEDIUM,
                    description="Log directory is world-readable",
                    fix=f"Run: chmod 700 {log_path}",
                ))

    def _check_default_port(self):
        config = self._load_config()
        port = config.get("gateway", {}).get("port", 18789)
        if port == 18789:
            self.findings.append(Finding(
                check="Default Port",
                severity=Severity.LOW,
                description="Using default port 18789 (easily scannable)",
                fix="Change to a non-default port in gateway.port",
            ))

    def to_json(self) -> str:
        return json.dumps([{
            "check": f.check,
            "severity": f.severity.value,
            "description": f.description,
            "fix": f.fix,
        } for f in self.findings], indent=2)
