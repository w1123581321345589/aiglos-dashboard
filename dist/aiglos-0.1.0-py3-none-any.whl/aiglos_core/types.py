"""
Aiglos shared types and data models.
All core data structures are defined here to avoid circular imports.
"""

from __future__ import annotations

import hashlib
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------

class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class EventType(str, Enum):
    TOOL_CALL = "tool_call"
    TOOL_RESPONSE = "tool_response"
    GOAL_DRIFT = "goal_drift"
    CREDENTIAL_DETECTED = "credential_detected"
    POLICY_VIOLATION = "policy_violation"
    ANOMALY_DETECTED = "anomaly_detected"
    SESSION_START = "session_start"
    SESSION_END = "session_end"
    SERVER_UNTRUSTED = "server_untrusted"
    BEHAVIORAL_ANOMALY = "behavioral_anomaly"
    TRUST_VIOLATION = "trust_violation"
    TOOL_REDEFINITION = "tool_redefinition"
    AGENT_ATTESTED = "agent_attested"
    COMMAND_INJECTION = "command_injection"
    PATH_TRAVERSAL = "path_traversal"


class PolicyAction(str, Enum):
    ALLOW = "allow"
    BLOCK = "block"
    LOG = "log"
    ALERT = "alert"
    REQUIRE_APPROVAL = "require_approval"


class DeploymentTier(str, Enum):
    CLOUD = "cloud"          # SaaS, CMMC L1/L2
    ON_PREM = "on_prem"      # Air-gap capable, CMMC L3
    GOV = "gov"              # FedRAMP, IL4/IL5


# ---------------------------------------------------------------------------
# Core data models
# ---------------------------------------------------------------------------

@dataclass
class AgentIdentity:
    """Cryptographic identity record for an AI agent session."""
    session_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    model_id: str = ""
    model_version: str = ""
    system_prompt_hash: str = ""
    tool_permissions: list[str] = field(default_factory=list)
    initiated_by: str = "unknown"
    timestamp: float = field(default_factory=time.time)
    attestation_hash: str = ""

    def compute_attestation(self) -> str:
        """Produce a deterministic hash over the identity fields."""
        payload = (
            f"{self.session_id}:{self.model_id}:{self.model_version}:"
            f"{self.system_prompt_hash}:{sorted(self.tool_permissions)}:"
            f"{self.initiated_by}:{self.timestamp}"
        )
        self.attestation_hash = hashlib.sha256(payload.encode()).hexdigest()
        return self.attestation_hash


@dataclass
class ToolCall:
    """A single MCP tool invocation captured by the proxy."""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    session_id: str = ""
    server_id: str = ""
    tool_name: str = ""
    arguments: dict[str, Any] = field(default_factory=dict)
    raw_payload: dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    # Set after policy evaluation
    allowed: bool = True
    blocked_reason: str | None = None
    sanitized_arguments: dict[str, Any] | None = None


@dataclass
class ToolResponse:
    """Response from an MCP tool call."""
    call_id: str = ""
    session_id: str = ""
    tool_name: str = ""
    result: Any = None
    error: str | None = None
    timestamp: float = field(default_factory=time.time)
    # Credential scan results
    secrets_detected: list[str] = field(default_factory=list)


@dataclass
class SecurityEvent:
    """A security-relevant event produced by any Aiglos subsystem."""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    session_id: str = ""
    event_type: EventType = EventType.TOOL_CALL
    severity: Severity = Severity.INFO
    title: str = ""
    description: str = ""
    details: dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    # Compliance mapping populated by the compliance module
    cmmc_controls: list[str] = field(default_factory=list)
    nist_controls: list[str] = field(default_factory=list)


@dataclass
class PolicyResult:
    """Result of evaluating a policy rule against a tool call."""
    action: PolicyAction = PolicyAction.ALLOW
    rule_name: str = ""
    reason: str = ""
    severity: Severity = Severity.INFO


@dataclass
class SessionContext:
    """Full context for an active agent session."""
    identity: AgentIdentity = field(default_factory=AgentIdentity)
    authorized_goal: str = ""
    authorized_goal_hash: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    events: list[SecurityEvent] = field(default_factory=list)
    goal_integrity_score: float = 1.0   # 1.0 = fully aligned, 0.0 = fully drifted
    anomaly_score: float = 0.0          # 0.0 = normal, 1.0 = highly anomalous
    is_active: bool = True
    start_time: float = field(default_factory=time.time)
    end_time: float | None = None

    def set_goal(self, goal: str) -> None:
        self.authorized_goal = goal
        self.authorized_goal_hash = hashlib.sha256(goal.encode()).hexdigest()


@dataclass
class ProxyConfig:
    """Runtime configuration for the MCP Security Proxy."""
    # Network
    listen_host: str = "127.0.0.1"
    listen_port: int = 8765
    upstream_host: str = "127.0.0.1"
    upstream_port: int = 18789

    # Security
    deployment_tier: DeploymentTier = DeploymentTier.CLOUD
    enable_tls: bool = False
    tls_cert_path: str | None = None
    tls_key_path: str | None = None

    # Feature flags
    enable_goal_integrity: bool = True
    enable_credential_scanning: bool = True
    enable_policy_engine: bool = True
    enable_behavioral_baseline: bool = True
    enable_attestation: bool = True
    enable_trust_registry: bool = True

    # Policy
    policy_file: str = "aiglos_policy.yaml"
    default_action: PolicyAction = PolicyAction.LOG

    # Audit
    audit_db_path: str = "aiglos_audit.db"
    log_full_payloads: bool = True

    # Alerts
    alert_webhook_url: str | None = None
    alert_slack_webhook: str | None = None

    # Goal integrity
    goal_drift_threshold: float = 0.35
    anthropic_api_key: str | None = None

    # Trust registry
    trust_file: str = "aiglos_trust.yaml"
    trust_mode: str = "audit"
