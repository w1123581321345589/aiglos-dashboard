"""
T33: Cross-Vendor Agent Identity Bridge

Extends Aiglos cryptographic attestation (T7/T8) across multi-model,
multi-vendor agent pipelines.

The problem
-----------
T7 (AttestationEngine) signs and verifies Aiglos-proxied sessions.
T8 (TrustFabric) establishes cryptographic trust chains between agents
that ALL run through Aiglos.

But production multi-agent pipelines are multi-vendor:
  Claude (Anthropic) → GPT-4o (OpenAI) → Gemini 1.5 (Google)
  AutoGen orchestrator → CrewAI subagent → LangGraph tool node

When a cross-vendor call happens, Aiglos loses the chain of custody.
A subagent downstream has no way to verify:
  - Which model actually sent this task
  - Whether the instructions were tampered with in transit
  - Whether the calling agent is authorized to delegate these capabilities

What this module does
---------------------
1. Aiglos Identity Token (AIT)
   Aiglos issues a signed JWT-compatible token at session start that
   any downstream agent or proxy can verify without running Aiglos.
   Token contains: model_id, session_id, authorized_capabilities,
   goal_hash, issuer="aiglos", exp, iat, signature (RSA-2048).

2. Cross-Vendor Verification
   When Aiglos receives a call that originates from an external agent,
   it verifies the AIT if present, or flags the call as unattested.

3. OpenID for Agents Alignment
   Maps Aiglos attestation fields to the emerging OpenID for Agents /
   OAuth 2.0 for AI Agents spec (Anthropic / Google / OpenAI joint proposal).
   This is the direct integration surface for Okta's machine identity stack.

4. Delegation Chain
   When agent A delegates to agent B, the delegation is cryptographically
   chained: AIT_B is signed by Aiglos AND contains AIT_A's fingerprint.
   Any observer can reconstruct the full delegation tree.

Integration
-----------
  from aiglos_core.proxy.identity_bridge import AgentIdentityBridge

  bridge = AgentIdentityBridge(audit_db="aiglos_audit.db")

  # Issue AIT at session start:
  token = await bridge.issue_token(
      session_id="sess-abc",
      model_id="claude-opus-4-6",
      authorized_capabilities={"read_fs", "web_search"},
      goal_hash="sha256:...",
  )

  # Verify an incoming AIT from another model:
  verdict = await bridge.verify_token(token_str=incoming_ait)

  # Create delegation for subagent:
  child_token = await bridge.delegate(
      parent_token=token,
      child_agent_id="gpt-4o-subagent",
      delegated_capabilities={"web_search"},  # subset of parent
  )

  # Map to OpenID for Agents / Okta machine identity format:
  okta_claims = bridge.to_openid_agents_claims(token)
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    import structlog
    logger = structlog.get_logger("aiglos.identity_bridge")
except ImportError:
    import logging
    logger = logging.getLogger("aiglos.identity_bridge")

# ---------------------------------------------------------------------------
# Aiglos Identity Token (AIT) structure
# ---------------------------------------------------------------------------

@dataclass
class AgentIdentityToken:
    """
    Aiglos Identity Token — a signed, portable agent identity assertion.
    JWT-compatible but uses a simplified structure for clarity.
    """
    # Identity
    iss: str = "aiglos"              # Issuer
    sub: str = ""                    # Subject: session_id
    iat: float = field(default_factory=time.time)
    exp: float = 0.0                 # Expiry (default: iat + 3600)

    # Agent identity
    model_id: str = ""               # e.g. "claude-opus-4-6", "gpt-4o", "gemini-1.5-pro"
    model_vendor: str = ""           # "anthropic" | "openai" | "google" | "meta" | "unknown"
    session_id: str = ""
    agent_version: str = ""

    # Authorization
    authorized_capabilities: list = field(default_factory=list)
    goal_hash: str = ""              # SHA-256 of authorized goal string
    goal_summary: str = ""           # Human-readable (not signed, informational)

    # Chain of custody
    parent_token_fingerprint: str = ""   # Fingerprint of parent AIT (delegation chain)
    delegation_depth: int = 0            # 0 = root orchestrator

    # Cryptographic binding
    nonce: str = ""                  # Random nonce to prevent replay
    token_fingerprint: str = ""      # SHA-256 of canonical token payload (set on sign)
    signature: str = ""              # RSA-2048 signature (set on sign)

    def is_expired(self) -> bool:
        return time.time() > self.exp

    def to_dict(self) -> dict:
        return {
            "iss": self.iss, "sub": self.sub,
            "iat": self.iat, "exp": self.exp,
            "model_id": self.model_id, "model_vendor": self.model_vendor,
            "session_id": self.session_id, "agent_version": self.agent_version,
            "authorized_capabilities": self.authorized_capabilities,
            "goal_hash": self.goal_hash, "goal_summary": self.goal_summary,
            "parent_token_fingerprint": self.parent_token_fingerprint,
            "delegation_depth": self.delegation_depth,
            "nonce": self.nonce,
            "token_fingerprint": self.token_fingerprint,
            "signature": self.signature,
        }

    def to_compact(self) -> str:
        """Produce a base64url-encoded compact representation (for HTTP headers)."""
        payload = json.dumps(self.to_dict(), separators=(",", ":"))
        return base64.urlsafe_b64encode(payload.encode()).decode().rstrip("=")

    @classmethod
    def from_compact(cls, compact: str) -> "AgentIdentityToken":
        padded = compact + "=" * (-len(compact) % 4)
        payload = json.loads(base64.urlsafe_b64decode(padded).decode())
        t = cls()
        for k, v in payload.items():
            if hasattr(t, k):
                setattr(t, k, v)
        return t


@dataclass
class VerificationVerdict:
    valid: bool
    reason: str = ""
    token: AgentIdentityToken | None = None
    trust_level: str = "unverified"   # "aiglos-signed" | "attested" | "unattested" | "invalid"
    cmmc_controls: list = field(default_factory=list)


# ---------------------------------------------------------------------------
# Vendor detection
# ---------------------------------------------------------------------------

def _infer_vendor(model_id: str) -> str:
    model_lower = model_id.lower()
    if any(x in model_lower for x in ("claude", "anthropic")):
        return "anthropic"
    if any(x in model_lower for x in ("gpt", "o1", "o3", "openai")):
        return "openai"
    if any(x in model_lower for x in ("gemini", "palm", "google")):
        return "google"
    if any(x in model_lower for x in ("llama", "meta")):
        return "meta"
    if any(x in model_lower for x in ("mistral", "mixtral")):
        return "mistral"
    return "unknown"


# ---------------------------------------------------------------------------
# OpenID for Agents claim mapping
# ---------------------------------------------------------------------------

OPENID_AGENTS_CLAIM_MAP = {
    # AIT field          → OpenID for Agents / OAuth claim
    "model_id":           "agent_model",
    "model_vendor":       "agent_vendor",
    "session_id":         "agent_session_id",
    "authorized_capabilities": "scope",
    "goal_hash":          "agent_goal_hash",
    "delegation_depth":   "agent_delegation_depth",
    "parent_token_fingerprint": "agent_parent_jti",
    "token_fingerprint":  "jti",
    "iss":                "iss",
    "sub":                "sub",
    "iat":                "iat",
    "exp":                "exp",
}


class AgentIdentityBridge:
    """
    Issues, verifies, and delegates Aiglos Identity Tokens across
    multi-vendor agent pipelines. Maps to OpenID for Agents / Okta
    machine identity standards.
    """

    TOKEN_TTL_SECONDS = 3600    # 1 hour default

    def __init__(
        self,
        audit_db: str = "aiglos_audit.db",
        private_key_path: str = "aiglos_identity.key",
        public_key_path: str = "aiglos_identity.pub",
    ):
        self.audit_db = audit_db
        self.private_key_path = private_key_path
        self.public_key_path = public_key_path
        self._private_key = None
        self._public_key = None
        self._token_store: dict[str, AgentIdentityToken] = {}  # fingerprint → token
        self._n = 0

    def _fid(self) -> str:
        self._n += 1
        return f"ait-{self._n:05d}"

    def _load_or_generate_keys(self) -> tuple:
        """Load RSA keys or generate new ones if not present."""
        try:
            from cryptography.hazmat.primitives import serialization
            from cryptography.hazmat.primitives.asymmetric import rsa, padding
            from cryptography.hazmat.backends import default_backend

            priv_path = Path(self.private_key_path)
            pub_path = Path(self.public_key_path)

            if priv_path.exists() and pub_path.exists():
                with priv_path.open("rb") as f:
                    private_key = serialization.load_pem_private_key(f.read(), password=None)
                with pub_path.open("rb") as f:
                    public_key = serialization.load_pem_public_key(f.read())
                return private_key, public_key

            # Generate new key pair
            private_key = rsa.generate_private_key(
                public_exponent=65537, key_size=2048, backend=default_backend()
            )
            public_key = private_key.public_key()

            priv_path.write_bytes(private_key.private_bytes(
                serialization.Encoding.PEM,
                serialization.PrivateFormat.TraditionalOpenSSL,
                serialization.NoEncryption(),
            ))
            pub_path.write_bytes(public_key.public_bytes(
                serialization.Encoding.PEM,
                serialization.PublicFormat.SubjectPublicKeyInfo,
            ))
            logger.info("identity_bridge_keys_generated")
            return private_key, public_key

        except ImportError:
            return None, None

    def _sign_payload(self, payload: str) -> str:
        """Sign a payload string. Returns hex signature or HMAC fallback."""
        try:
            from cryptography.hazmat.primitives import hashes, serialization
            from cryptography.hazmat.primitives.asymmetric import padding
            if self._private_key is None:
                self._private_key, self._public_key = self._load_or_generate_keys()
            if self._private_key:
                sig = self._private_key.sign(
                    payload.encode(),
                    padding.PKCS1v15(),
                    hashes.SHA256(),
                )
                return sig.hex()
        except Exception:
            pass
        # Fallback: HMAC-SHA256 with nonce-derived key (no external dep)
        import hmac as _hmac
        key = hashlib.sha256(os.urandom(32)).digest()
        return _hmac.new(key, payload.encode(), hashlib.sha256).hexdigest()

    def _verify_signature(self, payload: str, signature_hex: str, public_key=None) -> bool:
        """Verify a payload signature."""
        try:
            from cryptography.hazmat.primitives import hashes, serialization
            from cryptography.hazmat.primitives.asymmetric import padding
            pk = public_key or self._public_key
            if pk is None:
                self._private_key, self._public_key = self._load_or_generate_keys()
                pk = self._public_key
            if pk:
                pk.verify(
                    bytes.fromhex(signature_hex),
                    payload.encode(),
                    padding.PKCS1v15(),
                    hashes.SHA256(),
                )
                return True
        except Exception:
            pass
        return False

    # ------------------------------------------------------------------
    # Token issuance
    # ------------------------------------------------------------------

    async def issue_token(
        self,
        session_id: str,
        model_id: str,
        authorized_capabilities: set[str] | list[str] | None = None,
        goal_hash: str = "",
        goal_summary: str = "",
        ttl: int | None = None,
        parent_token: AgentIdentityToken | None = None,
    ) -> AgentIdentityToken:
        """Issue a new Aiglos Identity Token for an agent session."""
        now = time.time()
        nonce = hashlib.sha256(os.urandom(16)).hexdigest()[:16]
        caps = sorted(authorized_capabilities or [])

        token = AgentIdentityToken(
            iss="aiglos",
            sub=session_id,
            iat=now,
            exp=now + (ttl or self.TOKEN_TTL_SECONDS),
            model_id=model_id,
            model_vendor=_infer_vendor(model_id),
            session_id=session_id,
            authorized_capabilities=caps,
            goal_hash=goal_hash,
            goal_summary=goal_summary,
            nonce=nonce,
            delegation_depth=(parent_token.delegation_depth + 1) if parent_token else 0,
            parent_token_fingerprint=parent_token.token_fingerprint if parent_token else "",
        )

        # Canonical payload for signing (excludes signature field)
        canonical = json.dumps({
            k: v for k, v in token.to_dict().items()
            if k not in ("signature", "token_fingerprint")
        }, sort_keys=True, separators=(",", ":"))

        token.token_fingerprint = hashlib.sha256(canonical.encode()).hexdigest()
        token.signature = self._sign_payload(canonical)

        self._token_store[token.token_fingerprint] = token

        await self._log_issuance(token)
        logger.info("ait_issued",
                    session_id=session_id[:8],
                    model=model_id,
                    caps=len(caps),
                    depth=token.delegation_depth)
        return token

    # ------------------------------------------------------------------
    # Token verification
    # ------------------------------------------------------------------

    async def verify_token(
        self,
        token: AgentIdentityToken | None = None,
        token_str: str | None = None,
    ) -> VerificationVerdict:
        """Verify an incoming AIT. Accepts token object or compact string."""
        if token_str:
            try:
                token = AgentIdentityToken.from_compact(token_str)
            except Exception as e:
                return VerificationVerdict(
                    valid=False, reason=f"Token parse error: {e}",
                    trust_level="invalid",
                    cmmc_controls=["3.5.1"],
                )

        if token is None:
            return VerificationVerdict(
                valid=False, reason="No token provided",
                trust_level="unattested",
                cmmc_controls=["3.5.1"],
            )

        # Expiry check
        if token.is_expired():
            return VerificationVerdict(
                valid=False,
                reason=f"Token expired at {token.exp} (now {time.time():.0f})",
                trust_level="invalid",
                cmmc_controls=["3.5.1"],
            )

        # Issuer check
        if token.iss != "aiglos":
            # External token — flag as unattested, don't reject outright
            return VerificationVerdict(
                valid=True,
                reason=f"Token from external issuer '{token.iss}' — unattested by Aiglos.",
                trust_level="unattested",
                token=token,
                cmmc_controls=["3.5.1", "3.13.8"],
            )

        # Signature verification
        canonical = json.dumps({
            k: v for k, v in token.to_dict().items()
            if k not in ("signature", "token_fingerprint")
        }, sort_keys=True, separators=(",", ":"))

        expected_fp = hashlib.sha256(canonical.encode()).hexdigest()
        if expected_fp != token.token_fingerprint:
            return VerificationVerdict(
                valid=False,
                reason="Token fingerprint mismatch — payload may have been tampered.",
                trust_level="invalid",
                cmmc_controls=["3.5.1", "3.13.8"],
            )

        sig_valid = self._verify_signature(canonical, token.signature)

        return VerificationVerdict(
            valid=sig_valid,
            reason="Valid Aiglos-signed token" if sig_valid else "Signature verification failed",
            trust_level="aiglos-signed" if sig_valid else "invalid",
            token=token,
            cmmc_controls=["3.5.1", "3.13.8"],
        )

    # ------------------------------------------------------------------
    # Delegation
    # ------------------------------------------------------------------

    async def delegate(
        self,
        parent_token: AgentIdentityToken,
        child_agent_id: str,
        delegated_capabilities: set[str] | None = None,
        child_model_id: str = "unknown",
        ttl: int | None = None,
    ) -> AgentIdentityToken:
        """
        Create a child AIT with a subset of the parent's capabilities.
        Delegation is always strictly downward — child cannot exceed parent scope.
        """
        parent_caps = set(parent_token.authorized_capabilities)
        requested = set(delegated_capabilities or parent_caps)

        # Enforce capability subsetting
        granted = requested & parent_caps
        if requested - parent_caps:
            logger.warning("ait_delegation_excess_caps_rejected",
                           excess=list(requested - parent_caps))

        return await self.issue_token(
            session_id=f"{parent_token.session_id}::{child_agent_id}",
            model_id=child_model_id,
            authorized_capabilities=granted,
            goal_hash=parent_token.goal_hash,
            goal_summary=f"[delegated] {parent_token.goal_summary}",
            ttl=ttl or int(parent_token.exp - time.time()),
            parent_token=parent_token,
        )

    # ------------------------------------------------------------------
    # OpenID for Agents / Okta mapping
    # ------------------------------------------------------------------

    def to_openid_agents_claims(self, token: AgentIdentityToken) -> dict:
        """
        Map an AIT to OpenID for Agents / OAuth 2.0 claims format.
        This is the direct integration surface for Okta machine identity.
        """
        claims: dict[str, Any] = {}
        token_dict = token.to_dict()
        for ait_field, oidc_claim in OPENID_AGENTS_CLAIM_MAP.items():
            val = token_dict.get(ait_field)
            if val is not None:
                claims[oidc_claim] = val

        # scope: convert capability list to space-separated OAuth scope string
        if "scope" in claims and isinstance(claims["scope"], list):
            claims["scope"] = " ".join(sorted(claims["scope"]))

        # Standard OIDC fields
        claims["token_type"] = "aiglos_identity_token"
        claims["aiglos_delegation_chain"] = (
            token.parent_token_fingerprint[:12] + "..."
            if token.parent_token_fingerprint else "root"
        )

        return claims

    def from_openid_agents_claims(self, claims: dict) -> AgentIdentityToken:
        """
        Construct an AIT from OpenID for Agents claims (for inbound token parsing).
        Marks the token as externally issued (trust_level will be 'unattested').
        """
        caps = claims.get("scope", "")
        if isinstance(caps, str):
            caps = caps.split()

        return AgentIdentityToken(
            iss=claims.get("iss", "external"),
            sub=claims.get("sub", ""),
            iat=float(claims.get("iat", time.time())),
            exp=float(claims.get("exp", time.time() + 3600)),
            model_id=claims.get("agent_model", "unknown"),
            model_vendor=claims.get("agent_vendor", _infer_vendor(claims.get("agent_model", ""))),
            session_id=claims.get("agent_session_id", claims.get("sub", "")),
            authorized_capabilities=caps,
            goal_hash=claims.get("agent_goal_hash", ""),
            token_fingerprint=claims.get("jti", ""),
            parent_token_fingerprint=claims.get("agent_parent_jti", ""),
            delegation_depth=int(claims.get("agent_delegation_depth", 0)),
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    async def _log_issuance(self, token: AgentIdentityToken) -> None:
        try:
            from aiglos_core.audit import AuditLog
            from aiglos_core.types import SecurityEvent, EventType, Severity
            audit = AuditLog(self.audit_db)
            audit.record_event(SecurityEvent(
                session_id=token.session_id,
                event_type=EventType.AGENT_ATTESTED,
                severity=Severity.LOW,
                title=f"AIT issued: {token.model_id} (depth={token.delegation_depth})",
                description=(
                    f"Aiglos Identity Token issued for model '{token.model_id}' "
                    f"(vendor: {token.model_vendor}), "
                    f"capabilities: {', '.join(token.authorized_capabilities[:5])}"
                ),
                details={
                    "token_fingerprint": token.token_fingerprint[:16],
                    "model_vendor": token.model_vendor,
                    "delegation_depth": token.delegation_depth,
                    "caps_count": len(token.authorized_capabilities),
                },
                cmmc_controls=["3.5.1", "3.13.8", "3.5.3"],
            ))
        except Exception as e:
            logger.debug("ait_log_failed", error=str(e))
