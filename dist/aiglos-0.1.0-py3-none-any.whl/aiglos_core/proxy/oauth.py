"""
T25: OAuth Confused Deputy Detector

Detects OAuth 2.0 "confused deputy" vulnerabilities specific to MCP proxy
servers. References:

  CVE-2025-6514 (CVSS 9.6)
    mcp-remote versions 0.0.5-0.1.15. First documented full RCE in
    real-world MCP. An attacker obtains authorization codes for other
    users by exploiting the combination of:
      - Static client ID used by the MCP proxy with third-party auth server
      - Dynamic client registration allowed for MCP clients
      - Consent cookie set by the third-party auth server after first auth
      - Missing per-client consent before forwarding to third-party

  MCP Spec Confused Deputy (OWASP Agentic #5 draft)
    When a proxy server uses one static OAuth client to represent all
    MCP clients, any client that completes the first OAuth dance can
    receive tokens issued for a different client's resources.

Three detection surfaces
------------------------
  1. Config Scanner  — reads aiglos_policy.yaml and MCP server configs
     looking for static client ID patterns and mcp-remote version strings.

  2. Flow Analyzer   — reads OAuth-related events from the audit DB and
     looks for: token reuse across sessions with different identity hashes,
     authorization codes presented after abnormal time gaps, scope escalation
     between a client's first and subsequent OAuth calls.

  3. Live Hook       — called from proxy.__init__ on each incoming OAuth
     callback. Returns an OAuthVerdict that the proxy can act on synchronously.

Integration
-----------
  # From your proxy intercept layer:
  from aiglos_core.proxy.oauth import OAuthConfusedDeputy, OAuthEvent
  detector = OAuthConfusedDeputy(audit_db="aiglos_audit.db")

  # On each OAuth callback:
  event = OAuthEvent(session_id=..., client_id=..., scopes=[...], token_hash=...)
  verdict = await detector.evaluate(event)
  if not verdict.allowed:
      raise SecurityError(verdict.reason)

  # Autonomous hunt cycle:
  findings = await detector.scan()
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import structlog

logger = structlog.get_logger("aiglos.oauth")

# ---------------------------------------------------------------------------
# CVE-2025-6514: mcp-remote vulnerable version pattern
# ---------------------------------------------------------------------------

MREMOTE_VULN_RE = re.compile(
    r"mcp-remote[^0-9]{0,10}(?:0\.0\.[0-9]|0\.1\.[0-9]|0\.1\.1[0-5])(?:[^0-9]|$)"
)

# Suspicious static client ID patterns (generic placeholders commonly copy-pasted)
STATIC_CLIENT_ID_RE = re.compile(
    r"(?i)client.?id[^a-z0-9]{0,10}(your.client.id|mcp.proxy|proxy.client|static.client|"
    r"mcp-server-[a-z]+|placeholder|changeme|todo|xxx)",
    re.IGNORECASE,
)



# Overly broad OAuth scopes that indicate misconfiguration
BROAD_SCOPE_RE = re.compile(
    r"(?i)(?:files:\*|db:\*|admin:\*|:write|:delete|:admin|"
    r"full[._]access|all[._]access|\*:\*|openid profile email offline_access)"
)

# Token patterns to detect harvested OAuth tokens in tool call arguments
OAUTH_TOKEN_IN_ARGS_RE = re.compile(
    r"(?i)(bearer\s+[a-z0-9\-_\.]{20,}|"
    r"access_token['\"]?\s*[:=]\s*['\"]?[a-z0-9\-_\.]{20,}|"
    r"ya29\.[a-z0-9\-_]{30,}|"           # Google OAuth
    r"eyJ[a-z0-9\-_]{20,}\.eyJ[a-z0-9\-_\.]+)"  # JWT
)


@dataclass
class OAuthEvent:
    """Represents a single OAuth callback or token event observed by the proxy."""
    session_id: str
    client_id: str
    scopes: list[str]
    token_hash: str = ""
    identity_hash: str = ""
    timestamp: float = field(default_factory=time.time)
    server_id: str = ""
    extra: dict = field(default_factory=dict)


@dataclass
class OAuthVerdict:
    """Real-time verdict returned by OAuthConfusedDeputy.evaluate()."""
    allowed: bool
    reason: str = ""
    severity: str = "medium"
    finding_id: str = ""
    cmmc_controls: list = field(default_factory=list)


@dataclass
class OAuthFinding:
    id: str
    vector: str
    severity: str
    title: str
    description: str
    session_id: str
    evidence: dict = field(default_factory=dict)
    remediation: str = ""
    cmmc_controls: list = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)


class OAuthConfusedDeputy:
    """
    Detects OAuth confused deputy and CVE-2025-6514 patterns in MCP deployments.
    """

    def __init__(
        self,
        audit_db: str = "aiglos_audit.db",
        config_paths: list[str] | None = None,
    ):
        self.audit_db = audit_db
        self.config_paths = config_paths or [
            "aiglos_policy.yaml",
            "aiglos_trust.yaml",
            ".claude/mcp_settings.json",
            "claude_desktop_config.json",
        ]
        self._n = 0
        # token_hash -> (session_id, identity_hash, timestamp)
        self._token_registry: dict[str, tuple[str, str, float]] = {}
        # client_id -> set of scopes seen
        self._scope_registry: dict[str, set[str]] = {}

    def _fid(self) -> str:
        self._n += 1
        return f"oauth-{self._n:05d}"

    # ------------------------------------------------------------------
    # Real-time evaluation hook (called from proxy)
    # ------------------------------------------------------------------

    async def evaluate(self, event: OAuthEvent) -> OAuthVerdict:
        """
        Synchronous-friendly real-time evaluation of an incoming OAuth event.
        Returns a verdict the proxy can act on immediately.
        """
        # Vector: token reuse across sessions with different identities
        if event.token_hash and event.token_hash in self._token_registry:
            prior_session, prior_identity, _ = self._token_registry[event.token_hash]
            if (prior_session != event.session_id and
                    event.identity_hash and
                    event.identity_hash != prior_identity):
                return OAuthVerdict(
                    allowed=False,
                    reason=(
                        f"Token hash {event.token_hash[:12]}... previously seen in "
                        f"session {prior_session[:8]} with a different identity. "
                        f"Possible confused deputy: one client consuming tokens "
                        f"issued for another."
                    ),
                    severity="critical",
                    cmmc_controls=["3.5.1", "3.5.2", "3.13.10"],
                )

        # Vector: broad scopes on first presentation
        current_scopes = set(event.scopes)
        if any(BROAD_SCOPE_RE.search(s) for s in event.scopes):
            return OAuthVerdict(
                allowed=False,
                reason=(
                    f"Client {event.client_id} requested overly broad OAuth scopes: "
                    f"{', '.join(event.scopes[:5])}. "
                    f"Broad scopes increase confused deputy impact. "
                    f"Request minimum necessary scopes."
                ),
                severity="high",
                cmmc_controls=["3.1.1", "3.13.10"],
            )

        # Vector: scope escalation from prior call
        if event.client_id in self._scope_registry:
            prior_scopes = self._scope_registry[event.client_id]
            new_scopes = current_scopes - prior_scopes
            if new_scopes:
                return OAuthVerdict(
                    allowed=False,
                    reason=(
                        f"Client {event.client_id} is requesting new OAuth scopes "
                        f"not present in prior authorization: {new_scopes}. "
                        f"Possible scope escalation attack."
                    ),
                    severity="high",
                    cmmc_controls=["3.1.1", "3.5.3"],
                )

        # Register for future comparison
        if event.token_hash:
            self._token_registry[event.token_hash] = (
                event.session_id, event.identity_hash, event.timestamp
            )
        self._scope_registry.setdefault(event.client_id, set()).update(current_scopes)

        return OAuthVerdict(allowed=True, reason="OAuth event cleared")

    # ------------------------------------------------------------------
    # Autonomous scan (called from hunt cycle)
    # ------------------------------------------------------------------

    async def scan(self) -> list[OAuthFinding]:
        """Full autonomous scan: config + audit DB."""
        findings: list[OAuthFinding] = []
        findings.extend(await self._scan_configs())
        findings.extend(await self._scan_audit_db())
        if findings:
            await self._persist(findings)
        return findings

    async def _scan_configs(self) -> list[OAuthFinding]:
        """Scan config files for CVE-2025-6514 and static client ID patterns."""
        findings = []
        for path_str in self.config_paths:
            path = Path(path_str)
            if not path.exists():
                continue
            try:
                content = path.read_text(errors="replace")
            except Exception:
                continue

            # CVE-2025-6514: vulnerable mcp-remote version
            if MREMOTE_VULN_RE.search(content):
                findings.append(OAuthFinding(
                    id=self._fid(),
                    vector="cve_2025_6514",
                    severity="critical",
                    title="CVE-2025-6514: Vulnerable mcp-remote version detected",
                    description=(
                        f"Config file '{path_str}' references mcp-remote in a "
                        f"version range (0.0.5-0.1.15) affected by CVE-2025-6514 "
                        f"(CVSS 9.6). This vulnerability enables OS command injection "
                        f"when connecting to an untrusted MCP server. Upgrade to "
                        f"mcp-remote >= 0.1.16 immediately."
                    ),
                    session_id="config-scan",
                    evidence={"file": path_str, "cve": "CVE-2025-6514"},
                    remediation="npm update mcp-remote  # or pin >= 0.1.16 in package.json",
                    cmmc_controls=["3.14.2", "3.14.1"],
                ))

            # Static client ID
            if STATIC_CLIENT_ID_RE.search(content):
                findings.append(OAuthFinding(
                    id=self._fid(),
                    vector="static_client_id",
                    severity="high",
                    title="Static OAuth client ID pattern in MCP config",
                    description=(
                        f"Config '{path_str}' appears to use a static or placeholder "
                        f"OAuth client ID. When the MCP proxy shares one static client ID "
                        f"across all MCP clients, the confused deputy attack becomes possible: "
                        f"a single authorization dance grants tokens that can be replayed "
                        f"for other clients."
                    ),
                    session_id="config-scan",
                    evidence={"file": path_str},
                    remediation=(
                        "Issue a unique OAuth client ID per MCP client. "
                        "Implement per-client consent verification before forwarding "
                        "authorization codes to the third-party auth server."
                    ),
                    cmmc_controls=["3.5.1", "3.5.2", "3.13.10"],
                ))

        return findings

    async def _scan_audit_db(self) -> list[OAuthFinding]:
        """Scan audit DB for OAuth token harvest and flow anomalies."""
        findings = []
        try:
            from aiglos_core.audit import AuditLog
            audit = AuditLog(self.audit_db)
            events = audit.get_recent_events(limit=2000)
        except Exception as e:
            logger.debug("oauth_audit_load_failed", error=str(e))
            return findings

        # Look for OAuth tokens appearing in tool call arguments
        # (they should never be there if scopes and secrets are handled correctly)
        for ev in events:
            details = ev.get("details") or {}
            if isinstance(details, str):
                try:
                    details = json.loads(details)
                except Exception:
                    details = {"raw": details}

            args_str = str(details.get("arguments", "")) + str(details.get("result", ""))
            if OAUTH_TOKEN_IN_ARGS_RE.search(args_str):
                session_id = ev.get("session_id", "?")
                findings.append(OAuthFinding(
                    id=self._fid(),
                    vector="token_in_args",
                    severity="critical",
                    title="OAuth token exposed in MCP tool call arguments",
                    description=(
                        f"Session {session_id[:8]} has an OAuth token appearing "
                        f"directly in tool call arguments or results. "
                        f"This matches the CVE-2025-6514 / Gmail MCP token harvest "
                        f"pattern where a compromised MCP server extracts stored "
                        f"OAuth tokens for all connected services."
                    ),
                    session_id=session_id,
                    evidence={"session_id": session_id, "event_type": ev.get("event_type")},
                    remediation=(
                        "Revoke affected OAuth tokens immediately. "
                        "Audit all services the MCP server had access to. "
                        "Block the originating MCP server fingerprint."
                    ),
                    cmmc_controls=["3.13.10", "3.5.3", "3.14.2"],
                ))

        return findings

    # ------------------------------------------------------------------
    # Persist
    # ------------------------------------------------------------------

    async def _persist(self, findings: list[OAuthFinding]) -> None:
        try:
            from aiglos_core.audit import AuditLog
            from aiglos_core.types import SecurityEvent, EventType, Severity
            audit = AuditLog(self.audit_db)
            smap = {
                "critical": Severity.CRITICAL,
                "high": Severity.HIGH,
                "medium": Severity.MEDIUM,
            }
            for f in findings:
                audit.record_event(SecurityEvent(
                    session_id=f.session_id,
                    event_type=EventType.POLICY_VIOLATION,
                    severity=smap.get(f.severity, Severity.HIGH),
                    title=f.title,
                    description=f.description,
                    details=f.evidence,
                    cmmc_controls=f.cmmc_controls,
                ))
        except Exception as e:
            logger.debug("oauth_persist_failed", error=str(e))
