"""Aiglos Core -- AI Agent Security Runtime."""

__version__ = "0.1.0"
__author__ = "Aiglos"
