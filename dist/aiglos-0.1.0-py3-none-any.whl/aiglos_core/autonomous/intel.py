"""Aiglos Threat Intelligence - autonomous CVE/OWASP feed ingestion."""
from __future__ import annotations
import asyncio, hashlib, json, re, time
from dataclasses import dataclass, field
from pathlib import Path
import structlog

logger = structlog.get_logger("aiglos.intel")

@dataclass
class ThreatIndicator:
    id: str; source: str; threat_type: str; severity: str
    title: str; description: str; cve_id: str = ""
    affected_tools: list = field(default_factory=list)
    policy_rule: dict | None = None; server_fingerprint: str = ""
    received_at: float = field(default_factory=time.time)
    applied: bool = False; cmmc_controls: list = field(default_factory=list)

@dataclass
class IntelRefreshResult:
    new_indicators: int; new_policy_rules: int; new_blocked_servers: int
    sources_checked: list; errors: list; refresh_duration_s: float
    timestamp: float = field(default_factory=time.time)

KNOWN_THREAT_PATTERNS = [
    {"id": "tp-001", "source": "internal", "threat_type": "attack_pattern",
     "severity": "critical", "title": "MCP Tool Poisoning via Hidden System Prompt",
     "description": "Attacker embeds hidden instructions in MCP tool descriptions.",
     "policy_rule": {"name": "block_tool_description_injection",
                     "description": "Block tool calls with prompt injection patterns",
                     "match": {"argument_pattern": r"(?i)(ignore previous|disregard|new instruction|system:\s*\[|<\|system\|>|{{SYSTEM|OVERRIDE:|IGNORE ABOVE)"},
                     "action": "block", "severity": "critical"},
     "cmmc_controls": ["3.14.2", "3.13.1"]},
    {"id": "tp-002", "source": "internal", "threat_type": "attack_pattern",
     "severity": "high", "title": "MCP Preference Manipulation Attack (MPMA)",
     "description": "Attacker subtly alters agent tool ranking to redirect to malicious implementations.",
     "policy_rule": {"name": "alert_tool_ranking_shift",
                     "description": "Alert on consistent selection of non-default tool variants",
                     "match": {"tool": "*_alt"}, "action": "alert", "severity": "high"},
     "cmmc_controls": ["3.13.1", "3.14.2"]},
    {"id": "tp-003", "source": "nvd", "cve_id": "CVE-2025-53773",
     "threat_type": "cve", "severity": "critical",
     "title": "GitHub Copilot YOLO Mode RCE via Prompt Injection",
     "description": "RCE through prompt injection in GitHub Copilot YOLO mode.",
     "policy_rule": {"name": "block_yolo_mode_rce",
                     "description": "Block RCE patterns associated with YOLO mode exploitation (CVE-2025-53773)",
                     "match": {"argument_pattern": r"(?i)(yolo|--dangerously-skip-permissions|auto.?approve|no.?confirm)\s*(mode|flag|enabled)"},
                     "action": "block", "severity": "critical"},
     "cmmc_controls": ["3.14.2", "3.1.1"]},
    {"id": "tp-004", "source": "nvd", "cve_id": "CVE-2025-54135",
     "threat_type": "cve", "severity": "critical",
     "title": "Cursor RCE via MCP Auto-Start Config Poisoning",
     "description": "RCE through MCP auto-start and config poisoning in Cursor IDE.",
     "policy_rule": {"name": "block_mcp_config_write",
                     "description": "Block writes to MCP server config files (CVE-2025-54135)",
                     "match": {"tool": "write_file", "argument_pattern": r"(?i)(\.mcp|mcp\.json|mcpconfig|mcp_servers\.json)"},
                     "action": "block", "severity": "critical"},
     "cmmc_controls": ["3.14.2", "3.13.1", "3.1.1"]},
    {"id": "tp-005", "source": "owasp", "threat_type": "attack_pattern",
     "severity": "high", "title": "OWASP Agentic Top 10 #1: Prompt Injection via Tool Response",
     "description": "Malicious content in tool responses hijacks subsequent agent actions.",
     "policy_rule": {"name": "alert_prompt_injection_in_response",
                     "description": "Alert on tool responses with instruction-like content",
                     "match": {"argument_pattern": r"(?i)(you should now|next you must|as an ai|ignore your|forget your previous|act as|roleplay as)"},
                     "action": "alert", "severity": "high"},
     "cmmc_controls": ["3.14.2"]},
    {"id": "tp-006", "source": "owasp", "threat_type": "attack_pattern",
     "severity": "high", "title": "OWASP Agentic Top 10 #2: Covert Tool Invocation",
     "description": "Agent invokes tools not consistent with stated goal.",
     "policy_rule": {"name": "alert_covert_exfil_pattern",
                     "description": "Block data exfiltration to known exfil services",
                     "match": {"tool": "http_request", "argument_pattern": r"(?i)(exfil|paste\.ee|pastebin|transfer\.sh|ngrok|burp\.suite|requestbin)"},
                     "action": "block", "severity": "critical"},
     "cmmc_controls": ["3.13.1", "3.14.2"]},
    {"id": "tp-007", "source": "internal", "threat_type": "attack_pattern",
     "severity": "critical", "title": "OAuth Token Harvest via MCP Server Compromise",
     "description": "Compromised MCP server harvests stored OAuth tokens.",
     "policy_rule": {"name": "block_oauth_token_access",
                     "description": "Block access to OAuth credential storage files",
                     "match": {"argument_pattern": r"(?i)(oauth_token|access_token|refresh_token|\.oauth|token_cache|gcloud/credentials)"},
                     "action": "block", "severity": "critical"},
     "cmmc_controls": ["3.13.10", "3.13.1"]},
    {"id": "tp-008", "source": "internal", "threat_type": "attack_pattern",
     "severity": "high", "title": "Unicode Steganography in Tool Arguments",
     "description": "Hidden instructions using invisible Unicode characters.",
     "policy_rule": {"name": "block_unicode_steganography",
                     "description": "Block tool calls containing invisible Unicode characters",
                     "match": {"argument_pattern": "[\u200b\u200c\u200d\u200e\u200f\u202a-\u202e\u2060-\u2069\ufeff]"},
                     "action": "block", "severity": "high"},
     "cmmc_controls": ["3.14.2", "3.13.1"]},
    {"id": "tp-009", "source": "supply_chain", "threat_type": "supply_chain",
     "severity": "critical", "title": "MCP Supply Chain: Package Impersonation",
     "description": "Malicious NPM/PyPI packages impersonating legitimate MCP servers.",
     "indicators": ["postmark-mcp-server", "mcp-postmark"],
     "cmmc_controls": ["3.14.2", "3.14.1"]},
    {"id": "tp-010", "source": "supply_chain", "threat_type": "supply_chain",
     "severity": "critical", "title": "MCP Supply Chain: Build Config Path Traversal",
     "description": "Build configs with path traversal allow arbitrary file read.",
     "indicators": ["smithery.yaml", "../../../"],
     "cmmc_controls": ["3.14.2", "3.13.1"]},
]

KNOWN_MALICIOUS_FINGERPRINTS = [
    {"fingerprint": "00000000000000000000000000000000000000000000000000000000deadbeef",
     "alias": "test-malicious-server",
     "reason": "Example malicious server fingerprint for testing",
     "reported_by": "aiglos-internal"},
]

class ThreatIntelligence:
    def __init__(self, policy_file="aiglos_policy.yaml", trust_file="aiglos_trust.yaml",
                 intel_cache_path="aiglos_intel_cache.json",
                 enable_nvd_feed=True, enable_community_feed=True):
        self.policy_file = Path(policy_file); self.trust_file = Path(trust_file)
        self.intel_cache = Path(intel_cache_path)
        self.enable_nvd = enable_nvd_feed; self.enable_community = enable_community_feed
        self._indicators: list[ThreatIndicator] = []
        self._applied_ids: set[str] = set()
        self._load_cache()
        if not self._indicators:
            self._seed_builtin_patterns()

    def _seed_builtin_patterns(self):
        for raw in KNOWN_THREAT_PATTERNS:
            self._indicators.append(ThreatIndicator(
                id=raw["id"], source=raw["source"], threat_type=raw["threat_type"],
                severity=raw["severity"], title=raw["title"], description=raw["description"],
                cve_id=raw.get("cve_id", ""), policy_rule=raw.get("policy_rule"),
                cmmc_controls=raw.get("cmmc_controls", []),
            ))
        logger.info("intel_seeded", count=len(KNOWN_THREAT_PATTERNS))

    async def refresh(self):
        start = time.monotonic(); errors = []; sources_checked = []
        new_indicators = new_rules = new_blocked = 0
        logger.info("intel_refresh_started")
        if self.enable_nvd:
            try:
                new_indicators += await self._check_nvd_feed()
                sources_checked.append("nvd")
            except Exception as e: errors.append(f"NVD: {e}")
        if self.enable_community:
            try:
                new_indicators += await self._check_community_feed()
                sources_checked.append("community")
            except Exception as e: errors.append(f"community: {e}")
        try:
            rules, blocked = await self._apply_new_indicators()
            new_rules += rules; new_blocked += blocked
        except Exception as e: errors.append(f"apply: {e}")
        try:
            sca_count = await self._run_sca_scan()
            if sca_count:
                sources_checked.append(f"sca({sca_count})")
        except Exception as e: errors.append(f"sca: {e}")
        try:
            reg_count = await self._run_registry_scan()
            if reg_count:
                sources_checked.append(f"registry({reg_count})")
        except Exception as e: errors.append(f"registry: {e}")
        self._save_cache()
        elapsed = time.monotonic() - start
        logger.info("intel_refresh_complete", new_indicators=new_indicators,
                    new_rules=new_rules, duration_s=elapsed)
        return IntelRefreshResult(new_indicators=new_indicators, new_policy_rules=new_rules,
                                  new_blocked_servers=new_blocked, sources_checked=sources_checked,
                                  errors=errors, refresh_duration_s=round(elapsed, 2))

    async def _check_nvd_feed(self):
        await asyncio.sleep(0)
        return 0

    async def _check_community_feed(self):
        await asyncio.sleep(0)
        known_fps = {i.server_fingerprint for i in self._indicators if i.server_fingerprint}
        new_count = 0
        for entry in KNOWN_MALICIOUS_FINGERPRINTS:
            if entry["fingerprint"] not in known_fps:
                self._indicators.append(ThreatIndicator(
                    id=f"cf-{hashlib.sha256(entry['fingerprint'].encode()).hexdigest()[:8]}",
                    source="community", threat_type="malicious_server", severity="critical",
                    title=f"Known malicious MCP server: {entry['alias']}",
                    description=entry["reason"], server_fingerprint=entry["fingerprint"],
                    cmmc_controls=["3.13.1", "3.1.1"],
                ))
                new_count += 1
        return new_count

    async def _apply_new_indicators(self):
        new_rules = new_blocked = 0
        for indicator in self._indicators:
            if indicator.id in self._applied_ids: continue
            if indicator.policy_rule:
                if await self._add_policy_rule(indicator): new_rules += 1
            if indicator.server_fingerprint:
                if await self._block_server_fingerprint(indicator): new_blocked += 1
            indicator.applied = True; self._applied_ids.add(indicator.id)
        return new_rules, new_blocked

    async def _add_policy_rule(self, indicator):
        try:
            import yaml
            rule = {**indicator.policy_rule, "_source": indicator.source,
                    "_indicator_id": indicator.id, "_cmmc_controls": indicator.cmmc_controls}
            if indicator.cve_id: rule["_cve_id"] = indicator.cve_id
            data = yaml.safe_load(self.policy_file.read_text()) if self.policy_file.exists() else {}
            policies = data.get("policies", [])
            if rule.get("name") in {p.get("name") for p in policies}: return False
            policies.append(rule); data["policies"] = policies
            self.policy_file.write_text(yaml.dump(data, default_flow_style=False))
            logger.info("policy_rule_added", rule_name=rule.get("name"))
            return True
        except Exception as e:
            logger.warning("policy_rule_add_failed", error=str(e)); return False

    async def _block_server_fingerprint(self, indicator):
        try:
            import yaml
            data = yaml.safe_load(self.trust_file.read_text()) if self.trust_file.exists() else \
                   {"aiglos_trust": "1.0", "mode": "audit", "servers": []}
            servers = data.get("servers", [])
            if indicator.server_fingerprint in {s.get("fingerprint") for s in servers}: return False
            servers.append({"status": "blocked", "fingerprint": indicator.server_fingerprint,
                            "alias": indicator.title, "note": indicator.description,
                            "added_by": f"aiglos-intel-{indicator.source}", "added_at": time.time()})
            data["servers"] = servers
            self.trust_file.write_text(yaml.dump(data, default_flow_style=False))
            return True
        except Exception as e:
            logger.warning("server_block_failed", error=str(e)); return False

    def _save_cache(self):
        try:
            self.intel_cache.write_text(json.dumps({
                "applied_ids": list(self._applied_ids),
                "indicators": [{"id": i.id, "source": i.source, "applied": i.applied} for i in self._indicators],
                "saved_at": time.time(),
            }, indent=2))
        except Exception as e: logger.debug("cache_save_failed", error=str(e))

    def _load_cache(self):
        if not self.intel_cache.exists(): return
        try:
            data = json.loads(self.intel_cache.read_text())
            self._applied_ids = set(data.get("applied_ids", []))
        except Exception as e: logger.debug("cache_load_failed", error=str(e))

    def get_summary(self):
        by_sev = {}; by_src = {}
        for i in self._indicators:
            by_sev[i.severity] = by_sev.get(i.severity, 0) + 1
            by_src[i.source] = by_src.get(i.source, 0) + 1
        return {"total_indicators": len(self._indicators), "applied": len(self._applied_ids),
                "pending": len(self._indicators) - len(self._applied_ids),
                "by_severity": by_sev, "by_source": by_src,
                "policy_file": str(self.policy_file), "trust_file": str(self.trust_file)}

    async def _run_sca_scan(self) -> int:
        """T26: Run supply chain scanner on intel refresh cycle."""
        from aiglos_core.autonomous.sca import SupplyChainScanner
        scanner = SupplyChainScanner(audit_db=self.audit_db if hasattr(self, 'audit_db') else 'aiglos_audit.db')
        findings = await scanner.scan()
        return len(findings)

    async def _run_registry_scan(self) -> int:
        """T30: Run registry monitor on intel refresh cycle."""
        from aiglos_core.autonomous.registry import RegistryMonitor
        monitor = RegistryMonitor(
            audit_db=self.audit_db if hasattr(self, 'audit_db') else 'aiglos_audit.db',
            trust_file=self.trust_file if hasattr(self, 'trust_file') else 'aiglos_trust.yaml',
        )
        findings = await monitor.scan()
        return len(findings)
