"""Aiglos Autonomous Engine - Command Center orchestrator."""
from __future__ import annotations
import asyncio, json, os, signal, time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Coroutine
import structlog
logger = structlog.get_logger("aiglos.engine")

class EngineState(str, Enum):
    INITIALIZING = "initializing"; RUNNING = "running"
    SUSPENDED = "suspended"; SHUTDOWN = "shutdown"

class TaskPriority(int, Enum):
    CRITICAL = 0; HIGH = 1; NORMAL = 2; LOW = 3

class TaskStatus(str, Enum):
    QUEUED = "queued"; RUNNING = "running"; COMPLETED = "completed"
    FAILED = "failed"; RETRYING = "retrying"

@dataclass
class ScanTask:
    id: str; name: str; goal: str; priority: TaskPriority
    coro_factory: Callable[[], Coroutine]
    created_at: float = field(default_factory=time.time)
    started_at: float | None = None; completed_at: float | None = None
    status: TaskStatus = TaskStatus.QUEUED; result: Any = None
    error: str | None = None; retry_count: int = 0; max_retries: int = 2
    timeout_seconds: float = 60.0
    def __lt__(self, other):
        return (self.priority, self.created_at) < (other.priority, other.created_at)

@dataclass
class EngineStatus:
    state: EngineState; uptime_seconds: float; tasks_completed: int
    tasks_failed: int; tasks_queued: int; last_scan_at: float | None
    last_intel_refresh_at: float | None; last_report_at: float | None
    active_task: str | None; threat_level: str; policy_version: str
    baseline_sessions: int; critical_events_24h: int
    def to_dict(self):
        return {k: (v.value if isinstance(v, EngineState) else v)
                for k, v in self.__dict__.items()}

class AiglOsAutonomousEngine:
    def __init__(self, audit_db_path="aiglos_audit.db", config_path="aiglos_config.yaml",
                 state_path="aiglos_engine_state.json", scan_interval_minutes=5,
                 intel_refresh_interval_hours=1, report_interval_hours=24,
                 max_concurrent_tasks=3):
        self.audit_db_path = audit_db_path; self.config_path = config_path
        self.state_path = Path(state_path)
        self.scan_interval_seconds = scan_interval_minutes * 60
        self.intel_refresh_seconds = intel_refresh_interval_hours * 3600
        self.report_interval_seconds = report_interval_hours * 3600
        self.max_concurrent = max_concurrent_tasks
        self._state = EngineState.INITIALIZING; self._start_time = 0.0
        self._task_queue: asyncio.PriorityQueue = asyncio.PriorityQueue()
        self._active_tasks: dict = {}; self._completed: list = []; self._failed: list = []
        self._task_counter = 0; self._last_scan_at = None; self._last_intel_at = None
        self._last_report_at = None; self._shutdown_event: asyncio.Event = None
        self._hunter = None; self._intel = None

    async def run(self):
        self._start_time = time.time(); self._state = EngineState.RUNNING
        self._shutdown_event = asyncio.Event()
        loop = asyncio.get_event_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, self._request_shutdown)
        await self._init_subsystems()
        await asyncio.gather(self._task_dispatcher(), self._schedule_loop(),
                             self._watchdog_loop(), self._state_persister(),
                             return_exceptions=True)
        self._state = EngineState.SHUTDOWN
        await self._persist_state()

    def _request_shutdown(self):
        if self._shutdown_event: self._shutdown_event.set()

    async def shutdown(self): self._request_shutdown()

    def _next_task_id(self):
        self._task_counter += 1; return f"task-{self._task_counter:06d}"

    async def enqueue(self, name, goal, coro_factory,
                      priority=TaskPriority.NORMAL, timeout_seconds=60.0):
        task = ScanTask(id=self._next_task_id(), name=name, goal=goal,
                        priority=priority, coro_factory=coro_factory,
                        timeout_seconds=timeout_seconds)
        await self._task_queue.put(task)
        logger.debug("task_enqueued", task_id=task.id, name=name)
        return task

    async def _task_dispatcher(self):
        semaphore = asyncio.Semaphore(self.max_concurrent)
        while not (self._shutdown_event and self._shutdown_event.is_set()):
            try:
                task = await asyncio.wait_for(self._task_queue.get(), timeout=1.0)
            except asyncio.TimeoutError: continue
            async def run_task(t):
                async with semaphore: await self._execute_task(t)
            asyncio.create_task(run_task(task))

    async def _execute_task(self, task: ScanTask):
        task.status = TaskStatus.RUNNING; task.started_at = time.time()
        self._active_tasks[task.id] = task
        logger.info("task_started", task_id=task.id, name=task.name)
        while task.retry_count <= task.max_retries:
            try:
                coro = task.coro_factory()
                task.result = await asyncio.wait_for(coro, timeout=task.timeout_seconds)
                task.status = TaskStatus.COMPLETED; task.completed_at = time.time()
                logger.info("task_completed", task_id=task.id)
                self._completed.append(task); break
            except (asyncio.TimeoutError, Exception) as exc:
                task.error = str(exc); task.retry_count += 1
                if task.retry_count <= task.max_retries:
                    task.status = TaskStatus.RETRYING
                    await asyncio.sleep(5 * task.retry_count)
                else:
                    task.status = TaskStatus.FAILED; self._failed.append(task); break
        del self._active_tasks[task.id]

    async def _schedule_loop(self):
        await self._enqueue_scan_cycle(); await self._enqueue_intel_refresh()
        while not (self._shutdown_event and self._shutdown_event.is_set()):
            now = time.time()
            if self._last_scan_at is None or now - self._last_scan_at >= self.scan_interval_seconds:
                await self._enqueue_scan_cycle(); self._last_scan_at = now
            if self._last_intel_at is None or now - self._last_intel_at >= self.intel_refresh_seconds:
                await self._enqueue_intel_refresh(); self._last_intel_at = now
            if self._last_report_at is None or now - self._last_report_at >= self.report_interval_seconds:
                await self._enqueue_report(); self._last_report_at = now
            await asyncio.sleep(30)

    async def _enqueue_scan_cycle(self):
        if not self._hunter: return
        hunter = self._hunter
        async def _scan(): return await hunter.run_full_scan()
        await self.enqueue("threat_scan_cycle",
            "Proactively scan all registered MCP servers for active threat indicators",
            _scan, TaskPriority.NORMAL, 120.0)

    async def _enqueue_intel_refresh(self):
        if not self._intel: return
        intel = self._intel
        async def _intel(): return await intel.refresh()
        await self.enqueue("threat_intel_refresh",
            "Ingest latest CVE feeds and OWASP updates to update detection policy",
            _intel, TaskPriority.NORMAL, 90.0)

    async def _enqueue_report(self):
        async def _report(): return await self._generate_and_dispatch_report()
        await self.enqueue("compliance_report",
            "Generate CMMC compliance digest for the past 24 hours",
            _report, TaskPriority.LOW, 180.0)

    async def _generate_and_dispatch_report(self):
        try:
            from aiglos_core.audit import AuditLog
            audit = AuditLog(self.audit_db_path); stats = audit.get_stats()
            recent = audit.get_recent_events(limit=100)
            critical = [e for e in recent if e.get("severity") == "critical"]
            threat_level = "critical" if len(critical) >= 5 else ("elevated" if len(critical) >= 1 else "nominal")
            logger.info("report_generated", threat_level=threat_level)
            self._last_report_at = time.time()
            return {"threat_level": threat_level, "stats": stats, "critical_count": len(critical)}
        except Exception as e:
            return {"error": str(e)}

    async def _watchdog_loop(self):
        while not (self._shutdown_event and self._shutdown_event.is_set()):
            await asyncio.sleep(60)
            recent_failures = len([t for t in self._failed if
                                    t.completed_at and time.time() - t.completed_at < 300])
            if recent_failures >= 5:
                logger.warning("watchdog_failure_spike", recent_failures=recent_failures)
            logger.debug("watchdog_pulse", state=self._state.value,
                         queued=self._task_queue.qsize(), active=len(self._active_tasks))

    async def _state_persister(self):
        while not (self._shutdown_event and self._shutdown_event.is_set()):
            await asyncio.sleep(15); await self._persist_state()

    async def _persist_state(self):
        try:
            critical_24h = 0
            try:
                from aiglos_core.audit import AuditLog
                audit = AuditLog(self.audit_db_path)
                critical_24h = audit.get_stats().get("critical_events", 0)
            except: pass
            threat_level = "critical" if critical_24h >= 5 else ("elevated" if critical_24h >= 1 else "nominal")
            status = EngineStatus(
                state=self._state, uptime_seconds=time.time() - self._start_time,
                tasks_completed=len(self._completed), tasks_failed=len(self._failed),
                tasks_queued=self._task_queue.qsize(),
                last_scan_at=self._last_scan_at, last_intel_refresh_at=self._last_intel_at,
                last_report_at=self._last_report_at,
                active_task=(next(iter(self._active_tasks.values())).name
                             if self._active_tasks else None),
                threat_level=threat_level, policy_version="0.1.0",
                baseline_sessions=0, critical_events_24h=critical_24h,
            )
            self.state_path.write_text(json.dumps(status.to_dict(), indent=2))
        except Exception as e:
            logger.debug("state_persist_failed", error=str(e))

    async def _init_subsystems(self):
        try:
            from aiglos_core.autonomous.hunter import ThreatHunter
            self._hunter = ThreatHunter(audit_db_path=self.audit_db_path)
            logger.info("subsystem_ready", name="ThreatHunter")
        except Exception as e:
            logger.warning("subsystem_init_failed", name="ThreatHunter", error=str(e))
        try:
            from aiglos_core.autonomous.intel import ThreatIntelligence
            self._intel = ThreatIntelligence()
            logger.info("subsystem_ready", name="ThreatIntelligence")
        except Exception as e:
            logger.warning("subsystem_init_failed", name="ThreatIntelligence", error=str(e))

    def get_status(self):
        return EngineStatus(
            state=self._state, uptime_seconds=time.time() - self._start_time,
            tasks_completed=len(self._completed), tasks_failed=len(self._failed),
            tasks_queued=self._task_queue.qsize() if self._task_queue else 0,
            last_scan_at=self._last_scan_at, last_intel_refresh_at=self._last_intel_at,
            last_report_at=self._last_report_at, active_task=None,
            threat_level="nominal", policy_version="0.1.0",
            baseline_sessions=0, critical_events_24h=0,
        )