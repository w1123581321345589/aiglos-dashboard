"""
T31: Memory / RAG Poison Detector

Detects adversarial content injected into AI agent memory stores and
Retrieval-Augmented Generation (RAG) knowledge bases.

Why this is architecturally different from prompt injection
-----------------------------------------------------------
The MCP proxy layer (T1-T4) catches injection at tool-call time — when
the LLM is actively calling a tool. RAG/memory poisoning attacks happen
at write time (when a document is ingested or a memory is stored) and
execute silently at every subsequent retrieval, invisibly to the proxy.

A poisoned document sitting in a vector store injects its instructions
into every agent session that retrieves it — "indirect prompt injection
at scale." No single tool call looks suspicious; the attack is distributed
across hundreds of sessions.

Attack vectors covered
----------------------
1. Document Ingestion Poisoning
   A malicious document is added to the RAG knowledge base. It contains
   hidden instructions that fire whenever the document is retrieved.
   Detection: scan at write time before embedding.

2. Memory Write Poisoning
   An agent writes a poisoned memory (Mem0, Zep, Letta) that will
   influence its own or other agents' future behavior.
   Detection: scan memory writes before persisting.

3. Retrieval-Time Chunk Injection
   Even a legitimate document may have been tampered with after ingestion.
   A retrieved chunk contains injection patterns not present at write time.
   Detection: scan retrieved chunks before injecting into context.

4. Cross-Session Memory Leakage
   A shared memory store leaks one user's private data into another
   user's context window via over-broad semantic search results.
   Detection: session_id boundary enforcement on retrieved chunks.

Integration
-----------
  from aiglos_core.autonomous.rag import RAGPoisonDetector, MemoryEvent

  detector = RAGPoisonDetector(audit_db="aiglos_audit.db")

  # On document ingest (write-time scan):
  verdict = await detector.scan_document(content=doc_text, source="uploads/brief.pdf")
  if not verdict.safe:
      raise SecurityError(verdict.reason)

  # On memory write:
  verdict = await detector.scan_memory_write(
      session_id="sess-123",
      content=memory_text,
      memory_key="user_preference_001",
  )

  # On RAG retrieval (pre-injection scan):
  safe_chunks = await detector.filter_chunks(chunks=retrieved_chunks, session_id="sess-123")

  # Autonomous scan of existing memory store:
  findings = await detector.scan()
"""

from __future__ import annotations

import asyncio
import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    import structlog
    logger = structlog.get_logger("aiglos.rag")
except ImportError:
    import logging
    logger = logging.getLogger("aiglos.rag")

# ---------------------------------------------------------------------------
# Detection patterns
# ---------------------------------------------------------------------------

# Tier 1: Hard injection patterns (block immediately)
INJECTION_PATTERNS_T1 = [
    re.compile(r"(?i)ignore\s+(?:all\s+)?(?:previous|prior|above|earlier)\s+instructions?"),
    re.compile(r"(?i)you\s+are\s+now\s+(?:a|an|the)\s+\w"),
    re.compile(r"(?i)(?:new|updated|revised)\s+system\s+(?:prompt|instruction)\s*:"),
    re.compile(r"(?i)from\s+now\s+on[,\s]"),
    re.compile(r"(?i)<\s*/?(?:system|INST|instruction|override|s)\s*>"),
    re.compile(r"(?i)\[INST\]|\[\/INST\]|\[SYS\]|\[\/SYS\]"),  # Llama/Mistral format injection
    re.compile(r"(?i)###\s*(?:system|instruction|override)\s*###"),
    re.compile(r"(?i)ASSISTANT\s*:\s*(?:Sure|Of course|I will|I'll)"),  # fake assistant turns
    re.compile(r"[\u200b\u200c\u200d\u200e\u200f\ufeff]{2,}"),  # clustered zero-width chars
]

# Tier 2: Suspicious patterns (flag, require review)
INJECTION_PATTERNS_T2 = [
    re.compile(r"(?i)please\s+(?:disregard|forget|override|bypass)"),
    re.compile(r"(?i)for\s+(?:testing|debug|dev)\s+purposes?[,\s]+(?:ignore|bypass|skip)"),
    re.compile(r"(?i)(?:secret|hidden|special)\s+(?:instruction|command|directive)"),
    re.compile(r"(?i)when\s+(?:you\s+)?(?:see|read|process)\s+this\s+(?:message|text|document)"),
    re.compile(r"(?i)base64[_\s]?decode\s*\("),  # encoded payload signal
    re.compile(r"(?i)eval\s*\(|exec\s*\("),       # code execution attempt
    re.compile(r"(?i)exfil|exfiltrate|send\s+to\s+(?:https?://|email)"),
]

# PII / sensitive data patterns (cross-session leakage detection)
PII_PATTERNS = [
    re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),                        # SSN
    re.compile(r"\b4[0-9]{12}(?:[0-9]{3})?\b"),                   # Visa card
    re.compile(r"\b(?:sk-ant-api|sk-ant-)[A-Za-z0-9\-_]{20,}\b"),# Anthropic API key
    re.compile(r"\bAKIA[0-9A-Z]{16}\b"),                          # AWS access key
    re.compile(r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Z|a-z]{2,}\b"),  # Email
    re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b"),                   # IP address
]


@dataclass
class DocumentVerdict:
    safe: bool
    tier: int = 0             # 0=clean, 1=blocked, 2=flagged
    reason: str = ""
    patterns_matched: list = field(default_factory=list)
    pii_detected: bool = False
    cmmc_controls: list = field(default_factory=list)


@dataclass
class RAGFinding:
    id: str
    vector: str
    severity: str
    title: str
    description: str
    source: str
    session_id: str = ""
    evidence: dict = field(default_factory=dict)
    remediation: str = ""
    cmmc_controls: list = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)


class RAGPoisonDetector:
    """
    Detects adversarial content in RAG knowledge bases and agent memory stores.
    Operates at write time, retrieval time, and via autonomous background scan.
    """

    def __init__(
        self,
        audit_db: str = "aiglos_audit.db",
        memory_paths: list[str] | None = None,
        strict_mode: bool = False,
    ):
        self.audit_db = audit_db
        # Paths to scan for memory/vector store files
        self.memory_paths = memory_paths or [
            ".aiglos_memory/",
            "memory/",
            "knowledge_base/",
            "rag_data/",
            "embeddings/",
            "vector_store/",
            "mem0/",
            "zep/",
        ]
        self.strict_mode = strict_mode  # If True, T2 patterns also block (not just flag)
        self._n = 0
        # session_id -> set of chunk_hashes (for cross-session leakage detection)
        self._session_chunks: dict[str, set[str]] = {}

    def _fid(self) -> str:
        self._n += 1
        return f"rag-{self._n:05d}"

    # ------------------------------------------------------------------
    # Write-time document scan
    # ------------------------------------------------------------------

    async def scan_document(
        self, content: str, source: str = "unknown", session_id: str = ""
    ) -> DocumentVerdict:
        """
        Scan a document before ingesting it into a RAG store.
        Returns a verdict — caller should block ingestion if not safe.
        """
        patterns_matched = []

        # Tier 1: hard injection
        for pat in INJECTION_PATTERNS_T1:
            if pat.search(content):
                await self._log_event("rag_write_blocked", source, session_id,
                                      f"T1 injection pattern: {pat.pattern[:60]}")
                return DocumentVerdict(
                    safe=False,
                    tier=1,
                    reason=f"Hard injection pattern detected: {pat.pattern[:60]}",
                    patterns_matched=[pat.pattern[:60]],
                    cmmc_controls=["3.14.2", "3.13.1"],
                )

        # Tier 2: suspicious patterns
        for pat in INJECTION_PATTERNS_T2:
            if pat.search(content):
                patterns_matched.append(pat.pattern[:60])

        if patterns_matched and self.strict_mode:
            return DocumentVerdict(
                safe=False,
                tier=2,
                reason=f"Suspicious patterns in strict mode: {patterns_matched[0]}",
                patterns_matched=patterns_matched,
                cmmc_controls=["3.14.2"],
            )

        # PII detection
        pii_found = any(pat.search(content) for pat in PII_PATTERNS)

        if patterns_matched:
            await self._log_event("rag_write_flagged", source, session_id,
                                  f"T2 patterns: {patterns_matched}")
            return DocumentVerdict(
                safe=True,   # Allowed but flagged
                tier=2,
                reason=f"Suspicious patterns flagged (not blocked): {', '.join(patterns_matched[:3])}",
                patterns_matched=patterns_matched,
                pii_detected=pii_found,
                cmmc_controls=["3.14.2"],
            )

        return DocumentVerdict(
            safe=True,
            tier=0,
            pii_detected=pii_found,
        )

    # ------------------------------------------------------------------
    # Memory write scan
    # ------------------------------------------------------------------

    async def scan_memory_write(
        self,
        content: str,
        memory_key: str = "",
        session_id: str = "",
    ) -> DocumentVerdict:
        """
        Scan a memory write before persisting to Mem0/Zep/Letta or any vector store.
        Stricter than document scan — memory persists across sessions.
        """
        # Memory writes use strict mode by default regardless of detector setting
        original_strict = self.strict_mode
        self.strict_mode = True
        verdict = await self.scan_document(content, source=f"memory:{memory_key}", session_id=session_id)
        self.strict_mode = original_strict

        if not verdict.safe:
            await self._persist_finding(RAGFinding(
                id=self._fid(),
                vector="memory_write_poison",
                severity="critical",
                title=f"Poisoned memory write blocked: key={memory_key or 'unknown'}",
                description=(
                    f"Memory write to key '{memory_key}' in session "
                    f"'{session_id[:8] if session_id else 'unknown'}' was blocked. "
                    f"Memory poisoning can influence all future agent sessions. "
                    f"Reason: {verdict.reason}"
                ),
                source=f"memory:{memory_key}",
                session_id=session_id,
                evidence={"memory_key": memory_key, "patterns": verdict.patterns_matched},
                remediation=(
                    "Review the memory write source. "
                    "If this content came from an external tool response, "
                    "the upstream MCP server may be compromised."
                ),
                cmmc_controls=["3.14.2", "3.13.1", "3.1.1"],
            ))
        return verdict

    # ------------------------------------------------------------------
    # Retrieval-time chunk filtering
    # ------------------------------------------------------------------

    async def filter_chunks(
        self,
        chunks: list[str],
        session_id: str = "",
    ) -> list[str]:
        """
        Filter retrieved chunks before injecting into context window.
        Returns only safe chunks. Poisoned chunks are dropped and logged.
        """
        safe_chunks = []
        for chunk in chunks:
            verdict = await self.scan_document(chunk, source="retrieval", session_id=session_id)
            if verdict.safe and verdict.tier == 0:
                safe_chunks.append(chunk)
            elif not verdict.safe:
                logger.warning("rag_chunk_dropped", session_id=session_id[:8] if session_id else "?",
                               reason=verdict.reason[:80])
                await self._persist_finding(RAGFinding(
                    id=self._fid(),
                    vector="retrieval_injection",
                    severity="critical",
                    title="Poisoned chunk dropped at retrieval time",
                    description=(
                        f"A retrieved chunk was dropped before context injection "
                        f"in session '{session_id[:8] if session_id else 'unknown'}'. "
                        f"The knowledge base may contain documents that were poisoned "
                        f"after initial ingestion. Reason: {verdict.reason}"
                    ),
                    source="retrieval",
                    session_id=session_id,
                    evidence={"patterns": verdict.patterns_matched,
                              "chunk_preview": chunk[:100]},
                    remediation=(
                        "Re-scan the entire knowledge base with RAGPoisonDetector.scan(). "
                        "Identify and remove the source document."
                    ),
                    cmmc_controls=["3.14.2", "3.13.1"],
                ))
            else:
                # T2 flagged but allowed
                safe_chunks.append(chunk)
        return safe_chunks

    # ------------------------------------------------------------------
    # Cross-session leakage check
    # ------------------------------------------------------------------

    async def check_cross_session_leakage(
        self,
        chunks: list[str],
        current_session_id: str,
        owner_session_id: str,
    ) -> list[str]:
        """
        Ensure retrieved chunks belong to the current session's user context.
        Drops chunks that originated in a different session and contain PII.
        """
        if current_session_id == owner_session_id:
            return chunks

        safe = []
        for chunk in chunks:
            has_pii = any(pat.search(chunk) for pat in PII_PATTERNS)
            if has_pii:
                logger.warning("rag_cross_session_leakage_blocked",
                               from_session=owner_session_id[:8],
                               to_session=current_session_id[:8])
                await self._persist_finding(RAGFinding(
                    id=self._fid(),
                    vector="cross_session_leakage",
                    severity="high",
                    title="Cross-session PII leakage blocked in RAG retrieval",
                    description=(
                        f"A retrieved chunk from session '{owner_session_id[:8]}' "
                        f"containing PII was blocked from leaking into session "
                        f"'{current_session_id[:8]}'. Overly broad semantic search "
                        f"in the shared memory store is returning another user's data."
                    ),
                    source="cross_session_retrieval",
                    session_id=current_session_id,
                    evidence={"owner_session": owner_session_id[:8],
                              "chunk_preview": chunk[:80]},
                    remediation=(
                        "Add session_id namespace isolation to your vector store queries. "
                        "Use metadata filtering: WHERE session_id = current_session_id."
                    ),
                    cmmc_controls=["3.13.1", "3.1.1", "3.1.3"],
                ))
            else:
                safe.append(chunk)
        return safe

    # ------------------------------------------------------------------
    # Autonomous background scan of memory paths
    # ------------------------------------------------------------------

    async def scan(self) -> list[RAGFinding]:
        """
        Autonomous scan of all configured memory/vector store paths.
        Reads text files and scans for injection patterns.
        """
        findings: list[RAGFinding] = []

        for path_str in self.memory_paths:
            path = Path(path_str)
            if not path.exists():
                continue
            if path.is_dir():
                # Recursively scan text files
                for f in path.rglob("*.txt"):
                    findings.extend(await self._scan_file(f))
                for f in path.rglob("*.json"):
                    findings.extend(await self._scan_file(f))
                for f in path.rglob("*.md"):
                    findings.extend(await self._scan_file(f))
            elif path.is_file():
                findings.extend(await self._scan_file(path))

        logger.info("rag_scan_complete", findings=len(findings),
                    paths_checked=len(self.memory_paths))
        return findings

    async def _scan_file(self, path: Path) -> list[RAGFinding]:
        findings = []
        try:
            content = path.read_text(errors="replace")
        except Exception:
            return findings

        verdict = await self.scan_document(content, source=str(path))
        if not verdict.safe or verdict.pii_detected:
            severity = "critical" if not verdict.safe else "medium"
            findings.append(RAGFinding(
                id=self._fid(),
                vector="knowledge_base_poison" if not verdict.safe else "pii_in_knowledge_base",
                severity=severity,
                title=f"{'Injection' if not verdict.safe else 'PII'} detected in knowledge base: {path.name}",
                description=(
                    f"File '{path}' in the RAG knowledge base "
                    f"{'contains injection patterns' if not verdict.safe else 'contains PII'}. "
                    f"{verdict.reason}"
                ),
                source=str(path),
                evidence={"file": str(path), "patterns": verdict.patterns_matched,
                          "pii": verdict.pii_detected},
                remediation=(
                    f"Remove or quarantine '{path}'. "
                    f"Re-embed the knowledge base after removing this document."
                ),
                cmmc_controls=["3.14.2", "3.13.1"] if not verdict.safe else ["3.13.1"],
            ))
        return findings

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    async def _log_event(self, event_type: str, source: str, session_id: str, detail: str) -> None:
        logger.info("rag_event", event_type=event_type, source=source,
                    session_id=session_id[:8] if session_id else "?", detail=detail[:80])

    async def _persist_finding(self, finding: RAGFinding) -> None:
        try:
            from aiglos_core.audit import AuditLog
            from aiglos_core.types import SecurityEvent, EventType, Severity
            audit = AuditLog(self.audit_db)
            smap = {"critical": Severity.CRITICAL, "high": Severity.HIGH, "medium": Severity.MEDIUM}
            audit.record_event(SecurityEvent(
                session_id=finding.session_id or "aiglos-rag",
                event_type=EventType.ANOMALY_DETECTED,
                severity=smap.get(finding.severity, Severity.HIGH),
                title=finding.title,
                description=finding.description,
                details=finding.evidence,
                cmmc_controls=finding.cmmc_controls,
            ))
        except Exception as e:
            logger.debug("rag_persist_failed", error=str(e))
