"""
T24: MCP Sampling Monitor

Detects three attack vectors via the MCP sampling feature identified by
Palo Alto Unit 42 (December 2025):

  Vector 1 — Conversation Hijacking
    A malicious server injects persistent instructions into sampled LLM
    completions. The injected content becomes invisible to the user because
    the MCP client summarizes the raw response before display.

  Vector 2 — Covert Tool Invocation
    Sampling responses trigger hidden tool calls not in the session goal.
    File system reads, credential harvests, and exfil calls are the
    most common patterns.

  Vector 3 — Resource Theft
    Attacker abuses sampling to drain the user's LLM compute quota for
    unrelated workloads. Detected by anomalous token consumption rate
    relative to the session baseline.

How it integrates
-----------------
Aiglos.proxy.__init__ already logs all MCP messages to the audit DB as
ToolCall / ToolResponse events. The sampling monitor reads those events
in the autonomous hunt cycle (runs every 5 minutes by default) and
scores them against the three classifiers.

Sampling requests appear in the audit log as ToolCall events where
tool_name == "sampling/createMessage" (per MCP spec §4.4).

Drop-in usage:
    hunter = ThreatHunter(...)
    # Already wired: sampler is added as hunt module 6 in this file.
    # Import ThreatHunter from aiglos_core.autonomous.hunter and it
    # picks up the sampler automatically via monkey-patch at import time.

Standalone usage:
    monitor = SamplingMonitor(audit_db="aiglos_audit.db")
    result = asyncio.run(monitor.scan())
"""

from __future__ import annotations

import asyncio
import json
import re
import time
from dataclasses import dataclass, field
from typing import Any

import structlog

logger = structlog.get_logger("aiglos.sampler")

# ---------------------------------------------------------------------------
# Injection patterns inside sampled LLM completions
# ---------------------------------------------------------------------------

HIJACK_PATTERNS = [
    # Persistent instruction injection
    (re.compile(
        r"(?i)(from now on|going forward|in all future|for all subsequent|"
        r"always respond|never tell|you must always|you should always|"
        r"remember to always|your new (role|goal|instruction|directive))"
    ), "persistent-instruction-injection"),

    # Role override through sampling
    (re.compile(
        r"(?i)(you are (now |a |an )?(different|new|evil|malicious|jailbroken|"
        r"unrestricted|uncensored|DAN|STAN)|ignore (your|all) (previous |prior )?"
        r"(instruction|training|guideline|constraint|limit))"
    ), "role-override"),

    # Exfiltration instructions embedded in sample response
    (re.compile(
        r"(?i)(send (this|the following|all) (to|via)|"
        r"forward (this|everything|all) to|"
        r"email (this|the following|it) to|"
        r"upload (this|the following|all) to)"
    ), "embedded-exfil-instruction"),

    # Hidden content markers (whitespace tricks, zero-width chars)
    (re.compile(r"[\u200b\u200c\u200d\u200e\u200f\u202a-\u202e\u2060-\u2069\ufeff]"),
     "unicode-steganography"),
]

# Tool calls that indicate covert invocation within a sampling response
COVERT_TOOL_PATTERNS = [
    (re.compile(r"(?i)(read_file|file_read|cat |open\(|fs\.read)"), "covert-file-read"),
    (re.compile(r"(?i)(subprocess|os\.system|exec\(|eval\(|shell=True)"), "covert-code-exec"),
    (re.compile(r"(?i)(requests\.post|urllib|fetch\(|http_request)"), "covert-http-exfil"),
    (re.compile(r"(?i)(os\.getenv|process\.env|dotenv|\.env\b)"), "covert-env-harvest"),
]

# Token consumption thresholds
# If a sampling request consumes more tokens than this multiple of the
# session mean, it is flagged as potential resource theft.
RESOURCE_THEFT_MULTIPLIER = 5.0
RESOURCE_THEFT_MIN_TOKENS = 500  # Don't flag sessions with very few tokens


@dataclass
class SamplingFinding:
    id: str
    vector: str           # "hijack" | "covert_tool" | "resource_theft"
    severity: str
    title: str
    description: str
    session_id: str
    evidence: dict = field(default_factory=dict)
    remediation: str = ""
    cmmc_controls: list = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)


@dataclass
class SamplingResult:
    findings: list[SamplingFinding]
    sampling_events_analyzed: int
    sessions_with_sampling: int
    duration_s: float
    timestamp: float = field(default_factory=time.time)

    @property
    def critical_count(self):
        return sum(1 for f in self.findings if f.severity == "critical")

    def summary(self) -> str:
        if not self.findings:
            return (f"Sampling scan clean. "
                    f"{self.sampling_events_analyzed} events / "
                    f"{self.sessions_with_sampling} sessions analyzed.")
        return (f"Sampling: {len(self.findings)} findings "
                f"({self.critical_count} critical) across "
                f"{self.sessions_with_sampling} sessions.")


class SamplingMonitor:
    """
    Autonomous monitor for MCP sampling channel attack vectors.

    Reads sampling/createMessage events from the audit DB and scores
    them against the three Unit 42 attack vectors.
    """

    def __init__(self, audit_db: str = "aiglos_audit.db"):
        self.audit_db = audit_db
        self._n = 0

    def _fid(self) -> str:
        self._n += 1
        return f"samp-{self._n:05d}"

    async def scan(self) -> SamplingResult:
        """Run all three vector classifiers against recent sampling events."""
        start = time.monotonic()
        all_findings: list[SamplingFinding] = []
        sampling_events: list[dict] = []
        sessions_seen: set[str] = set()

        try:
            import sqlite3 as _sqlite3
            conn = _sqlite3.connect(self.audit_db)
            conn.row_factory = _sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM tool_calls WHERE tool_name LIKE '%sampling%' OR tool_name LIKE '%createMessage%' ORDER BY timestamp DESC LIMIT 1000"
            ).fetchall()
            conn.close()
            for row in rows:
                d = dict(row)
                for fld in ("arguments", "result"):
                    if isinstance(d.get(fld), str):
                        try:
                            d[fld + "_parsed"] = json.loads(d[fld])
                        except Exception:
                            d[fld + "_parsed"] = {"raw": d.get(fld, "")}
                # Build a merged details dict for pattern matching
                args = d.get("arguments_parsed", {})
                res = d.get("result_parsed", {})
                merged = {**args, **res}
                merged.setdefault("tool_name", d.get("tool_name", ""))
                d["_details_parsed"] = merged
                sampling_events.append(d)
                sessions_seen.add(d.get("session_id", ""))
        except Exception as e:
            logger.debug("sampling_load_failed", error=str(e))

        if sampling_events:
            # Vector 1: Conversation hijacking
            v1 = await self._detect_hijacking(sampling_events)
            all_findings.extend(v1)

            # Vector 2: Covert tool invocation
            v2 = await self._detect_covert_tools(sampling_events)
            all_findings.extend(v2)

            # Vector 3: Resource theft
            v3 = await self._detect_resource_theft(sampling_events)
            all_findings.extend(v3)

        elapsed = round(time.monotonic() - start, 2)
        result = SamplingResult(
            findings=all_findings,
            sampling_events_analyzed=len(sampling_events),
            sessions_with_sampling=len(sessions_seen),
            duration_s=elapsed,
        )

        if all_findings:
            await self._persist(all_findings)

        logger.info("sampling_scan_complete",
                    findings=len(all_findings),
                    events=len(sampling_events),
                    sessions=len(sessions_seen),
                    duration_s=elapsed)
        return result

    # ------------------------------------------------------------------
    # Vector 1: Conversation Hijacking
    # ------------------------------------------------------------------

    async def _detect_hijacking(
        self, events: list[dict]
    ) -> list[SamplingFinding]:
        findings = []
        seen: set[str] = set()

        for ev in events:
            details = ev.get("_details_parsed", {})
            session_id = ev.get("session_id", "?")

            # The sampled LLM response is in the result/content field
            content = (
                str(details.get("result", "")) +
                str(details.get("content", "")) +
                str(details.get("messages", ""))
            )

            for pattern, pattern_name in HIJACK_PATTERNS:
                if pattern.search(content):
                    key = f"{session_id}-{pattern_name}"
                    if key in seen:
                        continue
                    seen.add(key)

                    findings.append(SamplingFinding(
                        id=self._fid(),
                        vector="hijack",
                        severity="critical",
                        title=f"Sampling hijack: {pattern_name}",
                        description=(
                            f"Conversation hijacking pattern '{pattern_name}' detected "
                            f"in sampling response for session {session_id[:8]}. "
                            f"The injected instruction may persist across all future "
                            f"completions in this session."
                        ),
                        session_id=session_id,
                        evidence={
                            "session_id": session_id,
                            "pattern": pattern_name,
                            "tool": details.get("tool_name", "sampling/createMessage"),
                        },
                        remediation=(
                            "Terminate session. Inspect full sampling response payload. "
                            "Block originating MCP server fingerprint. "
                            "Review all tool calls made after this sampling event."
                        ),
                        cmmc_controls=["3.14.2", "3.13.1"],
                    ))
                    break

        return findings

    # ------------------------------------------------------------------
    # Vector 2: Covert Tool Invocation
    # ------------------------------------------------------------------

    async def _detect_covert_tools(
        self, events: list[dict]
    ) -> list[SamplingFinding]:
        findings = []
        seen: set[str] = set()

        for ev in events:
            details = ev.get("_details_parsed", {})
            session_id = ev.get("session_id", "?")

            content = (
                str(details.get("result", "")) +
                str(details.get("content", "")) +
                str(details.get("messages", "")) +
                str(details.get("arguments", ""))
            )

            for pattern, tool_type in COVERT_TOOL_PATTERNS:
                if pattern.search(content):
                    key = f"{session_id}-{tool_type}"
                    if key in seen:
                        continue
                    seen.add(key)

                    findings.append(SamplingFinding(
                        id=self._fid(),
                        vector="covert_tool",
                        severity="critical",
                        title=f"Covert tool invocation via sampling: {tool_type}",
                        description=(
                            f"Sampling response for session {session_id[:8]} contains "
                            f"patterns consistent with {tool_type}. "
                            f"This matches the Unit 42 covert tool invocation vector where "
                            f"hidden tool calls are triggered inside sampling completions "
                            f"without appearing in the visible session history."
                        ),
                        session_id=session_id,
                        evidence={
                            "session_id": session_id,
                            "tool_type": tool_type,
                        },
                        remediation=(
                            "Review full sampling payload. "
                            "Audit all filesystem and network activity in the session window. "
                            "Block originating server."
                        ),
                        cmmc_controls=["3.14.2", "3.13.1", "3.1.1"],
                    ))
                    break

        return findings

    # ------------------------------------------------------------------
    # Vector 3: Resource Theft (anomalous token consumption)
    # ------------------------------------------------------------------

    async def _detect_resource_theft(
        self, events: list[dict]
    ) -> list[SamplingFinding]:
        findings = []

        # Extract token counts per session
        session_tokens: dict[str, list[int]] = {}
        for ev in events:
            details = ev.get("_details_parsed", {})
            session_id = ev.get("session_id", "?")

            # Token counts may appear in various fields depending on the client
            tokens = (
                details.get("usage", {}).get("total_tokens") or
                details.get("token_count") or
                details.get("tokens") or
                details.get("inputTokens", 0) + details.get("outputTokens", 0)
            )

            try:
                tokens = int(tokens)
            except (TypeError, ValueError):
                continue

            if tokens > 0:
                session_tokens.setdefault(session_id, []).append(tokens)

        # Score each session for anomalous consumption
        for session_id, token_list in session_tokens.items():
            if len(token_list) < 2:
                continue

            total = sum(token_list)
            if total < RESOURCE_THEFT_MIN_TOKENS:
                continue

            mean = total / len(token_list)
            max_tokens = max(token_list)

            if max_tokens > mean * RESOURCE_THEFT_MULTIPLIER:
                findings.append(SamplingFinding(
                    id=self._fid(),
                    vector="resource_theft",
                    severity="high",
                    title=f"Anomalous token consumption in sampling: session {session_id[:8]}",
                    description=(
                        f"Session {session_id[:8]} has a sampling request consuming "
                        f"{max_tokens:,} tokens against a session mean of {int(mean):,}. "
                        f"This is {max_tokens/mean:.1f}x the baseline, consistent with "
                        f"the Unit 42 resource theft vector where a malicious server "
                        f"abuses sampling to drain compute quota."
                    ),
                    session_id=session_id,
                    evidence={
                        "session_id": session_id,
                        "max_tokens": max_tokens,
                        "session_mean_tokens": round(mean),
                        "multiplier": round(max_tokens / mean, 1),
                        "total_sampling_calls": len(token_list),
                    },
                    remediation=(
                        "Review which MCP server initiated the anomalous sampling request. "
                        "Check whether the sampled content is related to the session goal. "
                        "Consider adding per-session token budget enforcement."
                    ),
                    cmmc_controls=["3.14.2"],
                ))

        return findings

    # ------------------------------------------------------------------
    # Persist findings to audit DB
    # ------------------------------------------------------------------

    async def _persist(self, findings: list[SamplingFinding]) -> None:
        try:
            from aiglos_core.audit import AuditLog
            from aiglos_core.types import SecurityEvent, EventType, Severity

            audit = AuditLog(self.audit_db)
            smap = {
                "critical": Severity.CRITICAL,
                "high": Severity.HIGH,
                "medium": Severity.MEDIUM,
            }

            for f in findings:
                audit.record_event(SecurityEvent(
                    session_id=f.session_id,
                    event_type=EventType.ANOMALY_DETECTED,
                    severity=smap.get(f.severity, Severity.HIGH),
                    title=f.title,
                    description=f.description,
                    details=f.evidence,
                    cmmc_controls=f.cmmc_controls,
                ))
        except Exception as e:
            logger.debug("sampler_persist_failed", error=str(e))
