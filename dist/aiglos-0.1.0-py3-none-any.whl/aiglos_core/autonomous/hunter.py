"""Aiglos Threat Hunter - proactive MCP server scanner and forensic analyzer."""
from __future__ import annotations
import asyncio, json, re, time
from dataclasses import dataclass, field
from pathlib import Path
import structlog

logger = structlog.get_logger("aiglos.hunter")

@dataclass
class HuntFinding:
    id: str; hunt_type: str; severity: str; title: str; description: str
    evidence: dict = field(default_factory=dict); remediation: str = ""
    cmmc_controls: list = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)

@dataclass
class HuntResult:
    findings: list; hunts_run: list; duration_s: float
    sessions_analyzed: int; tool_calls_analyzed: int
    timestamp: float = field(default_factory=time.time)
    @property
    def critical_count(self): return sum(1 for f in self.findings if f.severity == "critical")
    @property
    def high_count(self): return sum(1 for f in self.findings if f.severity == "high")
    def summary(self):
        total = len(self.findings)
        if total == 0: return "Hunt complete. No findings. Threat level: NOMINAL."
        return (f"Hunt complete. {total} findings "
                f"({self.critical_count} critical, {self.high_count} high). "
                f"Sessions: {self.sessions_analyzed}, Tool calls: {self.tool_calls_analyzed}.")

class ThreatHunter:
    CREDENTIAL_PATTERNS = [
        (re.compile(r"sk-ant-api\d{2}-[A-Za-z0-9\-_]{93}"), "Anthropic API key"),
        (re.compile(r"AKIA[0-9A-Z]{16}"), "AWS Access Key ID"),
        (re.compile(r"ghp_[A-Za-z0-9]{36}"), "GitHub Personal Access Token"),
        (re.compile(r"ghs_[A-Za-z0-9]{36}"), "GitHub Actions Token"),
        (re.compile(r"(?i)password\s*[:=]\s*\S{8,}"), "Plaintext password"),
        (re.compile(r"eyJ[A-Za-z0-9\-_]{20,}\.eyJ[A-Za-z0-9\-_]+"), "JWT token"),
        (re.compile(r"xox[baprs]-[0-9A-Za-z\-]{10,}"), "Slack token"),
    ]
    INJECTION_PATTERNS = [
        (re.compile(r"(?i)ignore.{0,20}(previous|above|all).{0,20}(instruction|prompt|context)"),
         "Prompt injection: ignore instructions"),
        (re.compile(r"(?i)<\|system\|>|<s>|{{SYSTEM"),
         "Prompt injection: system tag injection"),
        (re.compile(r"(?i)you are now|pretend (you are|to be)|act as (a |an )?(different|new|evil|malicious)"),
         "Prompt injection: role override"),
        (re.compile(r"[\u200b\u200c\u200d\u200e\u200f\u202a-\u202e]"),
         "Unicode steganography"),
    ]

    def __init__(self, audit_db_path="aiglos_audit.db", config_paths=None, finding_threshold_per_run=100):
        self.audit_db_path = audit_db_path
        self.config_paths = config_paths if config_paths is not None else [
            str(Path.home() / ".clawdbot" / "config.yaml"),
            str(Path.home() / ".cursor" / "mcp.json"),
            str(Path.home() / ".config" / "Claude" / "claude_desktop_config.json"),
        ]
        self.max_findings = finding_threshold_per_run
        self._finding_counter = 0

    def _next_finding_id(self):
        self._finding_counter += 1
        return f"find-{self._finding_counter:06d}-{int(time.time())}"

    async def run_full_scan(self):
        start = time.monotonic(); all_findings = []; hunts_run = []
        sessions_analyzed = tool_calls_analyzed = 0
        logger.info("hunt_cycle_started")

        for module_name, module_coro in [
            ("exposure", self._hunt_exposure()),
            ("credential_scan", None),
            ("injection_hunt", None),
            ("behavioral_trend", None),
            ("policy_trend", self._hunt_policy_trends()),
            ("sampling_monitor", None),
            ("a2a_monitor", None),
            ("composition_scan", None),
        ]:
            try:
                if module_name == "credential_scan":
                    findings, tc = await self._hunt_credential_exposure()
                    tool_calls_analyzed += tc
                elif module_name == "injection_hunt":
                    findings, tc = await self._hunt_injection_patterns()
                    tool_calls_analyzed += tc
                elif module_name == "behavioral_trend":
                    findings, sess = await self._hunt_behavioral_trends()
                    sessions_analyzed += sess
                elif module_name == "sampling_monitor":
                    findings = await self._hunt_sampling()
                elif module_name == "a2a_monitor":
                    findings = await self._hunt_a2a()
                elif module_name == "composition_scan":
                    findings = await self._hunt_composition()
                else:
                    findings = await module_coro
                all_findings.extend(findings); hunts_run.append(module_name)
            except Exception as e:
                logger.warning("hunt_module_failed", module=module_name, error=str(e))

        elapsed = time.monotonic() - start
        result = HuntResult(findings=all_findings[:self.max_findings], hunts_run=hunts_run,
                            duration_s=round(elapsed, 2), sessions_analyzed=sessions_analyzed,
                            tool_calls_analyzed=tool_calls_analyzed)
        logger.info("hunt_cycle_complete", findings=len(all_findings),
                    critical=result.critical_count, duration_s=round(elapsed, 2))
        await self._persist_findings(result)
        return result

    async def _hunt_exposure(self):
        findings = []; await asyncio.sleep(0)
        for config_path in self.config_paths:
            path = Path(config_path)
            if not path.exists(): continue
            try:
                content = path.read_text()
                if re.search(r'"host"\s*:\s*"0\.0\.0\.0"', content):
                    findings.append(HuntFinding(
                        id=self._next_finding_id(), hunt_type="exposure", severity="critical",
                        title=f"MCP server exposed to all interfaces in {path.name}",
                        description=f"Config at {config_path} binds to 0.0.0.0.",
                        evidence={"config_path": config_path}, remediation="Change host to 127.0.0.1.",
                        cmmc_controls=["3.13.1", "3.13.5"]))
                if re.search(r'"auth"\s*:\s*(false|null|"none")', content, re.I):
                    findings.append(HuntFinding(
                        id=self._next_finding_id(), hunt_type="exposure", severity="critical",
                        title=f"MCP server running without authentication in {path.name}",
                        description=f"No auth configured at {config_path}.",
                        evidence={"config_path": config_path}, remediation="Enable authentication.",
                        cmmc_controls=["3.5.1", "3.5.2"]))
                for pattern, cred_type in self.CREDENTIAL_PATTERNS:
                    if pattern.search(content):
                        findings.append(HuntFinding(
                            id=self._next_finding_id(), hunt_type="credential", severity="critical",
                            title=f"{cred_type} found in MCP config file",
                            description=f"Credential in plaintext in {config_path}.",
                            evidence={"config_path": config_path, "credential_type": cred_type},
                            remediation="Use environment variables or a secrets manager.",
                            cmmc_controls=["3.13.10", "3.5.3"]))
                        break
            except Exception as e: logger.debug("config_scan_error", path=config_path, error=str(e))
        return findings

    async def _hunt_credential_exposure(self):
        findings = []; tc_count = 0
        try:
            from aiglos_core.audit import AuditLog
            audit = AuditLog(self.audit_db_path)
            recent = audit.get_recent_events(limit=500); tc_count = len(recent)
            for event in recent:
                details = event.get("details") or {}
                if isinstance(details, str):
                    try: details = json.loads(details)
                    except: details = {"raw": details}
                content = json.dumps(details)
                for pattern, cred_type in self.CREDENTIAL_PATTERNS:
                    if pattern.search(content):
                        findings.append(HuntFinding(
                            id=self._next_finding_id(), hunt_type="credential", severity="critical",
                            title=f"{cred_type} detected in tool call arguments",
                            description=f"Credential found in logged tool call for session {event.get('session_id','?')[:8]}.",
                            evidence={"session_id": event.get("session_id"), "credential_type": cred_type},
                            remediation="Rotate the exposed credential immediately.",
                            cmmc_controls=["3.13.10", "3.5.3"]))
                        break
        except Exception as e: logger.debug("credential_hunt_failed", error=str(e))
        return findings, tc_count

    async def _hunt_injection_patterns(self):
        findings = []; tc_count = 0
        try:
            from aiglos_core.audit import AuditLog
            audit = AuditLog(self.audit_db_path)
            recent = audit.get_recent_events(limit=500); tc_count = len(recent); seen = set()
            for event in recent:
                details = event.get("details") or {}
                if isinstance(details, str):
                    try: details = json.loads(details)
                    except: details = {"raw": details}
                content = json.dumps(details); session_id = event.get("session_id", "?")
                for pattern, inj_type in self.INJECTION_PATTERNS:
                    if pattern.search(content):
                        key = f"{session_id}-{inj_type}"
                        if key not in seen:
                            seen.add(key)
                            findings.append(HuntFinding(
                                id=self._next_finding_id(), hunt_type="injection_hunt", severity="high",
                                title=f"Prompt injection pattern: {inj_type}",
                                description=f"Injection '{inj_type}' in session {session_id[:8]}.",
                                evidence={"session_id": session_id, "injection_type": inj_type},
                                remediation="Review session for goal drift.",
                                cmmc_controls=["3.14.2", "3.13.1"]))
                        break
        except Exception as e: logger.debug("injection_hunt_failed", error=str(e))
        return findings, tc_count

    async def _hunt_behavioral_trends(self):
        findings = []; sess_count = 0
        try:
            from aiglos_core.audit import AuditLog
            audit = AuditLog(self.audit_db_path)
            sessions = audit.get_sessions(); sess_count = len(sessions)
            if sess_count < 5: return findings, sess_count
            high_anomaly = [s for s in sessions if s.get("anomaly_score", 0) > 0.7]
            high_drift = [s for s in sessions if s.get("goal_integrity_score", 1.0) < 0.4]
            if len(high_anomaly) >= 3:
                findings.append(HuntFinding(
                    id=self._next_finding_id(), hunt_type="behavioral_trend", severity="high",
                    title=f"Anomaly spike: {len(high_anomaly)} sessions with high anomaly scores",
                    description=f"{len(high_anomaly)}/{sess_count} sessions have anomaly scores above 0.7.",
                    evidence={"high_anomaly_sessions": len(high_anomaly), "total": sess_count},
                    remediation="Review sessions for commonalities. Check shared system prompt or MCP server.",
                    cmmc_controls=["3.14.2", "3.13.1"]))
            if len(high_drift) >= 2:
                findings.append(HuntFinding(
                    id=self._next_finding_id(), hunt_type="behavioral_trend", severity="critical",
                    title=f"Goal drift pattern: {len(high_drift)} sessions with severe deviation",
                    description=f"{len(high_drift)} sessions with goal integrity below 0.4.",
                    evidence={"drifted_sessions": len(high_drift)},
                    remediation="Investigate whether drift is from prompt injection.",
                    cmmc_controls=["3.14.2"]))
        except Exception as e: logger.debug("behavioral_trend_failed", error=str(e))
        return findings, sess_count

    async def _hunt_policy_trends(self):
        findings = []
        try:
            from aiglos_core.audit import AuditLog
            audit = AuditLog(self.audit_db_path)
            events = audit.get_recent_events(limit=1000); rule_counts = {}
            for event in events:
                if event.get("event_type") == "policy_violation":
                    details = event.get("details") or {}
                    if isinstance(details, str):
                        try: details = json.loads(details)
                        except: continue
                    rule = details.get("rule", "unknown")
                    rule_counts[rule] = rule_counts.get(rule, 0) + 1
            for rule, count in rule_counts.items():
                if count >= 5:
                    findings.append(HuntFinding(
                        id=self._next_finding_id(), hunt_type="policy_trend",
                        severity="critical" if count >= 20 else "high",
                        title=f"Policy rule '{rule}' violated {count} times",
                        description=f"Rule '{rule}' triggered {count} times. Possible probing or automated attack.",
                        evidence={"rule": rule, "violation_count": count},
                        remediation=f"Consider tightening rule '{rule}' to BLOCK if currently ALERT.",
                        cmmc_controls=["3.14.2", "3.13.1"]))
        except Exception as e: logger.debug("policy_trend_failed", error=str(e))
        return findings

    async def _persist_findings(self, result):
        if not result.findings: return
        try:
            from aiglos_core.audit import AuditLog
            from aiglos_core.types import SecurityEvent, EventType, Severity
            audit = AuditLog(self.audit_db_path)
            sev_map = {"critical": Severity.CRITICAL, "high": Severity.HIGH,
                       "medium": Severity.MEDIUM, "low": Severity.LOW}
            for finding in result.findings:
                audit.record_event(SecurityEvent(
                    session_id="aiglos-hunter",
                    event_type=EventType.ANOMALY_DETECTED,
                    severity=sev_map.get(finding.severity, Severity.MEDIUM),
                    title=finding.title, description=finding.description,
                    details=finding.evidence, cmmc_controls=finding.cmmc_controls,
                ))
        except Exception as e: logger.debug("findings_persist_failed", error=str(e))

    async def _hunt_sampling(self):
        """Module 6 - MCP Sampling Monitor (T24). Delegates to SamplingMonitor."""
        from aiglos_core.autonomous.sampler import SamplingMonitor
        monitor = SamplingMonitor(audit_db=self.audit_db_path)
        result = await monitor.scan()

        # Translate SamplingFinding -> HuntFinding
        findings = []
        for sf in result.findings:
            findings.append(HuntFinding(
                id=sf.id,
                module="sampling_monitor",
                severity=sf.severity,
                title=sf.title,
                description=sf.description,
                evidence=sf.evidence,
                remediation=sf.remediation,
                cmmc_controls=sf.cmmc_controls,
            ))
        return findings

    async def _hunt_a2a(self):
        """Module 7 - A2A Protocol Monitor (T29)."""
        from aiglos_core.autonomous.a2a import A2AMonitor
        monitor = A2AMonitor(audit_db=self.audit_db_path)
        a2a_findings = await monitor.scan()
        findings = []
        for f in a2a_findings:
            findings.append(HuntFinding(
                id=f.id, module="a2a_monitor",
                severity=f.severity, title=f.title,
                description=f.description, evidence=f.evidence,
                remediation=f.remediation, cmmc_controls=f.cmmc_controls,
            ))
        return findings

    async def _hunt_composition(self):
        """Module 8 - Skill Composition Analyzer (T32)."""
        from aiglos_core.autonomous.composer import SkillComposer
        composer = SkillComposer(audit_db=self.audit_db_path)
        comp_findings = await composer.scan()
        findings = []
        for f in comp_findings:
            findings.append(HuntFinding(
                id=f.id, module="composition_scan",
                severity=f.severity,
                title=f"Dangerous skill composition: {f.rule.name}",
                description=f.rule.description,
                evidence=f.evidence,
                remediation=f.rule.remediation,
                cmmc_controls=f.rule.cmmc_controls,
            ))
        return findings
