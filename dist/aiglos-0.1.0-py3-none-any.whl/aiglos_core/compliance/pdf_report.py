"""
Aiglos Compliance PDF Report Generator (T19).

Produces a multi-page, C3PAO-ready compliance report in PDF format.
One-click export from `aiglos report --format pdf`.

The report is structured for the actual audience: a C3PAO assessor
reviewing a defense contractor's AI/ML security posture. It contains:

  Cover page       Organization, assessment date, CMMC level, overall score
  Executive summary Key metrics at a glance with pass/fail indicators
  Control coverage  Per-control status table (NIST ID, family, status, evidence count)
  Event timeline    Chronological log of security events with severity color coding
  Section 1513      NDAA FY2026 readiness assessment, requirement by requirement
  Attestation index Inventory of signed session attestations with hash verification
  Methodology note  What Aiglos measures and how evidence maps to controls

Design language: Authoritative, monochromatic with amber/green/red accents.
No gradients, no decoration. The report should look like something a
government auditor would trust, not a SaaS marketing PDF.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

# ReportLab imports
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    HRFlowable,
    Image,
    KeepTogether,
    NextPageTemplate,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)
from reportlab.platypus.flowables import Flowable

# ---------------------------------------------------------------------------
# Color palette
# ---------------------------------------------------------------------------

C_BLACK = colors.HexColor("#080B0E")
C_DARK = colors.HexColor("#0C1014")
C_MID = colors.HexColor("#161C22")
C_BORDER = colors.HexColor("#2A3540")
C_TEXT = colors.HexColor("#E8EDF2")
C_DIM = colors.HexColor("#6B7A88")
C_AMBER = colors.HexColor("#F0A000")
C_AMBER_LIGHT = colors.HexColor("#FFC840")
C_GREEN = colors.HexColor("#00C878")
C_RED = colors.HexColor("#FF4040")
C_BLUE = colors.HexColor("#40AAFF")
C_YELLOW = colors.HexColor("#F0C000")
C_WHITE = colors.white

SEV_COLORS = {
    "critical": C_RED,
    "high": colors.HexColor("#FF7A00"),
    "medium": C_YELLOW,
    "low": C_BLUE,
    "info": C_DIM,
}

STATUS_COLORS = {
    "covered": C_GREEN,
    "partial": C_YELLOW,
    "not_covered": C_RED,
    "active": C_GREEN,
    "inactive": C_DIM,
}

# ---------------------------------------------------------------------------
# Input data model
# ---------------------------------------------------------------------------

@dataclass
class ControlCoverageRow:
    control_id: str
    family: str
    title: str
    status: str           # "covered" | "partial" | "not_covered"
    evidence_count: int
    cmmc_level: int = 2
    aiglos_feature: str = ""


@dataclass
class SecurityEventRow:
    timestamp: float
    event_type: str
    severity: str
    title: str
    session_id: str
    cmmc_controls: list[str] = field(default_factory=list)


@dataclass
class Section1513Row:
    requirement: str
    status: str           # "active" | "inactive"
    feature: str = ""
    note: str = ""


@dataclass
class AttestationRow:
    session_id: str
    model: str
    timestamp: float
    document_hash: str
    event_count: int
    goal_integrity: float = 1.0


@dataclass
class ReportInput:
    """All data needed to generate the PDF report."""

    # Organization / metadata
    organization: str = "Defense Contractor Organization"
    report_id: str = ""
    cmmc_level: int = 2
    assessment_date: str = ""
    generated_by: str = "Aiglos 0.1.0"
    time_window_days: int = 30

    # Control coverage
    controls: list[ControlCoverageRow] = field(default_factory=list)

    # Security events
    events: list[SecurityEventRow] = field(default_factory=list)

    # Section 1513
    s1513: list[Section1513Row] = field(default_factory=list)

    # Attestations
    attestations: list[AttestationRow] = field(default_factory=list)

    # Summary stats
    total_sessions: int = 0
    total_tool_calls: int = 0
    total_blocked: int = 0
    avg_goal_integrity: float = 0.0

    def __post_init__(self):
        if not self.report_id:
            ts = str(time.time()).encode()
            self.report_id = hashlib.sha256(ts).hexdigest()[:12].upper()
        if not self.assessment_date:
            self.assessment_date = datetime.now(tz=timezone.utc).strftime("%B %d, %Y")

    @property
    def covered_count(self) -> int:
        return sum(1 for c in self.controls if c.status == "covered")

    @property
    def partial_count(self) -> int:
        return sum(1 for c in self.controls if c.status == "partial")

    @property
    def not_covered_count(self) -> int:
        return sum(1 for c in self.controls if c.status == "not_covered")

    @property
    def coverage_pct(self) -> float:
        if not self.controls:
            return 0.0
        score = self.covered_count + self.partial_count * 0.5
        return round(score / len(self.controls) * 100, 1)

    @property
    def critical_events(self) -> int:
        return sum(1 for e in self.events if e.severity == "critical")

    @property
    def high_events(self) -> int:
        return sum(1 for e in self.events if e.severity == "high")

    @property
    def s1513_active_count(self) -> int:
        return sum(1 for r in self.s1513 if r.status == "active")


# ---------------------------------------------------------------------------
# Page template canvas callback
# ---------------------------------------------------------------------------

def _header_footer(canvas, doc):
    """Draw consistent header/footer on every page."""
    canvas.saveState()
    w, h = letter

    # Top rule
    canvas.setFillColor(C_AMBER)
    canvas.rect(0, h - 0.08 * inch, w, 0.05 * inch, fill=1, stroke=0)

    # Header bar
    canvas.setFillColor(C_DARK)
    canvas.rect(0, h - 0.55 * inch, w, 0.47 * inch, fill=1, stroke=0)

    # Header text
    canvas.setFont("Helvetica-Bold", 8)
    canvas.setFillColor(C_AMBER)
    canvas.drawString(0.4 * inch, h - 0.38 * inch, "AIGLOS")
    canvas.setFont("Helvetica", 7)
    canvas.setFillColor(C_DIM)
    canvas.drawString(0.4 * inch, h - 0.49 * inch, "AI AGENT SECURITY RUNTIME")

    # Report ID in header
    canvas.setFont("Helvetica", 7)
    canvas.setFillColor(C_DIM)
    canvas.drawRightString(w - 0.4 * inch, h - 0.38 * inch, f"REPORT {doc.report_id}")
    canvas.drawRightString(w - 0.4 * inch, h - 0.49 * inch, "CONFIDENTIAL")

    # Footer
    canvas.setFillColor(C_BORDER)
    canvas.rect(0, 0.3 * inch, w, 0.001 * inch, fill=1, stroke=0)

    canvas.setFont("Helvetica", 7)
    canvas.setFillColor(C_DIM)
    canvas.drawString(0.4 * inch, 0.18 * inch, f"Aiglos CMMC Compliance Report  |  {doc.assessment_date}")
    canvas.drawRightString(w - 0.4 * inch, 0.18 * inch, f"Page {doc.page}")

    canvas.restoreState()


# ---------------------------------------------------------------------------
# Style helpers
# ---------------------------------------------------------------------------

def _styles():
    base = getSampleStyleSheet()

    return {
        "title": ParagraphStyle("cg_title",
            fontName="Helvetica-Bold", fontSize=22, textColor=C_TEXT,
            spaceAfter=6, leading=26),
        "subtitle": ParagraphStyle("cg_subtitle",
            fontName="Helvetica", fontSize=11, textColor=C_DIM,
            spaceAfter=20, leading=16),
        "h1": ParagraphStyle("cg_h1",
            fontName="Helvetica-Bold", fontSize=13, textColor=C_AMBER,
            spaceBefore=18, spaceAfter=8, leading=16,
            borderPad=0, leftIndent=0),
        "h2": ParagraphStyle("cg_h2",
            fontName="Helvetica-Bold", fontSize=10, textColor=C_TEXT,
            spaceBefore=10, spaceAfter=4, leading=14),
        "body": ParagraphStyle("cg_body",
            fontName="Helvetica", fontSize=9, textColor=C_DIM,
            spaceAfter=6, leading=14),
        "mono": ParagraphStyle("cg_mono",
            fontName="Courier", fontSize=8, textColor=C_TEXT,
            spaceAfter=4, leading=12),
        "mono_dim": ParagraphStyle("cg_mono_dim",
            fontName="Courier", fontSize=8, textColor=C_DIM,
            spaceAfter=2, leading=12),
        "label": ParagraphStyle("cg_label",
            fontName="Helvetica-Bold", fontSize=7, textColor=C_DIM,
            spaceAfter=2, leading=10, wordWrap='LTR'),
        "metric_value": ParagraphStyle("cg_metric",
            fontName="Helvetica-Bold", fontSize=20, textColor=C_TEXT,
            spaceAfter=2, leading=22),
        "metric_label": ParagraphStyle("cg_metric_label",
            fontName="Helvetica", fontSize=7, textColor=C_DIM,
            leading=10),
        "status_covered": ParagraphStyle("cg_covered",
            fontName="Helvetica-Bold", fontSize=7, textColor=C_GREEN,
            leading=10),
        "status_partial": ParagraphStyle("cg_partial",
            fontName="Helvetica-Bold", fontSize=7, textColor=C_YELLOW,
            leading=10),
        "status_not_covered": ParagraphStyle("cg_not_covered",
            fontName="Helvetica-Bold", fontSize=7, textColor=C_RED,
            leading=10),
        "table_header": ParagraphStyle("cg_table_header",
            fontName="Helvetica-Bold", fontSize=7, textColor=C_DIM,
            leading=10),
        "table_cell": ParagraphStyle("cg_table_cell",
            fontName="Helvetica", fontSize=8, textColor=C_TEXT,
            leading=11, wordWrap='LTR'),
        "table_cell_dim": ParagraphStyle("cg_table_cell_dim",
            fontName="Helvetica", fontSize=7, textColor=C_DIM,
            leading=10, wordWrap='LTR'),
        "table_cell_mono": ParagraphStyle("cg_table_cell_mono",
            fontName="Courier", fontSize=7, textColor=C_AMBER,
            leading=10),
    }


def _sev_style(sev: str, styles: dict) -> ParagraphStyle:
    color = SEV_COLORS.get(sev, C_DIM)
    return ParagraphStyle(f"cg_sev_{sev}",
        fontName="Helvetica-Bold", fontSize=7, textColor=color, leading=10)


def _status_style(status: str, styles: dict) -> ParagraphStyle:
    if status == "covered":
        return styles["status_covered"]
    elif status == "partial":
        return styles["status_partial"]
    return styles["status_not_covered"]


# ---------------------------------------------------------------------------
# Section builders
# ---------------------------------------------------------------------------

def _dark_rule(width=None):
    return HRFlowable(
        width=width or "100%",
        thickness=0.5,
        color=C_BORDER,
        spaceAfter=8,
        spaceBefore=4,
    )


def _section_header(title: str, styles: dict) -> list:
    return [
        Paragraph(title.upper(), styles["h1"]),
        _dark_rule(),
    ]


def _metric_box(label: str, value: str, color=None, styles: dict = None) -> Table:
    """A single stat card as a Table cell."""
    val_style = ParagraphStyle("mv",
        fontName="Helvetica-Bold", fontSize=18,
        textColor=color or C_TEXT, leading=20)
    lbl_style = ParagraphStyle("ml",
        fontName="Helvetica", fontSize=7,
        textColor=C_DIM, leading=10)
    t = Table(
        [[Paragraph(value, val_style)], [Paragraph(label.upper(), lbl_style)]],
        colWidths=[1.4 * inch],
        rowHeights=[0.28 * inch, 0.2 * inch],
    )
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), C_MID),
        ("BOX", (0, 0), (-1, -1), 0.5, C_BORDER),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (0, 0), 8),
        ("BOTTOMPADDING", (0, -1), (-1, -1), 6),
        ("LINEABOVE", (0, 0), (-1, 0), 2, color or C_AMBER),
    ]))
    return t


def _build_cover(report: ReportInput, styles: dict) -> list:
    story = []
    story.append(Spacer(1, 1.4 * inch))

    # Classification banner
    banner = Table(
        [[Paragraph("CONFIDENTIAL  /  FOR AUTHORIZED USE ONLY", ParagraphStyle(
            "cls", fontName="Helvetica-Bold", fontSize=8,
            textColor=C_DARK, alignment=TA_CENTER, leading=12))]],
        colWidths=[7.2 * inch],
        rowHeights=[0.28 * inch],
    )
    banner.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), C_AMBER),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(banner)
    story.append(Spacer(1, 0.35 * inch))

    # Report title
    story.append(Paragraph("CMMC Compliance Report", styles["title"]))
    story.append(Paragraph(
        f"AI Agent Security Assessment  |  CMMC Level {report.cmmc_level}  |  NIST SP 800-171 Rev 2",
        styles["subtitle"]))
    story.append(_dark_rule())
    story.append(Spacer(1, 0.25 * inch))

    # Organization / metadata table
    meta_data = [
        ["Organization", report.organization],
        ["Report ID", report.report_id],
        ["Assessment Date", report.assessment_date],
        ["CMMC Level", f"Level {report.cmmc_level}"],
        ["Time Window", f"Last {report.time_window_days} days"],
        ["Generated By", report.generated_by],
    ]
    meta_table = Table(meta_data, colWidths=[1.8 * inch, 4.4 * inch])
    meta_table.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("TEXTCOLOR", (0, 0), (0, -1), C_DIM),
        ("TEXTCOLOR", (1, 0), (1, -1), C_TEXT),
        ("ROWBACKGROUNDS", (0, 0), (-1, -1), [C_DARK, C_MID]),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("LINEBELOW", (0, -1), (-1, -1), 0.5, C_BORDER),
    ]))
    story.append(meta_table)
    story.append(Spacer(1, 0.35 * inch))

    # Coverage indicator
    pct = report.coverage_pct
    pct_color = C_GREEN if pct >= 80 else C_YELLOW if pct >= 50 else C_RED
    cov_label = ParagraphStyle("cl",
        fontName="Helvetica-Bold", fontSize=36,
        textColor=pct_color, leading=40)
    story.append(Paragraph(f"{pct}%", cov_label))
    story.append(Paragraph(
        f"Overall CMMC Level {report.cmmc_level} control coverage  "
        f"({report.covered_count} covered, {report.partial_count} partial, "
        f"{report.not_covered_count} not covered of {len(report.controls)} applicable controls)",
        styles["body"]))

    story.append(PageBreak())
    return story


def _build_executive_summary(report: ReportInput, styles: dict) -> list:
    story = _section_header("Executive Summary", styles)

    story.append(Paragraph(
        f"This report summarizes the AI agent security posture assessed by Aiglos "
        f"during the {report.time_window_days}-day period ending {report.assessment_date}. "
        f"Aiglos operates as a transparent proxy for all MCP (Model Context Protocol) "
        f"tool calls made by AI agents in the assessed environment, providing real-time "
        f"interception, policy enforcement, goal integrity verification, and cryptographic "
        f"session attestation. All security events generated during the assessment period "
        f"are mapped to the corresponding NIST SP 800-171 Rev 2 controls and CMMC Level "
        f"{report.cmmc_level} requirements documented in this report.",
        styles["body"]))

    story.append(Spacer(1, 0.15 * inch))

    # Metric row
    pct = report.coverage_pct
    pct_color = C_GREEN if pct >= 80 else C_YELLOW if pct >= 50 else C_RED
    gi_color = C_GREEN if report.avg_goal_integrity >= 0.7 else C_YELLOW

    metrics = [
        _metric_box("Control Coverage", f"{pct}%", pct_color, styles),
        _metric_box("Sessions Monitored", str(report.total_sessions), C_TEXT, styles),
        _metric_box("Tool Calls Intercepted", f"{report.total_tool_calls:,}", C_TEXT, styles),
        _metric_box("Calls Blocked", str(report.total_blocked),
            C_RED if report.total_blocked > 0 else C_GREEN, styles),
        _metric_box("Critical Events", str(report.critical_events),
            C_RED if report.critical_events > 0 else C_GREEN, styles),
    ]
    metric_row = Table([metrics],
        colWidths=[1.5 * inch] * 5,
        rowHeights=[0.58 * inch])
    metric_row.setStyle(TableStyle([
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
    ]))
    story.append(metric_row)
    story.append(Spacer(1, 0.2 * inch))

    # Section 1513 callout
    s_pct = int(report.s1513_active_count / max(len(report.s1513), 1) * 100)
    s_color = C_GREEN if s_pct == 100 else C_YELLOW
    callout_data = [[
        Paragraph("NDAA FY2026 SECTION 1513 READINESS", ParagraphStyle(
            "co_l", fontName="Helvetica-Bold", fontSize=8, textColor=C_DIM, leading=10)),
        Paragraph(f"{report.s1513_active_count}/{len(report.s1513)} Requirements Active",
            ParagraphStyle("co_v", fontName="Helvetica-Bold", fontSize=11,
                textColor=s_color, leading=14)),
    ]]
    callout = Table(callout_data, colWidths=[3.0 * inch, 4.2 * inch])
    callout.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), C_MID),
        ("BOX", (0, 0), (-1, -1), 0.5, C_BORDER),
        ("LINEABOVE", (0, 0), (-1, 0), 2, s_color),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("LEFTPADDING", (0, 0), (-1, -1), 12),
    ]))
    story.append(callout)
    story.append(Spacer(1, 0.15 * inch))

    # Key findings
    story.append(Paragraph("Key Findings", styles["h2"]))
    findings = [
        f"CMMC Level {report.cmmc_level} control coverage: {pct}% "
        f"({report.covered_count} of {len(report.controls)} controls fully covered)",
        f"{report.total_sessions} agent sessions monitored with {report.total_tool_calls:,} "
        f"tool call interceptions during the assessment period.",
        f"{report.total_blocked} tool calls blocked by policy enforcement engine.",
        f"{report.critical_events} critical-severity security events detected "
        f"({report.high_events} high-severity).",
        f"Section 1513 NDAA FY2026: {report.s1513_active_count} of "
        f"{len(report.s1513)} anticipated framework requirements are actively met.",
        f"{len(report.attestations)} cryptographically signed session attestations "
        "produced and available for audit review.",
    ]
    for finding in findings:
        story.append(Paragraph(f"\u2022  {finding}", styles["body"]))

    story.append(PageBreak())
    return story


def _build_control_coverage(report: ReportInput, styles: dict) -> list:
    story = _section_header("CMMC Control Coverage", styles)
    story.append(Paragraph(
        f"The following table shows coverage status for each NIST SP 800-171 Rev 2 control "
        f"applicable under CMMC Level {report.cmmc_level}. Evidence counts reflect the number "
        f"of security events generated by Aiglos that provide direct evidence of control "
        f"implementation during the assessment period.",
        styles["body"]))
    story.append(Spacer(1, 0.1 * inch))

    # Group by family
    by_family: dict[str, list[ControlCoverageRow]] = {}
    for ctrl in report.controls:
        by_family.setdefault(ctrl.family, []).append(ctrl)

    for family, ctrls in sorted(by_family.items()):
        story.append(Paragraph(family.upper(), ParagraphStyle(
            "fam", fontName="Helvetica-Bold", fontSize=8,
            textColor=C_AMBER, spaceBefore=12, spaceAfter=4, leading=12)))

        header = [
            Paragraph("CONTROL ID", styles["table_header"]),
            Paragraph("TITLE", styles["table_header"]),
            Paragraph("STATUS", styles["table_header"]),
            Paragraph("EVIDENCE", styles["table_header"]),
        ]
        rows = [header]
        for ctrl in sorted(ctrls, key=lambda c: c.control_id):
            status_label = ctrl.status.replace("_", " ").upper()
            status_color = STATUS_COLORS.get(ctrl.status, C_DIM)
            rows.append([
                Paragraph(ctrl.control_id, styles["table_cell_mono"]),
                Paragraph(ctrl.title, styles["table_cell"]),
                Paragraph(status_label, ParagraphStyle(
                    f"st_{ctrl.status}", fontName="Helvetica-Bold",
                    fontSize=7, textColor=status_color, leading=10)),
                Paragraph(str(ctrl.evidence_count), styles["table_cell_dim"]),
            ])

        col_widths = [0.9 * inch, 4.5 * inch, 1.0 * inch, 0.8 * inch]
        tbl = Table(rows, colWidths=col_widths, repeatRows=1)
        tbl.setStyle(TableStyle([
            # Header
            ("BACKGROUND", (0, 0), (-1, 0), C_MID),
            ("LINEBELOW", (0, 0), (-1, 0), 0.5, C_BORDER),
            # Rows
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [C_DARK, C_MID]),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ("LEFTPADDING", (0, 0), (-1, -1), 8),
            ("RIGHTPADDING", (0, 0), (-1, -1), 8),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("BOX", (0, 0), (-1, -1), 0.5, C_BORDER),
            ("INNERGRID", (0, 0), (-1, -1), 0.25, C_BORDER),
        ]))
        story.append(tbl)
        story.append(Spacer(1, 0.06 * inch))

    story.append(PageBreak())
    return story


def _build_event_timeline(report: ReportInput, styles: dict) -> list:
    story = _section_header("Security Event Log", styles)
    story.append(Paragraph(
        f"Chronological log of security events intercepted during the assessment period. "
        f"Critical and high-severity events represent direct audit evidence for the "
        f"corresponding CMMC controls listed in each row.",
        styles["body"]))
    story.append(Spacer(1, 0.1 * inch))

    if not report.events:
        story.append(Paragraph("No security events recorded during the assessment period.",
            styles["body"]))
        story.append(PageBreak())
        return story

    # Sort by severity then timestamp
    sev_order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    sorted_events = sorted(
        report.events,
        key=lambda e: (sev_order.get(e.severity, 5), -e.timestamp)
    )

    header = [
        Paragraph("TIME", styles["table_header"]),
        Paragraph("SEV", styles["table_header"]),
        Paragraph("TYPE", styles["table_header"]),
        Paragraph("TITLE", styles["table_header"]),
        Paragraph("SESSION", styles["table_header"]),
        Paragraph("CMMC", styles["table_header"]),
    ]
    rows = [header]
    for ev in sorted_events[:100]:  # Cap at 100 events per report
        ts = datetime.fromtimestamp(ev.timestamp, tz=timezone.utc).strftime("%m/%d %H:%M")
        sev_color = SEV_COLORS.get(ev.severity, C_DIM)
        cmmc_str = ", ".join(ev.cmmc_controls[:3])
        rows.append([
            Paragraph(ts, styles["table_cell_dim"]),
            Paragraph(ev.severity.upper(), ParagraphStyle(
                f"sev_td_{ev.severity}", fontName="Helvetica-Bold",
                fontSize=6, textColor=sev_color, leading=9)),
            Paragraph(ev.event_type.replace("_", " "), styles["table_cell_dim"]),
            Paragraph(ev.title[:60], styles["table_cell"]),
            Paragraph(ev.session_id[:10] + "...", styles["table_cell_dim"]),
            Paragraph(cmmc_str, styles["table_cell_dim"]),
        ])

    col_widths = [0.65*inch, 0.5*inch, 1.1*inch, 2.6*inch, 0.9*inch, 1.45*inch]
    tbl = Table(rows, colWidths=col_widths, repeatRows=1)
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), C_MID),
        ("LINEBELOW", (0, 0), (-1, 0), 0.5, C_BORDER),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [C_DARK, C_MID]),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("BOX", (0, 0), (-1, -1), 0.5, C_BORDER),
        ("INNERGRID", (0, 0), (-1, -1), 0.25, C_BORDER),
    ]))
    story.append(tbl)

    if len(report.events) > 100:
        story.append(Spacer(1, 0.08 * inch))
        story.append(Paragraph(
            f"Note: Showing 100 of {len(report.events)} total events. "
            "Full event log available via aiglos logs --export.",
            styles["body"]))

    story.append(PageBreak())
    return story


def _build_s1513(report: ReportInput, styles: dict) -> list:
    story = _section_header("Section 1513 NDAA FY2026 Readiness", styles)
    story.append(Paragraph(
        "Section 1513 of the National Defense Authorization Act for Fiscal Year 2026 directs "
        "the Department of Defense to develop and implement a cybersecurity framework for AI/ML "
        "technologies acquired by the Pentagon, to be incorporated into CMMC. The DoD status "
        "report to Congress is due June 16, 2026. The table below shows how Aiglos addresses "
        "each anticipated framework requirement.",
        styles["body"]))
    story.append(Spacer(1, 0.1 * inch))

    if not report.s1513:
        story.append(Paragraph("No Section 1513 requirements configured.", styles["body"]))
        story.append(PageBreak())
        return story

    header = [
        Paragraph("#", styles["table_header"]),
        Paragraph("REQUIREMENT", styles["table_header"]),
        Paragraph("STATUS", styles["table_header"]),
        Paragraph("AIGLOS FEATURE", styles["table_header"]),
    ]
    rows = [header]
    for i, req in enumerate(report.s1513, 1):
        s_color = STATUS_COLORS.get(req.status, C_DIM)
        rows.append([
            Paragraph(str(i), styles["table_cell_dim"]),
            Paragraph(req.requirement, styles["table_cell"]),
            Paragraph(req.status.upper(), ParagraphStyle(
                f"s1513_st_{i}", fontName="Helvetica-Bold",
                fontSize=7, textColor=s_color, leading=10)),
            Paragraph(req.feature, styles["table_cell_dim"]),
        ])

    col_widths = [0.35*inch, 3.5*inch, 0.75*inch, 2.6*inch]
    tbl = Table(rows, colWidths=col_widths, repeatRows=1)
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), C_MID),
        ("LINEBELOW", (0, 0), (-1, 0), 0.5, C_BORDER),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [C_DARK, C_MID]),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("BOX", (0, 0), (-1, -1), 0.5, C_BORDER),
        ("INNERGRID", (0, 0), (-1, -1), 0.25, C_BORDER),
    ]))
    story.append(tbl)
    story.append(Spacer(1, 0.15 * inch))

    active = report.s1513_active_count
    total = len(report.s1513)
    conclusion_color = C_GREEN if active == total else C_YELLOW
    story.append(Paragraph(
        f"{active} of {total} Section 1513 requirements are currently met by Aiglos. "
        "This assessment will be updated as the DoD framework is finalized.",
        ParagraphStyle("s1513_conc", fontName="Helvetica-Bold", fontSize=9,
            textColor=conclusion_color, leading=13, spaceAfter=8)))

    story.append(PageBreak())
    return story


def _build_attestation_index(report: ReportInput, styles: dict) -> list:
    story = _section_header("Session Attestation Index", styles)
    story.append(Paragraph(
        "Each agent session monitored by Aiglos produces a cryptographically signed "
        "attestation document containing: model identity, system prompt hash, tool "
        "permissions, session timeline, security posture scores, and a per-event SHA-256 "
        "manifest. Attestation documents are RSA-2048 signed and tamper-evident.",
        styles["body"]))
    story.append(Spacer(1, 0.1 * inch))

    if not report.attestations:
        story.append(Paragraph("No attestation records available for this period.", styles["body"]))
        story.append(PageBreak())
        return story

    header = [
        Paragraph("SESSION ID", styles["table_header"]),
        Paragraph("MODEL", styles["table_header"]),
        Paragraph("DATE/TIME", styles["table_header"]),
        Paragraph("EVENTS", styles["table_header"]),
        Paragraph("INTEGRITY", styles["table_header"]),
        Paragraph("DOCUMENT HASH (PARTIAL)", styles["table_header"]),
    ]
    rows = [header]
    for att in sorted(report.attestations, key=lambda a: -a.timestamp)[:40]:
        ts = datetime.fromtimestamp(att.timestamp, tz=timezone.utc).strftime("%m/%d %H:%M")
        gi_color = C_GREEN if att.goal_integrity >= 0.7 else C_YELLOW if att.goal_integrity >= 0.35 else C_RED
        rows.append([
            Paragraph(att.session_id[:14] + "...", styles["table_cell_dim"]),
            Paragraph(att.model[:22], styles["table_cell_dim"]),
            Paragraph(ts, styles["table_cell_dim"]),
            Paragraph(str(att.event_count), styles["table_cell_dim"]),
            Paragraph(f"{att.goal_integrity:.0%}", ParagraphStyle(
                "gi", fontName="Helvetica-Bold", fontSize=7,
                textColor=gi_color, leading=10)),
            Paragraph(att.document_hash[:24] + "...", styles["table_cell_mono"]),
        ])

    col_widths = [1.1*inch, 1.3*inch, 0.85*inch, 0.6*inch, 0.65*inch, 2.65*inch]
    tbl = Table(rows, colWidths=col_widths, repeatRows=1)
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), C_MID),
        ("LINEBELOW", (0, 0), (-1, 0), 0.5, C_BORDER),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [C_DARK, C_MID]),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING", (0, 0), (-1, -1), 7),
        ("RIGHTPADDING", (0, 0), (-1, -1), 7),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("BOX", (0, 0), (-1, -1), 0.5, C_BORDER),
        ("INNERGRID", (0, 0), (-1, -1), 0.25, C_BORDER),
    ]))
    story.append(tbl)

    if len(report.attestations) > 40:
        story.append(Spacer(1, 0.08 * inch))
        story.append(Paragraph(
            f"Showing 40 of {len(report.attestations)} attestations. "
            "Full index available via aiglos attest --list.",
            styles["body"]))

    story.append(PageBreak())
    return story


def _build_methodology(report: ReportInput, styles: dict) -> list:
    story = _section_header("Methodology and Scope", styles)

    sections = [
        ("Proxy Architecture",
         "Aiglos operates as a transparent WebSocket proxy positioned between AI agents "
         "and their MCP (Model Context Protocol) servers. Every tool call passes through the "
         "Aiglos security pipeline before reaching the upstream server. No agent code "
         "modification is required."),
        ("Security Pipeline",
         "Each tool call is evaluated by: (1) Credential scanner -- 20+ secret patterns "
         "in tool arguments; (2) Policy engine -- YAML-defined rules with glob matching; "
         "(3) Goal integrity engine -- semantic evaluation of alignment with authorized "
         "objective; (4) Behavioral baseline -- statistical anomaly detection against "
         "per-agent fingerprint; (5) Trust registry -- MCP server allowlist/blocklist with "
         "tool manifest fingerprinting."),
        ("Evidence Mapping",
         "Security events are automatically mapped to NIST SP 800-171 Rev 2 controls at "
         "the time of event generation. Evidence counts in this report represent the number "
         "of distinct events providing audit evidence for each control. A control is classified "
         "as 'covered' when 3+ evidence events are present; 'partial' for 1-2 events; and "
         "'not covered' when no relevant activity occurred during the assessment period."),
        ("Attestation Integrity",
         "Session attestation documents are RSA-2048 signed using keys stored at "
         "~/.aiglos/keys/attestation_default.pem (or via AIGLOS_SIGNING_KEY "
         "environment variable for air-gapped deployments). Documents are tamper-evident: "
         "any modification to session_id, security_posture, event_manifest, or model_identity "
         "invalidates the signature. Attestation documents can be independently verified "
         "with: aiglos verify <document.json>"),
        ("Limitations",
         "Aiglos provides evidence of security controls at the agent/MCP layer. It does "
         "not assess underlying infrastructure controls, network security, or physical security. "
         "Goal integrity semantic evaluation requires a valid Anthropic API key; without it, "
         "the fast-path rule-based evaluation operates but semantic scoring is unavailable. "
         "Behavioral baseline anomaly detection requires a minimum of 2 baseline sessions "
         "before producing anomaly scores."),
    ]

    for title, body in sections:
        story.append(Paragraph(title, styles["h2"]))
        story.append(Paragraph(body, styles["body"]))
        story.append(Spacer(1, 0.08 * inch))

    return story


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def generate_compliance_pdf(report: ReportInput, output_path: str) -> str:
    """
    Generate a PDF compliance report and save it to output_path.
    Returns the path of the generated file.
    """
    doc = SimpleDocTemplate(
        output_path,
        pagesize=letter,
        leftMargin=0.5 * inch,
        rightMargin=0.5 * inch,
        topMargin=0.7 * inch,
        bottomMargin=0.5 * inch,
        title=f"Aiglos CMMC Compliance Report - {report.report_id}",
        author="Aiglos 0.1.0",
        subject=f"CMMC Level {report.cmmc_level} Assessment",
        creator="Aiglos AI Agent Security Runtime",
    )

    # Attach report metadata to doc for header/footer access
    doc.report_id = report.report_id
    doc.assessment_date = report.assessment_date

    styles = _styles()
    story = []

    story.extend(_build_cover(report, styles))
    story.extend(_build_executive_summary(report, styles))
    story.extend(_build_control_coverage(report, styles))
    story.extend(_build_event_timeline(report, styles))
    story.extend(_build_s1513(report, styles))
    story.extend(_build_attestation_index(report, styles))
    story.extend(_build_methodology(report, styles))

    doc.build(story, onFirstPage=_header_footer, onLaterPages=_header_footer)
    return output_path


# ---------------------------------------------------------------------------
# Sample data builder (for CLI demo and tests)
# ---------------------------------------------------------------------------

DEFAULT_CONTROLS = [
    ControlCoverageRow("3.1.1", "Access Control", "Authorized Access Control", "covered", 34),
    ControlCoverageRow("3.1.2", "Access Control", "Transaction and Function Control", "covered", 28),
    ControlCoverageRow("3.1.3", "Access Control", "Control CUI Flow", "covered", 19),
    ControlCoverageRow("3.3.1", "Audit & Accountability", "System Auditing", "covered", 187),
    ControlCoverageRow("3.3.2", "Audit & Accountability", "User Accountability", "covered", 41),
    ControlCoverageRow("3.5.1", "Identification & Auth", "User Identification", "covered", 23),
    ControlCoverageRow("3.5.2", "Identification & Auth", "User Authentication", "covered", 23),
    ControlCoverageRow("3.4.1", "Config Management", "Baseline Configuration", "covered", 55),
    ControlCoverageRow("3.4.2", "Config Management", "Configuration Settings", "partial", 12),
    ControlCoverageRow("3.13.1", "System & Comms Protection", "Boundary Protection", "covered", 187),
    ControlCoverageRow("3.13.3", "System & Comms Protection", "Security Function Isolation", "covered", 7),
    ControlCoverageRow("3.13.10", "System & Comms Protection", "Cryptographic Key Management", "covered", 23),
    ControlCoverageRow("3.13.16", "System & Comms Protection", "CUI at Rest", "covered", 14),
    ControlCoverageRow("3.14.1", "System Integrity", "Flaw Remediation", "partial", 8),
    ControlCoverageRow("3.14.2", "System Integrity", "Malicious Code Protection", "covered", 31),
    ControlCoverageRow("3.14.6", "System Integrity", "Security Alert Monitoring", "covered", 55),
    ControlCoverageRow("3.14.7", "System Integrity", "Identify Unauthorized Use", "covered", 7),
]

DEFAULT_S1513 = [
    Section1513Row("AI system identity and version tracking", "active",
        "Agent Identity Attestation (T7)"),
    Section1513Row("Authorized objective registration and drift monitoring", "active",
        "Goal Integrity Engine (T6)"),
    Section1513Row("Human oversight and intervention capability", "active",
        "Policy Engine REQUIRE_APPROVAL action (T10)"),
    Section1513Row("Comprehensive audit trail for AI actions", "active",
        "SQLite Audit Log with WAL mode (T5)"),
    Section1513Row("Detection of adversarial inputs and prompt injection", "active",
        "Command injection / path traversal / goal drift detection (T3, T6)"),
    Section1513Row("Cryptographic integrity of AI session records", "active",
        "RSA-2048 signed session attestations (T7)"),
    Section1513Row("Credential and sensitive data protection", "active",
        "Real-time credential scanner (T4)"),
    Section1513Row("Configuration baseline enforcement", "active",
        "YAML policy engine (T10)"),
    Section1513Row("Multi-agent trust and authentication", "active",
        "MCP Server Trust Registry with fingerprinting (T8)"),
    Section1513Row("Real-time alerting on AI security anomalies", "active",
        "Alert Dispatcher: Splunk / Syslog / Slack / webhook (T15)"),
]


def build_sample_report(organization: str = "Example Defense Contractor LLC") -> ReportInput:
    """Build a fully-populated sample report for demo and testing."""
    import random
    rng = random.Random(42)

    events = []
    event_templates = [
        ("credential_detected", "critical", "Credential detected: AWS Access Key in tool arguments",
         ["3.13.10", "3.13.16"]),
        ("goal_drift", "high", "Goal drift detected (integrity score: 0.21)",
         ["3.13.3", "3.14.7"]),
        ("command_injection", "critical", "Command injection pattern blocked: bash tool",
         ["3.14.2", "3.14.6"]),
        ("policy_violation", "high", "Policy block: sudo execution attempted",
         ["3.1.1", "3.1.2"]),
        ("tool_call", "info", "Tool call intercepted: read_file",
         ["3.3.1"]),
        ("agent_attested", "info", "Session attestation produced",
         ["3.3.2", "3.5.2"]),
        ("behavioral_anomaly", "medium", "Behavioral anomaly: unusual tool sequence detected",
         ["3.14.6", "3.14.7"]),
        ("server_untrusted", "high", "Unknown MCP server detected: dev.staging.internal:9000",
         ["3.13.1", "3.1.1"]),
    ]
    base_ts = time.time() - 86400 * 7
    for i in range(48):
        tpl = event_templates[rng.randint(0, len(event_templates) - 1)]
        events.append(SecurityEventRow(
            timestamp=base_ts + rng.uniform(0, 86400 * 7),
            event_type=tpl[0],
            severity=tpl[1],
            title=tpl[2],
            session_id="sess-" + "".join(rng.choice("0123456789abcdef") for _ in range(12)),
            cmmc_controls=tpl[3],
        ))

    attestations = []
    for i in range(12):
        attestations.append(AttestationRow(
            session_id="sess-" + "".join(rng.choice("0123456789abcdef") for _ in range(12)),
            model=rng.choice(["claude-sonnet-4-6", "claude-opus-4-6", "gpt-4o"]),
            timestamp=base_ts + rng.uniform(0, 86400 * 7),
            document_hash="".join(rng.choice("0123456789abcdef") for _ in range(64)),
            event_count=rng.randint(3, 24),
            goal_integrity=rng.uniform(0.45, 0.98),
        ))

    return ReportInput(
        organization=organization,
        cmmc_level=2,
        time_window_days=30,
        controls=DEFAULT_CONTROLS,
        events=events,
        s1513=DEFAULT_S1513,
        attestations=attestations,
        total_sessions=47,
        total_tool_calls=1842,
        total_blocked=7,
        avg_goal_integrity=0.83,
    )
