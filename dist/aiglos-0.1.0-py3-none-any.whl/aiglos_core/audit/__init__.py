"""
Aiglos Audit Log -- SQLite-backed chain-of-custody for all agent sessions.

Every tool call, security event, and session record is persisted here.
The audit log is the source of truth for forensics, CMMC compliance artifacts,
and the dashboard real-time feed.
"""

from __future__ import annotations

import json
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Generator

import sqlalchemy as sa
from sqlalchemy import event as sa_event

from aiglos_core.types import (
    AgentIdentity,
    SecurityEvent,
    SessionContext,
    ToolCall,
    ToolResponse,
)

# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------

metadata = sa.MetaData()

sessions_table = sa.Table(
    "sessions",
    metadata,
    sa.Column("session_id", sa.String, primary_key=True),
    sa.Column("model_id", sa.String),
    sa.Column("model_version", sa.String),
    sa.Column("system_prompt_hash", sa.String),
    sa.Column("tool_permissions", sa.Text),  # JSON array
    sa.Column("initiated_by", sa.String),
    sa.Column("attestation_hash", sa.String),
    sa.Column("authorized_goal", sa.Text),
    sa.Column("authorized_goal_hash", sa.String),
    sa.Column("goal_integrity_score", sa.Float, default=1.0),
    sa.Column("anomaly_score", sa.Float, default=0.0),
    sa.Column("is_active", sa.Boolean, default=True),
    sa.Column("start_time", sa.Float),
    sa.Column("end_time", sa.Float, nullable=True),
)

tool_calls_table = sa.Table(
    "tool_calls",
    metadata,
    sa.Column("id", sa.String, primary_key=True),
    sa.Column("session_id", sa.String, sa.ForeignKey("sessions.session_id")),
    sa.Column("server_id", sa.String),
    sa.Column("tool_name", sa.String),
    sa.Column("arguments", sa.Text),     # JSON
    sa.Column("raw_payload", sa.Text),   # JSON
    sa.Column("timestamp", sa.Float),
    sa.Column("allowed", sa.Boolean, default=True),
    sa.Column("blocked_reason", sa.Text, nullable=True),
    sa.Column("sanitized_arguments", sa.Text, nullable=True),
)

tool_responses_table = sa.Table(
    "tool_responses",
    metadata,
    sa.Column("call_id", sa.String, primary_key=True),
    sa.Column("session_id", sa.String, sa.ForeignKey("sessions.session_id")),
    sa.Column("tool_name", sa.String),
    sa.Column("result", sa.Text),       # JSON
    sa.Column("error", sa.Text, nullable=True),
    sa.Column("timestamp", sa.Float),
    sa.Column("secrets_detected", sa.Text),  # JSON array
)

events_table = sa.Table(
    "security_events",
    metadata,
    sa.Column("id", sa.String, primary_key=True),
    sa.Column("session_id", sa.String, sa.ForeignKey("sessions.session_id")),
    sa.Column("event_type", sa.String),
    sa.Column("severity", sa.String),
    sa.Column("title", sa.String),
    sa.Column("description", sa.Text),
    sa.Column("details", sa.Text),       # JSON
    sa.Column("timestamp", sa.Float),
    sa.Column("cmmc_controls", sa.Text), # JSON array
    sa.Column("nist_controls", sa.Text), # JSON array
)


# ---------------------------------------------------------------------------
# AuditLog class
# ---------------------------------------------------------------------------

class AuditLog:
    """
    Thread-safe, append-only audit log backed by SQLite.
    Suitable for single-node deployments. For distributed / Gov tier,
    swap the engine for PostgreSQL with no other changes needed.
    """

    def __init__(self, db_path: str = "aiglos_audit.db") -> None:
        self.db_path = db_path
        db_url = f"sqlite:///{db_path}" if db_path != ":memory:" else "sqlite://"
        self.engine = sa.create_engine(db_url, echo=False)

        # Enable WAL mode for concurrent reads while writing
        @sa_event.listens_for(self.engine, "connect")
        def set_sqlite_pragma(dbapi_conn, _):
            cursor = dbapi_conn.cursor()
            cursor.execute("PRAGMA journal_mode=WAL")
            cursor.execute("PRAGMA synchronous=NORMAL")
            cursor.close()

        metadata.create_all(self.engine)

    @contextmanager
    def _conn(self) -> Generator[sa.Connection, None, None]:
        with self.engine.begin() as conn:
            yield conn

    # ------------------------------------------------------------------
    # Session operations
    # ------------------------------------------------------------------

    def record_session_start(self, ctx: SessionContext) -> None:
        with self._conn() as conn:
            conn.execute(sessions_table.insert().values(
                session_id=ctx.identity.session_id,
                model_id=ctx.identity.model_id,
                model_version=ctx.identity.model_version,
                system_prompt_hash=ctx.identity.system_prompt_hash,
                tool_permissions=json.dumps(ctx.identity.tool_permissions),
                initiated_by=ctx.identity.initiated_by,
                attestation_hash=ctx.identity.attestation_hash,
                authorized_goal=ctx.authorized_goal,
                authorized_goal_hash=ctx.authorized_goal_hash,
                goal_integrity_score=ctx.goal_integrity_score,
                anomaly_score=ctx.anomaly_score,
                is_active=True,
                start_time=ctx.identity.timestamp,
                end_time=None,
            ))

    def update_session(self, ctx: SessionContext) -> None:
        with self._conn() as conn:
            conn.execute(
                sessions_table.update()
                .where(sessions_table.c.session_id == ctx.identity.session_id)
                .values(
                    goal_integrity_score=ctx.goal_integrity_score,
                    anomaly_score=ctx.anomaly_score,
                    is_active=ctx.is_active,
                    end_time=ctx.end_time,
                )
            )

    def close_session(self, session_id: str) -> None:
        with self._conn() as conn:
            conn.execute(
                sessions_table.update()
                .where(sessions_table.c.session_id == session_id)
                .values(is_active=False, end_time=time.time())
            )

    # ------------------------------------------------------------------
    # Tool call operations
    # ------------------------------------------------------------------

    def record_tool_call(self, call: ToolCall) -> None:
        with self._conn() as conn:
            conn.execute(tool_calls_table.insert().values(
                id=call.id,
                session_id=call.session_id,
                server_id=call.server_id,
                tool_name=call.tool_name,
                arguments=json.dumps(call.arguments),
                raw_payload=json.dumps(call.raw_payload),
                timestamp=call.timestamp,
                allowed=call.allowed,
                blocked_reason=call.blocked_reason,
                sanitized_arguments=(
                    json.dumps(call.sanitized_arguments)
                    if call.sanitized_arguments else None
                ),
            ))

    def record_tool_response(self, response: ToolResponse) -> None:
        with self._conn() as conn:
            conn.execute(tool_responses_table.insert().values(
                call_id=response.call_id,
                session_id=response.session_id,
                tool_name=response.tool_name,
                result=json.dumps(response.result),
                error=response.error,
                timestamp=response.timestamp,
                secrets_detected=json.dumps(response.secrets_detected),
            ))

    # ------------------------------------------------------------------
    # Security event operations
    # ------------------------------------------------------------------

    def record_event(self, event: SecurityEvent) -> None:
        with self._conn() as conn:
            conn.execute(events_table.insert().values(
                id=event.id,
                session_id=event.session_id,
                event_type=event.event_type.value,
                severity=event.severity.value,
                title=event.title,
                description=event.description,
                details=json.dumps(event.details),
                timestamp=event.timestamp,
                cmmc_controls=json.dumps(event.cmmc_controls),
                nist_controls=json.dumps(event.nist_controls),
            ))

    # ------------------------------------------------------------------
    # Query operations (for CLI and dashboard)
    # ------------------------------------------------------------------

    def get_recent_events(
        self, limit: int = 50, session_id: str | None = None,
        severity: str | None = None,
    ) -> list[dict]:
        with self._conn() as conn:
            q = sa.select(events_table).order_by(
                events_table.c.timestamp.desc()
            ).limit(limit)
            if session_id:
                q = q.where(events_table.c.session_id == session_id)
            if severity:
                q = q.where(events_table.c.severity == severity)
            rows = conn.execute(q).mappings().all()
        return [dict(r) for r in rows]

    def get_sessions(self, limit: int = 20, active_only: bool = False) -> list[dict]:
        with self._conn() as conn:
            q = sa.select(sessions_table).order_by(
                sessions_table.c.start_time.desc()
            ).limit(limit)
            if active_only:
                q = q.where(sessions_table.c.is_active == True)  # noqa: E712
            rows = conn.execute(q).mappings().all()
        return [dict(r) for r in rows]

    def get_tool_calls(
        self, session_id: str | None = None,
        blocked_only: bool = False,
        limit: int = 100,
    ) -> list[dict]:
        with self._conn() as conn:
            q = sa.select(tool_calls_table).order_by(
                tool_calls_table.c.timestamp.desc()
            ).limit(limit)
            if session_id:
                q = q.where(tool_calls_table.c.session_id == session_id)
            if blocked_only:
                q = q.where(tool_calls_table.c.allowed == False)  # noqa: E712
            rows = conn.execute(q).mappings().all()
        return [dict(r) for r in rows]

    def get_stats(self) -> dict:
        with self._conn() as conn:
            total_sessions = conn.execute(
                sa.select(sa.func.count()).select_from(sessions_table)
            ).scalar()
            active_sessions = conn.execute(
                sa.select(sa.func.count()).select_from(sessions_table)
                .where(sessions_table.c.is_active == True)  # noqa: E712
            ).scalar()
            total_tool_calls = conn.execute(
                sa.select(sa.func.count()).select_from(tool_calls_table)
            ).scalar()
            blocked_calls = conn.execute(
                sa.select(sa.func.count()).select_from(tool_calls_table)
                .where(tool_calls_table.c.allowed == False)  # noqa: E712
            ).scalar()
            critical_events = conn.execute(
                sa.select(sa.func.count()).select_from(events_table)
                .where(events_table.c.severity == "critical")
            ).scalar()
        return {
            "total_sessions": total_sessions,
            "active_sessions": active_sessions,
            "total_tool_calls": total_tool_calls,
            "blocked_calls": blocked_calls,
            "critical_events": critical_events,
        }
