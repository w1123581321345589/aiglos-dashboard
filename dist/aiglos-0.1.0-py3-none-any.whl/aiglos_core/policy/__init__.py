"""
Aiglos Policy Engine.

Human-readable YAML policies evaluated at the MCP proxy intercept point.
Every tool call passes through the policy engine before being forwarded.

Policy syntax example:
---
policies:
  - name: block_sudo
    description: Never allow sudo commands
    match:
      tool: shell
      argument_contains: "sudo"
    action: block
    severity: critical

  - name: restrict_file_access
    description: Only allow file operations within /project
    match:
      tool: file_*
      argument_pattern: "^(?!/project/).*"
    action: block
    severity: high

  - name: alert_new_domains
    description: Alert on network requests to new domains
    match:
      tool: http_request
    action: alert
    severity: medium
"""

from __future__ import annotations

import fnmatch
import re
from pathlib import Path
from typing import Any

import yaml

from aiglos_core.types import PolicyAction, PolicyResult, Severity, ToolCall


# ---------------------------------------------------------------------------
# Policy model
# ---------------------------------------------------------------------------

class PolicyRule:
    def __init__(self, raw: dict[str, Any]) -> None:
        self.name: str = raw.get("name", "unnamed")
        self.description: str = raw.get("description", "")
        self.match: dict[str, Any] = raw.get("match", {})
        self.action: PolicyAction = PolicyAction(raw.get("action", "log"))
        self.severity: Severity = Severity(raw.get("severity", "medium"))
        self.enabled: bool = raw.get("enabled", True)

    def matches(self, call: ToolCall) -> bool:
        if not self.enabled:
            return False

        m = self.match

        # Tool name match (supports glob: file_*, shell, etc.)
        if "tool" in m:
            if not fnmatch.fnmatch(call.tool_name, m["tool"]):
                return False

        # Argument contains (simple substring in any arg value)
        if "argument_contains" in m:
            needle = m["argument_contains"].lower()
            arg_str = str(call.arguments).lower()
            if needle not in arg_str:
                return False

        # Argument regex pattern
        if "argument_pattern" in m:
            pattern = re.compile(m["argument_pattern"])
            arg_str = str(call.arguments)
            if not pattern.search(arg_str):
                return False

        # Server ID match
        if "server" in m:
            if not fnmatch.fnmatch(call.server_id, m["server"]):
                return False

        return True


# ---------------------------------------------------------------------------
# Default built-in policies
# ---------------------------------------------------------------------------

BUILTIN_POLICIES: list[dict] = [
    {
        "name": "block_sudo",
        "description": "Never allow commands with sudo",
        "match": {"argument_contains": "sudo"},
        "action": "block",
        "severity": "critical",
    },
    {
        "name": "block_rm_rf",
        "description": "Block recursive delete commands",
        "match": {"argument_contains": "rm -rf"},
        "action": "block",
        "severity": "critical",
    },
    {
        "name": "block_credential_exfil",
        "description": "Block network calls that appear to contain credentials",
        "match": {
            "tool": "http*",
            "argument_pattern": r"(?i)(api_key|apikey|token|secret|password)\s*[:=]\s*\S{8,}",
        },
        "action": "block",
        "severity": "critical",
    },
    {
        "name": "alert_shell_execution",
        "description": "Alert on any shell or bash execution",
        "match": {"tool": "bash"},
        "action": "alert",
        "severity": "high",
    },
    {
        "name": "alert_shell_tool",
        "description": "Alert on shell tool usage",
        "match": {"tool": "shell"},
        "action": "alert",
        "severity": "high",
    },
    {
        "name": "log_file_writes",
        "description": "Log all file write operations",
        "match": {"tool": "write_file"},
        "action": "log",
        "severity": "info",
    },
    {
        "name": "block_path_traversal",
        "description": "Block path traversal attempts",
        "match": {"argument_contains": "../"},
        "action": "block",
        "severity": "high",
    },
    {
        "name": "alert_new_network_requests",
        "description": "Alert on outbound HTTP/HTTPS requests",
        "match": {"tool": "http_request"},
        "action": "alert",
        "severity": "medium",
    },
]

# Defense-specific policy profile
DEFENSE_POLICIES: list[dict] = BUILTIN_POLICIES + [
    {
        "name": "block_all_shell_execution",
        "description": "Defense profile: block all shell execution",
        "match": {"tool": "bash"},
        "action": "block",
        "severity": "critical",
    },
    {
        "name": "require_approval_network",
        "description": "Defense profile: require approval for all network requests",
        "match": {"tool": "http*"},
        "action": "require_approval",
        "severity": "high",
    },
    {
        "name": "block_external_domains",
        "description": "Defense profile: block requests to non-whitelisted domains",
        "match": {
            "tool": "http*",
            "argument_pattern": r"(?i)https?://(?!localhost|127\.0\.0\.1)",
        },
        "action": "block",
        "severity": "critical",
    },
]


# ---------------------------------------------------------------------------
# PolicyEngine class
# ---------------------------------------------------------------------------

class PolicyEngine:
    """
    Evaluates tool calls against ordered policy rules.
    First matching rule wins. Built-in rules always apply.
    Custom rules from YAML files layer on top.
    """

    def __init__(
        self,
        policy_file: str | None = None,
        profile: str = "default",
    ) -> None:
        base = DEFENSE_POLICIES if profile == "defense" else BUILTIN_POLICIES
        self.rules: list[PolicyRule] = [PolicyRule(r) for r in base]
        self.policy_file = policy_file

        if policy_file:
            self.load_file(policy_file)

        # Sort so BLOCK > REQUIRE_APPROVAL > ALERT > LOG for the same match scope
        _order = {"block": 0, "require_approval": 1, "alert": 2, "log": 3, "allow": 4}
        self.rules.sort(key=lambda r: _order.get(r.action.value, 5))

    def load_file(self, path: str) -> None:
        p = Path(path)
        if not p.exists():
            return
        with open(p) as f:
            data = yaml.safe_load(f)
        for rule_data in data.get("policies", []):
            self.rules.append(PolicyRule(rule_data))

    def evaluate(self, call: ToolCall) -> PolicyResult:
        """Return the first matching policy result, or ALLOW if none match."""
        for rule in self.rules:
            if rule.matches(call):
                return PolicyResult(
                    action=rule.action,
                    rule_name=rule.name,
                    reason=rule.description,
                    severity=rule.severity,
                )
        return PolicyResult(
            action=PolicyAction.ALLOW,
            rule_name="default_allow",
            reason="No policy matched",
            severity=Severity.INFO,
        )

    def add_rule(self, rule_data: dict) -> None:
        self.rules.append(PolicyRule(rule_data))
        _order = {"block": 0, "require_approval": 1, "alert": 2, "log": 3, "allow": 4}
        self.rules.sort(key=lambda r: _order.get(r.action.value, 5))

    def export_yaml(self) -> str:
        """Export current rules as YAML for inspection."""
        rules_out = []
        for r in self.rules:
            rules_out.append({
                "name": r.name,
                "description": r.description,
                "match": r.match,
                "action": r.action.value,
                "severity": r.severity.value,
                "enabled": r.enabled,
            })
        return yaml.dump({"policies": rules_out}, default_flow_style=False)


def generate_default_policy_file(path: str = "aiglos_policy.yaml") -> None:
    """Write a starter policy file to disk."""
    engine = PolicyEngine()
    with open(path, "w") as f:
        f.write("# Aiglos Policy File\n")
        f.write("# Edit this file to customize security policies.\n")
        f.write("# Actions: allow, block, log, alert, require_approval\n\n")
        f.write(engine.export_yaml())
